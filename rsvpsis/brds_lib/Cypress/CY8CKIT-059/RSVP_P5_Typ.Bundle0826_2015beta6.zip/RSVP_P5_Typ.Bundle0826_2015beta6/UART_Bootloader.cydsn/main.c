/**
******************************************************************************
    @file        main.c
    @author      Tom Moxon
    @copyright   PatternAgents, LLC
    @brief       This file provides the Main program entry point/function.
    @mainpage    RSVP Platform Firmware Documentation
    @section     main_intro Introduction
    @par
    \n
    @par
    @section    main_theory Theory of Operation
     The USB Bootloader uses USB interface to bootload a new project into flash memory.    \n
     The User Switch on the CY8CKIT-059 board can be held during power up to enter         \n
     into the bootloader on start, or the User Switch can be held for more than 2 seconds. \n
     The USER LED on the CY8CKIT-059 board blinks fast (300ms) to denote that the          \n
     bootloader code is running and  is ready for a bootloader host operation.             \n  
    @par
    \n
    @par
    @section    main_packages Firmware Packages 
    @par
    The RSVP Firmware utilizes several external software packages \n
	with various licenses. Check each package for redistribution terms. \n
    @par
    \n
	@par
	Cypress Creator Compiler/Libraries : \n
	GCC/Keil Compiler/Libraries : \n
	TBD: (audit any other third-party code for licensing terms) \n
	@par

 ******************************************************************************
*/
/*-----------------------------------------------------------------------------*/
/* Include Files                                                               */
/*-----------------------------------------------------------------------------*/
#include <project.h>

/*-----------------------------------------------------------------------------*/
/** @defgroup main main
  * @{
  */
#define RSVP_DEBUG 1 /**< Define to a nonzero value to enable debugging messages    */
#define RSVP_TEST  1 /**< Define to a nonzero value to enable internal test modes   */

/* Define the Bootloader Switch timeout (in ms) */
#define USER_SW_TIMEOUT 100

/*-----------------------------------------------------------------------------*/
/**
  * @fn         int main(void)
  * @brief      Firmware Main Entry Point
  * @brief      The is the main entry point for the UART Bootloader project
  * @param      None.
  * @retval     int (Main never returns, a return of int is used to indicate failure)
  */
int main()
{
    /* BootStrap Loader Time Out Count */
	uint8 bs_timeout_cnt = 0;	
	
	/* Enable global interrupts for the PSoC */
	CyGlobalIntEnable;
	
	/* Check if the user switch is pressed during power up */ 
	if( USER_SW_1_Read() == 0 )
	{
		/* give some time for the user to change their mind... */
		for(bs_timeout_cnt = 0; bs_timeout_cnt <= USER_SW_TIMEOUT; bs_timeout_cnt++)
		{
			CyDelay(1);				
			/* If the user switch is released before specified time, then bail... */
			if( USER_SW_1_Read() != 0)
				break;
		}
						 
        /* okay, he means it, enter the bootloader */
		if(bs_timeout_cnt > USER_SW_TIMEOUT)
		{
			/* set the flash run type as bootloader to wait for a bootload operation */
			Bootloader_SET_RUN_TYPE (Bootloader_START_BTLDR);
		}
	}
		
	/*Indicate that you have entered the bootloader mode.*/
	PWM_Start();
	
	/* Start the Bootloader */
	Bootloader_Start();			
    for(;;)
    {
      /* we should never get here, so kill the LED and halt the MCU... */
      PWM_Stop();
      CyHalt(0);
    }
}

/*****************************************************************************
# Copyright:	(C) 2013-2015 by PatternAgents,LLC. All rights reserved.
#*****************************************************************************
# RSVP-SIS Licensing Model:
# 
# RSVP-SIS uses the increasingly popular business model called 
# "Dual Licensing" in which both the open source software distribution 
# mechanism and traditional commercial software distribution models 
# are combined.
# 
# Open Source Projects:
# 
# If you are developing and distributing open source applications 
# under the GNU General Public License version 3 (GPLv3), 
# as published by the Free Software Foundation, then you are free 
# to use the RSVP-SIS software under the GPLv3 license. Please note 
# that GPLv3 Section 2(b) requires that all modifications to the 
# original code as well as all Derivative Works must also be 
# released under the terms of the GPLv3 open source license.
# 
# Closed Source Projects:
# 
# If you are developing and distributing traditional closed source 
# applications, you must purchase a RSVP-SIS commercial use license, 
# which is specifically designed for users interested in retaining 
# the proprietary status of their code. All RSVP-SIS commercial licenses 
# expressly supersede the GPLv3 open source license. This means that 
# when you license the RSVP-SIS software under a commercial license, 
# you specifically do not use the software under the open source 
# license and therefore you are not subject to any of its terms.
#
# Commercial licensing options available on the RSVP-SIS Website at : 
#	http://www.rsvpsis.org/licensing/
#
#*****************************************************************************
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, 
# BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
# COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED 
# AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE 
# USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
/* End of main.c */

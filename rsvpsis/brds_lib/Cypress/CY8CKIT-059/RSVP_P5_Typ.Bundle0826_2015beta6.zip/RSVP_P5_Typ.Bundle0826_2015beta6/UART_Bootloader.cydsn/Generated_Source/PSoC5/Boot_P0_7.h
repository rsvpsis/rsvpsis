/*******************************************************************************
* File Name: Boot_P0_7.h  
* Version 2.10
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Boot_P0_7_H) /* Pins Boot_P0_7_H */
#define CY_PINS_Boot_P0_7_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "Boot_P0_7_aliases.h"

/* Check to see if required defines such as CY_PSOC5A are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5A)
    #error Component cy_pins_v2_10 requires cy_boot v3.0 or later
#endif /* (CY_PSOC5A) */

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 Boot_P0_7__PORT == 15 && ((Boot_P0_7__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

void    Boot_P0_7_Write(uint8 value) ;
void    Boot_P0_7_SetDriveMode(uint8 mode) ;
uint8   Boot_P0_7_ReadDataReg(void) ;
uint8   Boot_P0_7_Read(void) ;
uint8   Boot_P0_7_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define Boot_P0_7_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define Boot_P0_7_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define Boot_P0_7_DM_RES_UP          PIN_DM_RES_UP
#define Boot_P0_7_DM_RES_DWN         PIN_DM_RES_DWN
#define Boot_P0_7_DM_OD_LO           PIN_DM_OD_LO
#define Boot_P0_7_DM_OD_HI           PIN_DM_OD_HI
#define Boot_P0_7_DM_STRONG          PIN_DM_STRONG
#define Boot_P0_7_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define Boot_P0_7_MASK               Boot_P0_7__MASK
#define Boot_P0_7_SHIFT              Boot_P0_7__SHIFT
#define Boot_P0_7_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define Boot_P0_7_PS                     (* (reg8 *) Boot_P0_7__PS)
/* Data Register */
#define Boot_P0_7_DR                     (* (reg8 *) Boot_P0_7__DR)
/* Port Number */
#define Boot_P0_7_PRT_NUM                (* (reg8 *) Boot_P0_7__PRT) 
/* Connect to Analog Globals */                                                  
#define Boot_P0_7_AG                     (* (reg8 *) Boot_P0_7__AG)                       
/* Analog MUX bux enable */
#define Boot_P0_7_AMUX                   (* (reg8 *) Boot_P0_7__AMUX) 
/* Bidirectional Enable */                                                        
#define Boot_P0_7_BIE                    (* (reg8 *) Boot_P0_7__BIE)
/* Bit-mask for Aliased Register Access */
#define Boot_P0_7_BIT_MASK               (* (reg8 *) Boot_P0_7__BIT_MASK)
/* Bypass Enable */
#define Boot_P0_7_BYP                    (* (reg8 *) Boot_P0_7__BYP)
/* Port wide control signals */                                                   
#define Boot_P0_7_CTL                    (* (reg8 *) Boot_P0_7__CTL)
/* Drive Modes */
#define Boot_P0_7_DM0                    (* (reg8 *) Boot_P0_7__DM0) 
#define Boot_P0_7_DM1                    (* (reg8 *) Boot_P0_7__DM1)
#define Boot_P0_7_DM2                    (* (reg8 *) Boot_P0_7__DM2) 
/* Input Buffer Disable Override */
#define Boot_P0_7_INP_DIS                (* (reg8 *) Boot_P0_7__INP_DIS)
/* LCD Common or Segment Drive */
#define Boot_P0_7_LCD_COM_SEG            (* (reg8 *) Boot_P0_7__LCD_COM_SEG)
/* Enable Segment LCD */
#define Boot_P0_7_LCD_EN                 (* (reg8 *) Boot_P0_7__LCD_EN)
/* Slew Rate Control */
#define Boot_P0_7_SLW                    (* (reg8 *) Boot_P0_7__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define Boot_P0_7_PRTDSI__CAPS_SEL       (* (reg8 *) Boot_P0_7__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define Boot_P0_7_PRTDSI__DBL_SYNC_IN    (* (reg8 *) Boot_P0_7__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define Boot_P0_7_PRTDSI__OE_SEL0        (* (reg8 *) Boot_P0_7__PRTDSI__OE_SEL0) 
#define Boot_P0_7_PRTDSI__OE_SEL1        (* (reg8 *) Boot_P0_7__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define Boot_P0_7_PRTDSI__OUT_SEL0       (* (reg8 *) Boot_P0_7__PRTDSI__OUT_SEL0) 
#define Boot_P0_7_PRTDSI__OUT_SEL1       (* (reg8 *) Boot_P0_7__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define Boot_P0_7_PRTDSI__SYNC_OUT       (* (reg8 *) Boot_P0_7__PRTDSI__SYNC_OUT) 


#if defined(Boot_P0_7__INTSTAT)  /* Interrupt Registers */

    #define Boot_P0_7_INTSTAT                (* (reg8 *) Boot_P0_7__INTSTAT)
    #define Boot_P0_7_SNAP                   (* (reg8 *) Boot_P0_7__SNAP)

#endif /* Interrupt Registers */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_Boot_P0_7_H */


/* [] END OF FILE */

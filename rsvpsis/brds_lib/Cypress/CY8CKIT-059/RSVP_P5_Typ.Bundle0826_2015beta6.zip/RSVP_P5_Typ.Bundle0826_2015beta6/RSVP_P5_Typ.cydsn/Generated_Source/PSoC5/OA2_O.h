/*******************************************************************************
* File Name: OA2_O.h  
* Version 2.10
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_OA2_O_H) /* Pins OA2_O_H */
#define CY_PINS_OA2_O_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "OA2_O_aliases.h"

/* Check to see if required defines such as CY_PSOC5A are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5A)
    #error Component cy_pins_v2_10 requires cy_boot v3.0 or later
#endif /* (CY_PSOC5A) */

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 OA2_O__PORT == 15 && ((OA2_O__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

void    OA2_O_Write(uint8 value) ;
void    OA2_O_SetDriveMode(uint8 mode) ;
uint8   OA2_O_ReadDataReg(void) ;
uint8   OA2_O_Read(void) ;
uint8   OA2_O_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define OA2_O_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define OA2_O_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define OA2_O_DM_RES_UP          PIN_DM_RES_UP
#define OA2_O_DM_RES_DWN         PIN_DM_RES_DWN
#define OA2_O_DM_OD_LO           PIN_DM_OD_LO
#define OA2_O_DM_OD_HI           PIN_DM_OD_HI
#define OA2_O_DM_STRONG          PIN_DM_STRONG
#define OA2_O_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define OA2_O_MASK               OA2_O__MASK
#define OA2_O_SHIFT              OA2_O__SHIFT
#define OA2_O_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define OA2_O_PS                     (* (reg8 *) OA2_O__PS)
/* Data Register */
#define OA2_O_DR                     (* (reg8 *) OA2_O__DR)
/* Port Number */
#define OA2_O_PRT_NUM                (* (reg8 *) OA2_O__PRT) 
/* Connect to Analog Globals */                                                  
#define OA2_O_AG                     (* (reg8 *) OA2_O__AG)                       
/* Analog MUX bux enable */
#define OA2_O_AMUX                   (* (reg8 *) OA2_O__AMUX) 
/* Bidirectional Enable */                                                        
#define OA2_O_BIE                    (* (reg8 *) OA2_O__BIE)
/* Bit-mask for Aliased Register Access */
#define OA2_O_BIT_MASK               (* (reg8 *) OA2_O__BIT_MASK)
/* Bypass Enable */
#define OA2_O_BYP                    (* (reg8 *) OA2_O__BYP)
/* Port wide control signals */                                                   
#define OA2_O_CTL                    (* (reg8 *) OA2_O__CTL)
/* Drive Modes */
#define OA2_O_DM0                    (* (reg8 *) OA2_O__DM0) 
#define OA2_O_DM1                    (* (reg8 *) OA2_O__DM1)
#define OA2_O_DM2                    (* (reg8 *) OA2_O__DM2) 
/* Input Buffer Disable Override */
#define OA2_O_INP_DIS                (* (reg8 *) OA2_O__INP_DIS)
/* LCD Common or Segment Drive */
#define OA2_O_LCD_COM_SEG            (* (reg8 *) OA2_O__LCD_COM_SEG)
/* Enable Segment LCD */
#define OA2_O_LCD_EN                 (* (reg8 *) OA2_O__LCD_EN)
/* Slew Rate Control */
#define OA2_O_SLW                    (* (reg8 *) OA2_O__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define OA2_O_PRTDSI__CAPS_SEL       (* (reg8 *) OA2_O__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define OA2_O_PRTDSI__DBL_SYNC_IN    (* (reg8 *) OA2_O__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define OA2_O_PRTDSI__OE_SEL0        (* (reg8 *) OA2_O__PRTDSI__OE_SEL0) 
#define OA2_O_PRTDSI__OE_SEL1        (* (reg8 *) OA2_O__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define OA2_O_PRTDSI__OUT_SEL0       (* (reg8 *) OA2_O__PRTDSI__OUT_SEL0) 
#define OA2_O_PRTDSI__OUT_SEL1       (* (reg8 *) OA2_O__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define OA2_O_PRTDSI__SYNC_OUT       (* (reg8 *) OA2_O__PRTDSI__SYNC_OUT) 


#if defined(OA2_O__INTSTAT)  /* Interrupt Registers */

    #define OA2_O_INTSTAT                (* (reg8 *) OA2_O__INTSTAT)
    #define OA2_O_SNAP                   (* (reg8 *) OA2_O__SNAP)

#endif /* Interrupt Registers */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_OA2_O_H */


/* [] END OF FILE */

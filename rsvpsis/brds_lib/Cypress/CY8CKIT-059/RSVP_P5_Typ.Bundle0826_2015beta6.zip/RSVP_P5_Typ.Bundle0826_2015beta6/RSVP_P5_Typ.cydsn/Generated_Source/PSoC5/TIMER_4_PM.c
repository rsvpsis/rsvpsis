/*******************************************************************************
* File Name: TIMER_4_PM.c
* Version 2.70
*
*  Description:
*     This file provides the power management source code to API for the
*     Timer.
*
*   Note:
*     None
*
*******************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
********************************************************************************/

#include "TIMER_4.h"

static TIMER_4_backupStruct TIMER_4_backup;


/*******************************************************************************
* Function Name: TIMER_4_SaveConfig
********************************************************************************
*
* Summary:
*     Save the current user configuration
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  TIMER_4_backup:  Variables of this global structure are modified to
*  store the values of non retention configuration registers when Sleep() API is
*  called.
*
*******************************************************************************/
void TIMER_4_SaveConfig(void) 
{
    #if (!TIMER_4_UsingFixedFunction)
        TIMER_4_backup.TimerUdb = TIMER_4_ReadCounter();
        TIMER_4_backup.InterruptMaskValue = TIMER_4_STATUS_MASK;
        #if (TIMER_4_UsingHWCaptureCounter)
            TIMER_4_backup.TimerCaptureCounter = TIMER_4_ReadCaptureCount();
        #endif /* Back Up capture counter register  */

        #if(!TIMER_4_UDB_CONTROL_REG_REMOVED)
            TIMER_4_backup.TimerControlRegister = TIMER_4_ReadControlRegister();
        #endif /* Backup the enable state of the Timer component */
    #endif /* Backup non retention registers in UDB implementation. All fixed function registers are retention */
}


/*******************************************************************************
* Function Name: TIMER_4_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the current user configuration.
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  TIMER_4_backup:  Variables of this global structure are used to
*  restore the values of non retention registers on wakeup from sleep mode.
*
*******************************************************************************/
void TIMER_4_RestoreConfig(void) 
{   
    #if (!TIMER_4_UsingFixedFunction)

        TIMER_4_WriteCounter(TIMER_4_backup.TimerUdb);
        TIMER_4_STATUS_MASK =TIMER_4_backup.InterruptMaskValue;
        #if (TIMER_4_UsingHWCaptureCounter)
            TIMER_4_SetCaptureCount(TIMER_4_backup.TimerCaptureCounter);
        #endif /* Restore Capture counter register*/

        #if(!TIMER_4_UDB_CONTROL_REG_REMOVED)
            TIMER_4_WriteControlRegister(TIMER_4_backup.TimerControlRegister);
        #endif /* Restore the enable state of the Timer component */
    #endif /* Restore non retention registers in the UDB implementation only */
}


/*******************************************************************************
* Function Name: TIMER_4_Sleep
********************************************************************************
*
* Summary:
*     Stop and Save the user configuration
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  TIMER_4_backup.TimerEnableState:  Is modified depending on the
*  enable state of the block before entering sleep mode.
*
*******************************************************************************/
void TIMER_4_Sleep(void) 
{
    #if(!TIMER_4_UDB_CONTROL_REG_REMOVED)
        /* Save Counter's enable state */
        if(TIMER_4_CTRL_ENABLE == (TIMER_4_CONTROL & TIMER_4_CTRL_ENABLE))
        {
            /* Timer is enabled */
            TIMER_4_backup.TimerEnableState = 1u;
        }
        else
        {
            /* Timer is disabled */
            TIMER_4_backup.TimerEnableState = 0u;
        }
    #endif /* Back up enable state from the Timer control register */
    TIMER_4_Stop();
    TIMER_4_SaveConfig();
}


/*******************************************************************************
* Function Name: TIMER_4_Wakeup
********************************************************************************
*
* Summary:
*  Restores and enables the user configuration
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  TIMER_4_backup.enableState:  Is used to restore the enable state of
*  block on wakeup from sleep mode.
*
*******************************************************************************/
void TIMER_4_Wakeup(void) 
{
    TIMER_4_RestoreConfig();
    #if(!TIMER_4_UDB_CONTROL_REG_REMOVED)
        if(TIMER_4_backup.TimerEnableState == 1u)
        {     /* Enable Timer's operation */
                TIMER_4_Enable();
        } /* Do nothing if Timer was disabled before */
    #endif /* Remove this code section if Control register is removed */
}


/* [] END OF FILE */

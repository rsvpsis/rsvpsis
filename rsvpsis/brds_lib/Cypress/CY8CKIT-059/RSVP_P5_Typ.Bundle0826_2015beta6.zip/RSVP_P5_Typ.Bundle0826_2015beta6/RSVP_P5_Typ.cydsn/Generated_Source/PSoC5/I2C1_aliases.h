/*******************************************************************************
* File Name: I2C1.h  
* Version 2.10
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_I2C1_ALIASES_H) /* Pins I2C1_ALIASES_H */
#define CY_PINS_I2C1_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"



/***************************************
*              Constants        
***************************************/
#define I2C1_0		(I2C1__0__PC)
#define I2C1_1		(I2C1__1__PC)

#define I2C1_scl		(I2C1__scl__PC)
#define I2C1_sda		(I2C1__sda__PC)

#endif /* End Pins I2C1_ALIASES_H */

/* [] END OF FILE */

/*******************************************************************************
* File Name: A8_N.h  
* Version 2.10
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_A8_N_H) /* Pins A8_N_H */
#define CY_PINS_A8_N_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "A8_N_aliases.h"

/* Check to see if required defines such as CY_PSOC5A are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5A)
    #error Component cy_pins_v2_10 requires cy_boot v3.0 or later
#endif /* (CY_PSOC5A) */

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 A8_N__PORT == 15 && ((A8_N__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

void    A8_N_Write(uint8 value) ;
void    A8_N_SetDriveMode(uint8 mode) ;
uint8   A8_N_ReadDataReg(void) ;
uint8   A8_N_Read(void) ;
uint8   A8_N_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define A8_N_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define A8_N_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define A8_N_DM_RES_UP          PIN_DM_RES_UP
#define A8_N_DM_RES_DWN         PIN_DM_RES_DWN
#define A8_N_DM_OD_LO           PIN_DM_OD_LO
#define A8_N_DM_OD_HI           PIN_DM_OD_HI
#define A8_N_DM_STRONG          PIN_DM_STRONG
#define A8_N_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define A8_N_MASK               A8_N__MASK
#define A8_N_SHIFT              A8_N__SHIFT
#define A8_N_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define A8_N_PS                     (* (reg8 *) A8_N__PS)
/* Data Register */
#define A8_N_DR                     (* (reg8 *) A8_N__DR)
/* Port Number */
#define A8_N_PRT_NUM                (* (reg8 *) A8_N__PRT) 
/* Connect to Analog Globals */                                                  
#define A8_N_AG                     (* (reg8 *) A8_N__AG)                       
/* Analog MUX bux enable */
#define A8_N_AMUX                   (* (reg8 *) A8_N__AMUX) 
/* Bidirectional Enable */                                                        
#define A8_N_BIE                    (* (reg8 *) A8_N__BIE)
/* Bit-mask for Aliased Register Access */
#define A8_N_BIT_MASK               (* (reg8 *) A8_N__BIT_MASK)
/* Bypass Enable */
#define A8_N_BYP                    (* (reg8 *) A8_N__BYP)
/* Port wide control signals */                                                   
#define A8_N_CTL                    (* (reg8 *) A8_N__CTL)
/* Drive Modes */
#define A8_N_DM0                    (* (reg8 *) A8_N__DM0) 
#define A8_N_DM1                    (* (reg8 *) A8_N__DM1)
#define A8_N_DM2                    (* (reg8 *) A8_N__DM2) 
/* Input Buffer Disable Override */
#define A8_N_INP_DIS                (* (reg8 *) A8_N__INP_DIS)
/* LCD Common or Segment Drive */
#define A8_N_LCD_COM_SEG            (* (reg8 *) A8_N__LCD_COM_SEG)
/* Enable Segment LCD */
#define A8_N_LCD_EN                 (* (reg8 *) A8_N__LCD_EN)
/* Slew Rate Control */
#define A8_N_SLW                    (* (reg8 *) A8_N__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define A8_N_PRTDSI__CAPS_SEL       (* (reg8 *) A8_N__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define A8_N_PRTDSI__DBL_SYNC_IN    (* (reg8 *) A8_N__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define A8_N_PRTDSI__OE_SEL0        (* (reg8 *) A8_N__PRTDSI__OE_SEL0) 
#define A8_N_PRTDSI__OE_SEL1        (* (reg8 *) A8_N__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define A8_N_PRTDSI__OUT_SEL0       (* (reg8 *) A8_N__PRTDSI__OUT_SEL0) 
#define A8_N_PRTDSI__OUT_SEL1       (* (reg8 *) A8_N__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define A8_N_PRTDSI__SYNC_OUT       (* (reg8 *) A8_N__PRTDSI__SYNC_OUT) 


#if defined(A8_N__INTSTAT)  /* Interrupt Registers */

    #define A8_N_INTSTAT                (* (reg8 *) A8_N__INTSTAT)
    #define A8_N_SNAP                   (* (reg8 *) A8_N__SNAP)

#endif /* Interrupt Registers */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_A8_N_H */


/* [] END OF FILE */

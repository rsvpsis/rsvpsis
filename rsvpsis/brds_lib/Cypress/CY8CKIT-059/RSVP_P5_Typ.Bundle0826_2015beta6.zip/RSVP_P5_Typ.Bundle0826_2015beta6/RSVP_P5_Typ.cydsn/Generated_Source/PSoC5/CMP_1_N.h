/*******************************************************************************
* File Name: CMP_1_N.h  
* Version 2.10
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_CMP_1_N_H) /* Pins CMP_1_N_H */
#define CY_PINS_CMP_1_N_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "CMP_1_N_aliases.h"

/* Check to see if required defines such as CY_PSOC5A are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5A)
    #error Component cy_pins_v2_10 requires cy_boot v3.0 or later
#endif /* (CY_PSOC5A) */

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 CMP_1_N__PORT == 15 && ((CMP_1_N__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

void    CMP_1_N_Write(uint8 value) ;
void    CMP_1_N_SetDriveMode(uint8 mode) ;
uint8   CMP_1_N_ReadDataReg(void) ;
uint8   CMP_1_N_Read(void) ;
uint8   CMP_1_N_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define CMP_1_N_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define CMP_1_N_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define CMP_1_N_DM_RES_UP          PIN_DM_RES_UP
#define CMP_1_N_DM_RES_DWN         PIN_DM_RES_DWN
#define CMP_1_N_DM_OD_LO           PIN_DM_OD_LO
#define CMP_1_N_DM_OD_HI           PIN_DM_OD_HI
#define CMP_1_N_DM_STRONG          PIN_DM_STRONG
#define CMP_1_N_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define CMP_1_N_MASK               CMP_1_N__MASK
#define CMP_1_N_SHIFT              CMP_1_N__SHIFT
#define CMP_1_N_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define CMP_1_N_PS                     (* (reg8 *) CMP_1_N__PS)
/* Data Register */
#define CMP_1_N_DR                     (* (reg8 *) CMP_1_N__DR)
/* Port Number */
#define CMP_1_N_PRT_NUM                (* (reg8 *) CMP_1_N__PRT) 
/* Connect to Analog Globals */                                                  
#define CMP_1_N_AG                     (* (reg8 *) CMP_1_N__AG)                       
/* Analog MUX bux enable */
#define CMP_1_N_AMUX                   (* (reg8 *) CMP_1_N__AMUX) 
/* Bidirectional Enable */                                                        
#define CMP_1_N_BIE                    (* (reg8 *) CMP_1_N__BIE)
/* Bit-mask for Aliased Register Access */
#define CMP_1_N_BIT_MASK               (* (reg8 *) CMP_1_N__BIT_MASK)
/* Bypass Enable */
#define CMP_1_N_BYP                    (* (reg8 *) CMP_1_N__BYP)
/* Port wide control signals */                                                   
#define CMP_1_N_CTL                    (* (reg8 *) CMP_1_N__CTL)
/* Drive Modes */
#define CMP_1_N_DM0                    (* (reg8 *) CMP_1_N__DM0) 
#define CMP_1_N_DM1                    (* (reg8 *) CMP_1_N__DM1)
#define CMP_1_N_DM2                    (* (reg8 *) CMP_1_N__DM2) 
/* Input Buffer Disable Override */
#define CMP_1_N_INP_DIS                (* (reg8 *) CMP_1_N__INP_DIS)
/* LCD Common or Segment Drive */
#define CMP_1_N_LCD_COM_SEG            (* (reg8 *) CMP_1_N__LCD_COM_SEG)
/* Enable Segment LCD */
#define CMP_1_N_LCD_EN                 (* (reg8 *) CMP_1_N__LCD_EN)
/* Slew Rate Control */
#define CMP_1_N_SLW                    (* (reg8 *) CMP_1_N__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define CMP_1_N_PRTDSI__CAPS_SEL       (* (reg8 *) CMP_1_N__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define CMP_1_N_PRTDSI__DBL_SYNC_IN    (* (reg8 *) CMP_1_N__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define CMP_1_N_PRTDSI__OE_SEL0        (* (reg8 *) CMP_1_N__PRTDSI__OE_SEL0) 
#define CMP_1_N_PRTDSI__OE_SEL1        (* (reg8 *) CMP_1_N__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define CMP_1_N_PRTDSI__OUT_SEL0       (* (reg8 *) CMP_1_N__PRTDSI__OUT_SEL0) 
#define CMP_1_N_PRTDSI__OUT_SEL1       (* (reg8 *) CMP_1_N__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define CMP_1_N_PRTDSI__SYNC_OUT       (* (reg8 *) CMP_1_N__PRTDSI__SYNC_OUT) 


#if defined(CMP_1_N__INTSTAT)  /* Interrupt Registers */

    #define CMP_1_N_INTSTAT                (* (reg8 *) CMP_1_N__INTSTAT)
    #define CMP_1_N_SNAP                   (* (reg8 *) CMP_1_N__SNAP)

#endif /* Interrupt Registers */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_CMP_1_N_H */


/* [] END OF FILE */

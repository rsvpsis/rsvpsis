/*******************************************************************************
* File Name: CMP_1_P.h  
* Version 2.10
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_CMP_1_P_H) /* Pins CMP_1_P_H */
#define CY_PINS_CMP_1_P_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "CMP_1_P_aliases.h"

/* Check to see if required defines such as CY_PSOC5A are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5A)
    #error Component cy_pins_v2_10 requires cy_boot v3.0 or later
#endif /* (CY_PSOC5A) */

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 CMP_1_P__PORT == 15 && ((CMP_1_P__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

void    CMP_1_P_Write(uint8 value) ;
void    CMP_1_P_SetDriveMode(uint8 mode) ;
uint8   CMP_1_P_ReadDataReg(void) ;
uint8   CMP_1_P_Read(void) ;
uint8   CMP_1_P_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define CMP_1_P_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define CMP_1_P_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define CMP_1_P_DM_RES_UP          PIN_DM_RES_UP
#define CMP_1_P_DM_RES_DWN         PIN_DM_RES_DWN
#define CMP_1_P_DM_OD_LO           PIN_DM_OD_LO
#define CMP_1_P_DM_OD_HI           PIN_DM_OD_HI
#define CMP_1_P_DM_STRONG          PIN_DM_STRONG
#define CMP_1_P_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define CMP_1_P_MASK               CMP_1_P__MASK
#define CMP_1_P_SHIFT              CMP_1_P__SHIFT
#define CMP_1_P_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define CMP_1_P_PS                     (* (reg8 *) CMP_1_P__PS)
/* Data Register */
#define CMP_1_P_DR                     (* (reg8 *) CMP_1_P__DR)
/* Port Number */
#define CMP_1_P_PRT_NUM                (* (reg8 *) CMP_1_P__PRT) 
/* Connect to Analog Globals */                                                  
#define CMP_1_P_AG                     (* (reg8 *) CMP_1_P__AG)                       
/* Analog MUX bux enable */
#define CMP_1_P_AMUX                   (* (reg8 *) CMP_1_P__AMUX) 
/* Bidirectional Enable */                                                        
#define CMP_1_P_BIE                    (* (reg8 *) CMP_1_P__BIE)
/* Bit-mask for Aliased Register Access */
#define CMP_1_P_BIT_MASK               (* (reg8 *) CMP_1_P__BIT_MASK)
/* Bypass Enable */
#define CMP_1_P_BYP                    (* (reg8 *) CMP_1_P__BYP)
/* Port wide control signals */                                                   
#define CMP_1_P_CTL                    (* (reg8 *) CMP_1_P__CTL)
/* Drive Modes */
#define CMP_1_P_DM0                    (* (reg8 *) CMP_1_P__DM0) 
#define CMP_1_P_DM1                    (* (reg8 *) CMP_1_P__DM1)
#define CMP_1_P_DM2                    (* (reg8 *) CMP_1_P__DM2) 
/* Input Buffer Disable Override */
#define CMP_1_P_INP_DIS                (* (reg8 *) CMP_1_P__INP_DIS)
/* LCD Common or Segment Drive */
#define CMP_1_P_LCD_COM_SEG            (* (reg8 *) CMP_1_P__LCD_COM_SEG)
/* Enable Segment LCD */
#define CMP_1_P_LCD_EN                 (* (reg8 *) CMP_1_P__LCD_EN)
/* Slew Rate Control */
#define CMP_1_P_SLW                    (* (reg8 *) CMP_1_P__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define CMP_1_P_PRTDSI__CAPS_SEL       (* (reg8 *) CMP_1_P__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define CMP_1_P_PRTDSI__DBL_SYNC_IN    (* (reg8 *) CMP_1_P__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define CMP_1_P_PRTDSI__OE_SEL0        (* (reg8 *) CMP_1_P__PRTDSI__OE_SEL0) 
#define CMP_1_P_PRTDSI__OE_SEL1        (* (reg8 *) CMP_1_P__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define CMP_1_P_PRTDSI__OUT_SEL0       (* (reg8 *) CMP_1_P__PRTDSI__OUT_SEL0) 
#define CMP_1_P_PRTDSI__OUT_SEL1       (* (reg8 *) CMP_1_P__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define CMP_1_P_PRTDSI__SYNC_OUT       (* (reg8 *) CMP_1_P__PRTDSI__SYNC_OUT) 


#if defined(CMP_1_P__INTSTAT)  /* Interrupt Registers */

    #define CMP_1_P_INTSTAT                (* (reg8 *) CMP_1_P__INTSTAT)
    #define CMP_1_P_SNAP                   (* (reg8 *) CMP_1_P__SNAP)

#endif /* Interrupt Registers */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_CMP_1_P_H */


/* [] END OF FILE */

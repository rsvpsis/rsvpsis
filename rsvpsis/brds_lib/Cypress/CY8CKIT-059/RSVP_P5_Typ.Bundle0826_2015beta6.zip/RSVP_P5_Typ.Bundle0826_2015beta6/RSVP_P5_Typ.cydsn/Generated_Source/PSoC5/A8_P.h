/*******************************************************************************
* File Name: A8_P.h  
* Version 2.10
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_A8_P_H) /* Pins A8_P_H */
#define CY_PINS_A8_P_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "A8_P_aliases.h"

/* Check to see if required defines such as CY_PSOC5A are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5A)
    #error Component cy_pins_v2_10 requires cy_boot v3.0 or later
#endif /* (CY_PSOC5A) */

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 A8_P__PORT == 15 && ((A8_P__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

void    A8_P_Write(uint8 value) ;
void    A8_P_SetDriveMode(uint8 mode) ;
uint8   A8_P_ReadDataReg(void) ;
uint8   A8_P_Read(void) ;
uint8   A8_P_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define A8_P_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define A8_P_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define A8_P_DM_RES_UP          PIN_DM_RES_UP
#define A8_P_DM_RES_DWN         PIN_DM_RES_DWN
#define A8_P_DM_OD_LO           PIN_DM_OD_LO
#define A8_P_DM_OD_HI           PIN_DM_OD_HI
#define A8_P_DM_STRONG          PIN_DM_STRONG
#define A8_P_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define A8_P_MASK               A8_P__MASK
#define A8_P_SHIFT              A8_P__SHIFT
#define A8_P_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define A8_P_PS                     (* (reg8 *) A8_P__PS)
/* Data Register */
#define A8_P_DR                     (* (reg8 *) A8_P__DR)
/* Port Number */
#define A8_P_PRT_NUM                (* (reg8 *) A8_P__PRT) 
/* Connect to Analog Globals */                                                  
#define A8_P_AG                     (* (reg8 *) A8_P__AG)                       
/* Analog MUX bux enable */
#define A8_P_AMUX                   (* (reg8 *) A8_P__AMUX) 
/* Bidirectional Enable */                                                        
#define A8_P_BIE                    (* (reg8 *) A8_P__BIE)
/* Bit-mask for Aliased Register Access */
#define A8_P_BIT_MASK               (* (reg8 *) A8_P__BIT_MASK)
/* Bypass Enable */
#define A8_P_BYP                    (* (reg8 *) A8_P__BYP)
/* Port wide control signals */                                                   
#define A8_P_CTL                    (* (reg8 *) A8_P__CTL)
/* Drive Modes */
#define A8_P_DM0                    (* (reg8 *) A8_P__DM0) 
#define A8_P_DM1                    (* (reg8 *) A8_P__DM1)
#define A8_P_DM2                    (* (reg8 *) A8_P__DM2) 
/* Input Buffer Disable Override */
#define A8_P_INP_DIS                (* (reg8 *) A8_P__INP_DIS)
/* LCD Common or Segment Drive */
#define A8_P_LCD_COM_SEG            (* (reg8 *) A8_P__LCD_COM_SEG)
/* Enable Segment LCD */
#define A8_P_LCD_EN                 (* (reg8 *) A8_P__LCD_EN)
/* Slew Rate Control */
#define A8_P_SLW                    (* (reg8 *) A8_P__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define A8_P_PRTDSI__CAPS_SEL       (* (reg8 *) A8_P__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define A8_P_PRTDSI__DBL_SYNC_IN    (* (reg8 *) A8_P__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define A8_P_PRTDSI__OE_SEL0        (* (reg8 *) A8_P__PRTDSI__OE_SEL0) 
#define A8_P_PRTDSI__OE_SEL1        (* (reg8 *) A8_P__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define A8_P_PRTDSI__OUT_SEL0       (* (reg8 *) A8_P__PRTDSI__OUT_SEL0) 
#define A8_P_PRTDSI__OUT_SEL1       (* (reg8 *) A8_P__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define A8_P_PRTDSI__SYNC_OUT       (* (reg8 *) A8_P__PRTDSI__SYNC_OUT) 


#if defined(A8_P__INTSTAT)  /* Interrupt Registers */

    #define A8_P_INTSTAT                (* (reg8 *) A8_P__INTSTAT)
    #define A8_P_SNAP                   (* (reg8 *) A8_P__SNAP)

#endif /* Interrupt Registers */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_A8_P_H */


/* [] END OF FILE */

/*******************************************************************************
* File Name: CMP_2.c
* Version 2.0
*
* Description:
*  This file provides the power management source code APIs for the
*  Comparator.
*
* Note:
*  None
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#include "CMP_2.h"

static CMP_2_backupStruct CMP_2_backup;


/*******************************************************************************
* Function Name: CMP_2_SaveConfig
********************************************************************************
*
* Summary:
*  Save the current user configuration
*
* Parameters:
*  void:
*
* Return:
*  void
*
*******************************************************************************/
void CMP_2_SaveConfig(void) 
{
    /* Empty since all are system reset for retention flops */
}


/*******************************************************************************
* Function Name: CMP_2_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the current user configuration.
*
* Parameters:
*  void
*
* Return:
*  void
*
********************************************************************************/
void CMP_2_RestoreConfig(void) 
{
    /* Empty since all are system reset for retention flops */    
}


/*******************************************************************************
* Function Name: CMP_2_Sleep
********************************************************************************
*
* Summary:
*  Stop and Save the user configuration
*
* Parameters:
*  void:
*
* Return:
*  void
*
* Global variables:
*  CMP_2_backup.enableState:  Is modified depending on the enable 
*   state of the block before entering sleep mode.
*
*******************************************************************************/
void CMP_2_Sleep(void) 
{
    /* Save Comp's enable state */    
    if(CMP_2_ACT_PWR_EN == (CMP_2_PWRMGR & CMP_2_ACT_PWR_EN))
    {
        /* Comp is enabled */
        CMP_2_backup.enableState = 1u;
    }
    else
    {
        /* Comp is disabled */
        CMP_2_backup.enableState = 0u;
    }    
    
    CMP_2_Stop();
    CMP_2_SaveConfig();
}


/*******************************************************************************
* Function Name: CMP_2_Wakeup
********************************************************************************
*
* Summary:
*  Restores and enables the user configuration
*  
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  CMP_2_backup.enableState:  Is used to restore the enable state of 
*  block on wakeup from sleep mode.
*
*******************************************************************************/
void CMP_2_Wakeup(void) 
{
    CMP_2_RestoreConfig();
    
    if(CMP_2_backup.enableState == 1u)
    {
        /* Enable Comp's operation */
        CMP_2_Enable();

    } /* Do nothing if Comp was disabled before */ 
}


/* [] END OF FILE */

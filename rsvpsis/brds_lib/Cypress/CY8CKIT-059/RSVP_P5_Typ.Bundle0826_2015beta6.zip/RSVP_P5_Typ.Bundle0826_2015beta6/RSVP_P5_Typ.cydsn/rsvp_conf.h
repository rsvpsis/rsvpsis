/**
  ******************************************************************************
    @file        rsvp_conf.h
    @author      Tom Moxon
    @copyright   PatternAgents, LLC
    @brief       The include file to define the RsVpSiS configuration.
  ******************************************************************************
  */

/*-----------------------------------------------------------------------------*/
/* Define to prevent recursive inclusion                                       */
/*-----------------------------------------------------------------------------*/
#ifndef RSVP_CONF_H
#define RSVP_CONF_H

/* Define to support C++ */
#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */
	
/*-----------------------------------------------------------------------------*/
/* Include Files                                                               */
/*-----------------------------------------------------------------------------*/
#include <project.h>
#include <rsvp_types.h>

/** @addtogroup rsvp_conf rsvp_conf
  * @{
  */

/*-----------------------------------------------------------------------------*/
/* Exported Types                                                              */
/*-----------------------------------------------------------------------------*/
/** @defgroup rsvp_conf_Exported_Types
  * @{
  */
typedef enum {FALSE = 0, TRUE = !FALSE} bool;

/**
  * Close the Doxygen rsvp_conf__Exported_Types group.
  * @}
  */

/*-----------------------------------------------------------------------------*/
/* Exported Constants                                                          */
/*-----------------------------------------------------------------------------*/
/** @defgroup rsvp_conf_Exported_Constants
  * @{
  */

/*-----------------------------------------------------------------------------*/
/* Basic RSVP Definitions                                                      */
/*-----------------------------------------------------------------------------*/
#define RSVP_DEBUG 1 /**< Define to a nonzero value to enable debugging msgs   */
#define RSVP_TEST  1 /**< Define to a nonzero value to enable internal tests   */
#define LOW                             (0u)
#define HIGH                            (1u)

/*-----------------------------------------------------------------------------*/
/* LED definitions                                                             */
/*-----------------------------------------------------------------------------*/
#define RSVP_LED_ON             		(0u)
#define RSVP_LED_OFF            		(1u)
#define RSVP_LED_OFF_MASK       		0x00
#define RSVP_LED_1_MASK       		    0x01
#define RSVP_LED_1_CHANNUM    			0x00

#define RSVP_DELAY_1S                   ( 1000 )
#define RSVP_HIGH_IMPEDANCE             ( 0x00000000 )

/*-----------------------------------------------------------------------------*/
/* Platform CPU Constants */
/** @TODO can we init theses automatically, from creator variables?            */
/*-----------------------------------------------------------------------------*/
#if defined(__CORE_CM3_PSOC5_H__)
  #define RSVP_CPU_FREQ			        ( 72000000u )
  #define RSVP_CPU_TYPE                   "arm cortex-m3"
  #define RSVP_CPU_SOC                   "PSOC5"
#endif

#if defined(CY_BOOT_CORE_CM0_PSOC4_H)
  #define RSVP_CPU_FREQ			        ( 48000000u )
  #define RSVP_CPU_TYPE                   "arm cortex-m0"
  #define RSVP_SOC_TYPE                   "PSOC4"
#endif
#define RSVP_WDT_CMP_VALUE               (0x8000u)
#define RSVP_WDT_RESET_FLAG_ACTIVE       (0x0001u)

/*-----------------------------------------------------------------------------*/
/* enable/disable rsvp_sis system code                                         */
/*                                                                             */
#if !defined(RSVP_USE_RSVPSIS) || defined(__DOXYGEN__)
	#if !defined(RSVP_SIS_PG__DISABLED)
		#define RSVP_USE_RSVPSIS            TRUE		
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable rsvp_io code                                                 */
/*                                                                             */
#if !defined(RSVP_USE_IO) || defined(__DOXYGEN__)
	#if !defined(RSVP_IO_PG__DISABLED)
		#define RSVP_USE_IO                TRUE	
        /* RSVP_IO Channel Configuration */
		#define RSVP_IO_NULL                 0u		
        #define RSVP_IO_USBUART_1            1u
        #define RSVP_IO_UART_1               2u
        #define RSVP_IO_UART_2               3u
        #define RSVP_IO_I2C_1                7u
        #define RSVP_IO_I2C_2                8u
        #define RSVP_IO_CAN_1               12u
        #define RSVP_IO_ADC_1               32u
        #define RSVP_IO_ADC_1_NUMCHAN        1u
        #define RSVP_IO_ADC_2               40u
        #define RSVP_IO_ADC_2_NUMCHAN        1u
        #define RSVP_IO_ADC_3               48u
        #define RSVP_IO_ADC_3_NUMCHAN        1u
        #define RSVP_IO_DAC_1               56u
        #define RSVP_IO_DAC_2               57u
        #define RSVP_IO_DAC_3               58u
        #define RSVP_IO_DAC_4               59u
        #define RSVP_IO_USER_SW            252u
        #define RSVP_IO_USER_LED           253u
        #define RSVP_IO_FRU                254u
		#define RSVP_IO_MAX                255u		
        /* USBUART_1 = Channel 1, UART_1 = Channel 2 */
        #define RSVP_IO_CLI_DEFAULT          2u
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable rsvp_cli code                                                */
/*                                                                             */
#if !defined(RSVP_USE_CLI) || defined(__DOXYGEN__)
	#if !defined(RSVP_CLI_PG__DISABLED)
		#define RSVP_USE_CLI                TRUE
	#endif
#endif


/*-----------------------------------------------------------------------------*/
/* enable/disable rsvp_fru code                                                 */
/*                                                                             */
#if !defined(RSVP_USE_FRU) || defined(__DOXYGEN__)
	#if !defined(RSVP_FRU_PG__DISABLED)
		#define RSVP_USE_FRU                TRUE
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable user LED resources                                           */
/*                                                                             */
#if !defined(RSVP_USE_USER_LED) || defined(__DOXYGEN__)
	#if !defined(USER_LED_PG__DISABLED)
		#define RSVP_USE_USER_LED            TRUE		
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable user switch (input pushbutton) resources */
/*                                                                             */
#if !defined(RSVP_USE_USER_SW) || defined(__DOXYGEN__)
	#if !defined(USER_SW_PG__DISABLED)
		#define RSVP_USE_USER_SW              TRUE		
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable Bootloader Module resources                                  */
/*                                                                             */
#if !defined(RSVP_USE_BOOTLD) || defined(__DOXYGEN__)
	#if !defined(BOOTLD_PG__DISABLED)
		#define RSVP_USE_BOOTLD                TRUE		
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable TIMER_BTLDR resources                                        */
/*                                                                             */
#if !defined(RSVP_USE_TIMER_BTLDR) || defined(__DOXYGEN__)
	#if !defined(TIMER_BTLDR_PG__DISABLED)
		#define RSVP_USE_TIMER_BTLDR                TRUE		
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable USBUART_1 resources                                          */
/*                                                                             */
#if !defined(RSVP_USE_USBUART_1) || defined(__DOXYGEN__)
	#if !defined(USBUART_1_PG__DISABLED)
		#define RSVP_USE_USBUART_1                TRUE

        /* Uncomment the following line to start USBUART_1 on power-up */
		// #define RSVP_USBUART_1_UP              TRUE
		/* currently it is manually started with the RSVP_CLI command line */
		/* "RSVP_CLI> usbuart1 up " */

        #define USBUART_RX_BUFFER_LEN             (64u)
        #define USBUART_TX_BUFFER_LEN             (64u)
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable UART_1 resources                                             */
/*                                                                             */
#if !defined(RSVP_USE_UART_1) || defined(__DOXYGEN__)
	#if !defined(UART_1_PG__DISABLED)
		#define RSVP_USE_UART_1                TRUE
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable UART_2 resources                                             */
/*                                                                             */
#if !defined(RSVP_USE_UART_2) || defined(__DOXYGEN__)
	#if !defined(UART_2_PG__DISABLED)
		#define RSVP_USE_UART_2                TRUE		
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable I2C_1 resources                                              */
/*                                                                             */
#if !defined(RSVP_USE_I2C_1) || defined(__DOXYGEN__)
	#if !defined(I2C_1_PG__DISABLED)
		#define RSVP_USE_I2C_1                TRUE		
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable I2C_2 resources                                              */
/*                                                                             */
#if !defined(RSVP_USE_I2C_2) || defined(__DOXYGEN__)
	#if !defined(I2C_2_PG__DISABLED)
		#define RSVP_USE_I2C_2                TRUE		
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable CAN_1 resources                                             */
/*                                                                             */
#if !defined(RSVP_USE_CAN_1) || defined(__DOXYGEN__)
	#if !defined(CAN_1_PG__DISABLED)
		#define RSVP_USE_CAN_1                TRUE
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable TIMER_1 resources                                            */
/*                                                                             */
#if !defined(RSVP_USE_TIMER_1) || defined(__DOXYGEN__)
	#if !defined(TIMER_1_PG__DISABLED)
		#define RSVP_USE_TIMER_1                TRUE		
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable TIMER_2 resources                                            */
/*                                                                             */
#if !defined(RSVP_USE_TIMER_2) || defined(__DOXYGEN__)
	#if !defined(TIMER_2_PG__DISABLED)
		#define RSVP_USE_TIMER_2                TRUE		
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable TIMER_3 resources                                            */
/*                                                                             */
#if !defined(RSVP_USE_TIMER_3) || defined(__DOXYGEN__)
	#if !defined(TIMER_3_PG__DISABLED)
		#define RSVP_USE_TIMER_3                TRUE		
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable TIMER_4 resources                                            */
/*                                                                             */
#if !defined(RSVP_USE_TIMER_4) || defined(__DOXYGEN__)
	#if !defined(TIMER_4_PG__DISABLED)
		#define RSVP_USE_TIMER_4                TRUE		
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable SysTick resources                                             */
/*                                                                             */
#if !defined(RSVP_USE_SYSTICK) || defined(__DOXYGEN__)
	#if !defined(SYSTICK_PG__DISABLED)
		#define RSVP_USE_SYSTICK                TRUE		
		#define RSVP_SYSTICK_TYPE               "arm cortex-m0"		
        #define RSVP_SYSTICK_FREQ			    ( 1000u )
        #define RSVP_SYSTICK_NVIC			    ( 15 )
        #define RSVP_SYSTICK_CONFIG			    ( RSVP_CPU_FREQ / RSVP_SYSTICK_FREQ )
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable LVDT_1 resources                                             */
/*                                                                             */
#if !defined(RSVP_USE_LVDT_1) || defined(__DOXYGEN__)
	#if !defined(LVDT_1_PG__DISABLED)
		#define RSVP_USE_LVDT_1             TRUE		
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable WDT_1 resources                                              */
/*                                                                             */
#if !defined(RSVP_USE_WDT_1) || defined(__DOXYGEN__)
	#if !defined(WDT_1_PG__DISABLED)
		#define RSVP_USE_WDT_1                TRUE		
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/*  emulated EEPROM / IPMI FRU flash memory block                              */
/*                                                                             */
#if !defined(RSVP_USE_EEPROM_1) || defined(__DOXYGEN__)
	#if !defined(EEPROM_1_PG__DISABLED)
		#define RSVP_USE_EEPROM_1           TRUE		
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/*  CapSense Component                                                         */
/*                                                                             */
#if !defined(RSVP_USE_CAPSENSE_1) || defined(__DOXYGEN__)
	#if !defined(CAPSENSE_1_PG__DISABLED)
		#define RSVP_USE_CAPSENSE_1           TRUE		
        #define RSVP_IO_CAPSENSE_1            251u
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable Die Temperature Sensor resources   DIETEMP                   */
/*                                                                             */
#if !defined(RSVP_USE_DIETEMP_1) || defined(__DOXYGEN__)
	#if !defined(DIETEMP_1_PG__DISABLED)
		#define RSVP_USE_DIETEMP_1            TRUE
        #define RSVP_IO_DIETEMP_1            250u
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable ADC resources                                                */
/*                                                                             */
#if !defined(RSVP_USE_ADC_1) || defined(__DOXYGEN__)
	#if !defined(ADC_1_PG__DISABLED)
		#define RSVP_USE_ADC_1                TRUE
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable ADC resources                                                */
/*                                                                             */
#if !defined(RSVP_USE_ADC_2) || defined(__DOXYGEN__)
	#if !defined(ADC_2_PG__DISABLED)
		#define RSVP_USE_ADC_2                TRUE
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable ADC resources                                                */
/*                                                                             */
#if !defined(RSVP_USE_ADC_3) || defined(__DOXYGEN__)
	#if !defined(ADC_3_PG__DISABLED)
		#define RSVP_USE_ADC_3                TRUE
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable DAC_1 resources                                              */
/*                                                                             */
#if !defined(RSVP_USE_DAC_1) || defined(__DOXYGEN__)
	#if !defined(DAC_1_PG__DISABLED)
		#define RSVP_USE_DAC_1                TRUE
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable DAC_2 resources                                              */
/*                                                                             */
#if !defined(RSVP_USE_DAC_2) || defined(__DOXYGEN__)
	#if !defined(DAC_2_PG__DISABLED)
		#define RSVP_USE_DAC_2                TRUE
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable OPAMP_1 resources                                            */
/*                                                                             */
#if !defined(RSVP_USE_OPAMP_1) || defined(__DOXYGEN__)
	#if !defined(OPAMP_1_PG__DISABLED)
		#define RSVP_USE_OPAMP_1                TRUE
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable OPAMP_2 resources                                            */
/*                                                                             */
#if !defined(RSVP_USE_OPAMP_2) || defined(__DOXYGEN__)
	#if !defined(OPAMP_2_PG__DISABLED)
		#define RSVP_USE_OPAMP_2                TRUE
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable CMP_1 resources                                              */
/*                                                                             */
#if !defined(RSVP_USE_CMP_1) || defined(__DOXYGEN__)
	#if !defined(CMP_1_PG__DISABLED)
		#define RSVP_USE_CMP_1                TRUE
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable CMP_2 resources                                              */
/*                                                                             */
#if !defined(RSVP_USE_CMP_2) || defined(__DOXYGEN__)
	#if !defined(CMP_2_PG__DISABLED)
		#define RSVP_USE_CMP_2                TRUE
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable SPWM (Software PWM) resources                                */
/*                                                                             */
#if !defined(RSVP_USE_SPWM_1) || defined(__DOXYGEN__)
	#if !defined(RSVP_SPWM_PG__DISABLED)
		#define RSVP_USE_SPWM_1                TRUE		
	#endif
#endif


/**
  * Close the Doxygen rsvp_conf_Exported_Constants group.
  * @}
  */

/*-----------------------------------------------------------------------------*/
/* Exported Macros                                                             */
/*-----------------------------------------------------------------------------*/
/** @defgroup rsvp_conf_Exported_Macros
  * @{
  */

/**
  * Close the Doxygen rsvp_conf_Exported_Macros group.
  * @}
  */

/*-----------------------------------------------------------------------------*/
/* Exported Variable Declarations                                              */
/*-----------------------------------------------------------------------------*/
/** @defgroup rsvp_conf_Exported_Variables
  * @{
  */

/** Platform Globals */

/**
  * Close the Doxygen rsvp_conf_Exported_Variables group.
  * @}
  */

/*-----------------------------------------------------------------------------*/
/* Exported Function Declarations                                              */
/*-----------------------------------------------------------------------------*/
/** @defgroup rsvp_conf_Exported_Functions
  * @{
  */

/**
  * Close the Doxygen rsvp_conf_Exported_Functions group.
  * @}
  */

/*-----------------------------------------------------------------------------*/
/* End of the C bindings section for C++ compilers.                            */
/*-----------------------------------------------------------------------------*/
#ifdef __cplusplus
}
#endif

#endif /* RSVP_CONF_H */

/*-----------------------------------------------------------------------------*/
/**
  * Close the Doxygen rsvp_conf group.
  *    @}
*/
/*****************************************************************************
# Copyright:	(C) 2013-2015 by PatternAgents,LLC. All rights reserved.
#*****************************************************************************
# RSVP-SIS Licensing Model:
# 
# RSVP-SIS uses the increasingly popular business model called 
# "Dual Licensing" in which both the open source software distribution 
# mechanism and traditional commercial software distribution models 
# are combined.
# 
# Open Source Projects:
# 
# If you are developing and distributing open source applications 
# under the GNU General Public License version 3 (GPLv3), 
# as published by the Free Software Foundation, then you are free 
# to use the RSVP-SIS software under the GPLv3 license. Please note 
# that GPLv3 Section 2(b) requires that all modifications to the 
# original code as well as all Derivative Works must also be 
# released under the terms of the GPLv3 open source license.
# 
# Closed Source Projects:
# 
# If you are developing and distributing traditional closed source 
# applications, you must purchase a RSVP-SIS commercial use license, 
# which is specifically designed for users interested in retaining 
# the proprietary status of their code. All RSVP-SIS commercial licenses 
# expressly supersede the GPLv3 open source license. This means that 
# when you license the RSVP-SIS software under a commercial license, 
# you specifically do not use the software under the open source 
# license and therefore you are not subject to any of its terms.
#
# Commercial licensing options available on the RSVP-SIS Website at : 
#	http://www.rsvpsis.org/licensing/
#
#*****************************************************************************
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, 
# BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
# COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED 
# AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE 
# USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
/* End of File : rsvp_conf.h */

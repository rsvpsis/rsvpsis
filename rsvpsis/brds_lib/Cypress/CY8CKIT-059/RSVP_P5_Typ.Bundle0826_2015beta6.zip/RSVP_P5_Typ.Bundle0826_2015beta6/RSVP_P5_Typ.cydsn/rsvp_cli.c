/**
 ******************************************************************************
    @file        rsvp_cli.c
    @author      Tom Moxon
    @copyright   PatternAgents, LLC
    @brief       This file provides the rsvp_cli Command Line Interface routines
    @section     rsvp_cli_intro rsvp_cli Command Line Interface routines
    @par	
    @section    rsvp_cli_theory Theory of Operation
    @par
    theory \n
	@par
    more \n

 ******************************************************************************
*/
/*-----------------------------------------------------------------------------*/
/* Include Files                                                               */
/*-----------------------------------------------------------------------------*/
#include <rsvp.h>

/*-----------------------------------------------------------------------------*/
/** @defgroup rsvp_cli rsvp_cli
  * @{
  */

#if defined(RSVP_USE_CLI)
/*-----------------------------------------------------------------------------*/
/* Global variables                                                            */
/*-----------------------------------------------------------------------------*/
const tRsVpCmdArray vCommandTable[] = 
{
	{"?",		rsvp_CLI_CmdMenu,		 "      : Show list of CLI Commands"},
	{"echo",	rsvp_CLI_CmdEcho,		 "   : echo - Echo whatever command line you type (i.e. argv[])"},	
	{"console",	rsvp_CLI_CmdConsole,	 ": console X - switch console to channel X"},	
    {"wire",	rsvp_CLI_CmdWire,		 "   : wire X Y - connect channel X and Y"},	
	{"adc",	    rsvp_CLI_CmdADC,		 "    : adc # ? - get ADC # reading"},	
	{"usb",	    rsvp_CLI_CmdUSB,		 "    : usb # ? - get USB # status"},
	{"uart",	rsvp_CLI_CmdUART,		 "   : uart # ? - get UART # status"},	
	{"temp",	rsvp_CLI_CmdDIETEMP,     "   : temp - get the die temperature"},	
	{"bootld",	rsvp_CLI_CmdBOOTLD,      " : bootld - start the bootloader"},	
	{"test",	rsvp_CLI_CmdTest,		 "   : test TYPE - invoke custom test TYPE"},	
    {0, 0, 0 }
};

/* variable for number of commands (MAX=255) in command table (in FLASH)    */
rsvp_u8_t bNumCmd = sizeof(vCommandTable)/sizeof(*vCommandTable);
char StrBuf[64] = "                                                      ";
rsvp_u8_t StrBufLen;

rsvp_u8_t rsvp_CLI_Channel = RSVP_IO_CLI_DEFAULT;
rsvp_u8_t rsvp_CLI_NewPrompt = TRUE;
rsvp_u8_t rsvp_CLI_Enable = TRUE;

/*****************************************************************************
* RSVP Command Line Interface API Defintions
*****************************************************************************/
/*-----------------------------------------------------------------------------*/
/**
  * @fn         rsvp_RetCode_t rsvp_CLI_CmdProcess(char *pcCmdBuffer)
  * @brief      Process a command line string
  * @param      char *pcCmdBuffer - String buffer with command line
  * @retval     rsvp_RetCode_t
  */
rsvp_RetCode_t
rsvp_CLI_CmdProcess(char *pcCmdBuffer)
{
    static char *argv[RSVP_CLI_ARGC_MAX + 1];
    char *pcChar;
    int argc;
    int bFoundArgv = 1;
    const tRsVpCmdArray *pCmdEntry;
    rsvp_RetCode_t RetCode;
	
    /* point to the first character of the command line buffer */
    pcChar = pcCmdBuffer;
    /* reset the argument counter */
    argc = 0;
    
    /* loop through the command line buffer until the null terminator is encountered */
    while(*pcChar)
    {
        // If there is a space, then replace it with a zero, and set the flag
        // to search for the next argument.
        if(*pcChar == ' ')
        {
            *pcChar = 0;
            bFoundArgv = 1;
        }

        //
        // Otherwise it is not a space, so it must be a character that is part
        // of an argument.
        //
        else
        {
            //
            // If bFoundArgv is set, then that means we are looking for the start
            // of the next argument.
            //
            if(bFoundArgv)
            {
                //
                // As long as the maximum number of arguments has not been
                // reached, then save the pointer to the start of this new arg
                // in the argv array, and increment the count of args, argc.
                //
                if(argc < RSVP_CLI_ARGC_MAX)
                {
                    argv[argc] = pcChar;
                    argc++;
                    bFoundArgv = 0;
                }

                //
                // The maximum number of arguments has been reached so return
                // the error.
                //
                else
                {
					rsvp_CLI_NewPrompt = TRUE;
                    return(RSVP_ILL_ARG);
                }
            }
        }

        //
        // Advance to the next character in the command line.
        //
        pcChar++;
    }

    //
    // If one or more arguments was found, then process the command.
    //
    if(argc)
    {
        //
        // Start at the beginning of the command table, to look for a matching
        // command.
        //
        pCmdEntry = &vCommandTable[0];

        //
        // Search through the command table until a null command string is
        // found, which marks the end of the table.
        //
        while(pCmdEntry->pcRsVpCmdName)
        {
            //
            // If this command entry command string matches argv[0], then call
            // the function for this command, passing the command line
            // arguments.
            //
            if(!strcmp(argv[0], pCmdEntry->pcRsVpCmdName))
            {
                RetCode = pCmdEntry->pfnRsVpFunction(argc, argv);
				rsvp_CLI_NewPrompt = TRUE;
				return(RetCode);
            }

            //
            // Not found, so advance to the next entry.
            //
            pCmdEntry++;
        }
    }

    //
    // Fall through to here means that no matching command was found, so return
    // an error.
    //
    rsvp_CLI_CmdError(argc, argv);
    return(RSVP_ERR_PLATFORM);
}


/*****************************************************************************
* RSVP Command Line Interface - Command API Defintions
*****************************************************************************/
rsvp_RetCode_t 
rsvp_CLI_CmdMenu(int argc, char *argv[]) {
    (void) (argc);
    (void) (*argv);
	
        /* Count of commands tested */
		rsvp_u8_t cmdcnt;
        
		rsvp_io_PutString(rsvp_CLI_Channel,  " \r\n");
		rsvp_io_PutString(rsvp_CLI_Channel,  "RSVP CLI Command Menu\r\n");
		rsvp_io_PutString(rsvp_CLI_Channel,  "---------------------\r\n");
		for ( cmdcnt = 0; cmdcnt < bNumCmd; cmdcnt++ ) 
		{
    		rsvp_io_PutString(rsvp_CLI_Channel,  (char *) vCommandTable[cmdcnt].pcRsVpCmdName);
            rsvp_io_PutString(rsvp_CLI_Channel,  "    ");
    		rsvp_io_PutString(rsvp_CLI_Channel,  (char *) vCommandTable[cmdcnt].pcRsVpCmdHelp);
			rsvp_io_PutString(rsvp_CLI_Channel,  " \r\n");
		}	
		rsvp_io_PutString(rsvp_CLI_Channel,  " \r\n");
		return(RSVP_SUCCESS);
}

rsvp_RetCode_t
rsvp_CLI_CmdError(int argc, char *argv[])
{
    (void) (argc);
    (void) (*argv);
	    /* Unrecognized Command Line Entered */
		rsvp_io_PutString(rsvp_CLI_Channel,  " \r\n");
		rsvp_io_PutString(rsvp_CLI_Channel,  "RSVP_CLI : Unrecognized CLI Command - use ? for help \r\n");
		rsvp_io_PutString(rsvp_CLI_Channel,  " \r\n");
		rsvp_CLI_NewPrompt = TRUE;
		return(RSVP_SUCCESS);
}

rsvp_RetCode_t
rsvp_CLI_CmdConsole(int argc, char *argv[])
{
	rsvp_u8_t  Console_ChanNum = 1;

	if ((argc < 2 ) || (strcmp( "?", argv[1] ) == 0)) {
	   rsvp_CLI_CmdMenu(argc, argv);
	} else {
	   Console_ChanNum = (rsvp_u8_t) atoi(argv[1]);
	}
	if (Console_ChanNum == 0) {
       rsvp_CLI_NewPrompt = FALSE;
       rsvp_CLI_Enable = FALSE;
	   Console_ChanNum = 1;
	} else if (Console_ChanNum == 255) {
       rsvp_CLI_NewPrompt = FALSE;
       rsvp_CLI_Enable = FALSE;
	   Console_ChanNum = 1;
	} else if (Console_ChanNum > 2) {
	  Console_ChanNum = 1;
	}
    ENTER_CRITICAL_SECTION( );
	rsvp_CLI_Channel = Console_ChanNum;
    EXIT_CRITICAL_SECTION( );
	return(RSVP_SUCCESS);
}

rsvp_RetCode_t
rsvp_CLI_CmdEcho(int argc, char *argv[])
{
	rsvp_u8_t i;

	rsvp_io_PutString(rsvp_CLI_Channel,  " \r\n");
	for (i=0; i<argc; i++)
	{
		rsvp_io_PutString(rsvp_CLI_Channel,  argv[i]);
		rsvp_io_PutString(rsvp_CLI_Channel,  " \r\n");
	}
	rsvp_io_PutString(rsvp_CLI_Channel,  " \r\n");
	return(RSVP_SUCCESS);
}

char* rsvp_CLI_itoa(char* result, int value, int base) 
{
		/* test if the base parameter is valid */
		if (base < 2 || base > 36) { *result = '\0'; return result; }
	
		char* ptr = result, *ptr1 = result, tmp_char;
		int tmp_value;
	
		do {
			tmp_value = value;
			value /= base;
			*ptr++ = "zyxwvutsrqponmlkjihgfedcba9876543210123456789abcdefghijklmnopqrstuvwxyz" [35 + (tmp_value - value * base)];
		} while ( value );
	
		/* insert negative sign if applicable */
		if (tmp_value < 0) *ptr++ = '-';
		*ptr-- = '\0';
		while(ptr1 < ptr) {
			tmp_char = *ptr;
			*ptr--= *ptr1;
			*ptr1++ = tmp_char;
		}
		return result;
}

rsvp_RetCode_t
rsvp_CLI_CmdWire(int argc, char *argv[])
{
    rsvp_u8_t X, Y, X_len, Y_len, X_buf, Y_buf;
    rsvp_u8_t wire_break = 1;
    
    if (argc > 2 ) {
	  X = (rsvp_u8_t) atoi(argv[1]);
	  Y = (rsvp_u8_t) atoi(argv[2]);
	  rsvp_io_PutString(rsvp_CLI_Channel,  "\r\n Wiring Channel ");
	  rsvp_io_PutString(rsvp_CLI_Channel,  argv[1]);
	  rsvp_io_PutString(rsvp_CLI_Channel,  " to Channel  ");
	  rsvp_io_PutString(rsvp_CLI_Channel,  argv[2]);
	  rsvp_io_PutString(rsvp_CLI_Channel,  " : Break to Escape\r\n");
    
      /* wire the channels until a break (SW1) is detected */
      while (wire_break != 0) {
          X_len = rsvp_io_GetRxBufferSize(X);
          if (X_len != 0) {
              X_buf = rsvp_io_GetChar(X);
              rsvp_io_PutChar(Y, X_buf);
          }
          Y_len = rsvp_io_GetRxBufferSize(Y);
          if (Y_len != 0) {
              Y_buf = rsvp_io_GetChar(Y);
              rsvp_io_PutChar(X, Y_buf);
          }
          wire_break = USER_SW_1_Read();
      }
	}
	return(RSVP_SUCCESS);
}

rsvp_RetCode_t
rsvp_CLI_CmdUSB(int argc, char *argv[])
{
  (void)argc;
  (void)argv;

  #if defined(__CORE_CM3_PSOC5_H__)
    rsvp_u8_t  USB_devnum = 1;
    if ((argc < 3 ) || (strcmp( "?", argv[1]) == 0) || (strcmp( "?", argv[2])==0)) {
		rsvp_io_PutString(rsvp_CLI_Channel,  "\r\n USB Channel = 1,  State = ");
		if (usbuart_1_if_status == 0) {
  		  rsvp_io_PutString(rsvp_CLI_Channel,  "Down :-( \r\n\r\n");
        } else {
		  rsvp_io_PutString(rsvp_CLI_Channel,  "UP! \r\n\r\n");
        }
        return(RSVP_SUCCESS);
    } else {
        USB_devnum = (rsvp_u8_t) atoi(argv[1]);
        if (USB_devnum != 1) {
         rsvp_io_PutString(rsvp_CLI_Channel, "\r\nError : Only One (1) USBUART available!\r\n");            
         return(RSVP_FAIL);
        }
    }
    if ((argc == 3) && (strcmp( "up", argv[2] ) == 0)) {
      #if defined(RSVP_USE_USBUART_1)	
          //rsvp_io_PutString(rsvp_CLI_Channel, "Starting USBUART_1 Interface...");
          rsvp_io_PutString(rsvp_CLI_Channel, "\r\n  USBUART_1 CDC Interface : Starting ...\r\n");
	      /* Start the Component and initialize */
          USBUART_1_Start(0u, USBUART_1_5V_OPERATION);
          /* Wait for Device to enumerate */
          /* @TODO : add SW1 or timer breakout */
          while(!USBUART_1_GetConfiguration());
          /*  initializes the CDC interface to be ready to receive data from the PC */
          USBUART_1_CDC_Init();
          CyDelay(100);
          usbuart_1_if_status = 1u ; /* interface is up */
          rsvp_io_PutString(rsvp_CLI_Channel, "  USBUART_1 CDC Interface : Now Up!\r\n");
          CyDelay(100);
          rsvp_io_PutString(rsvp_CLI_Channel, "\r\n");
      #endif
    } else if ((argc == 3) && (strcmp( "down", argv[2] ) == 0)) {
        #if defined(RSVP_USE_USBUART_1)
          USBUART_1_Stop();
        #endif
    }
  #else
    rsvp_io_PutString(rsvp_CLI_Channel,  "\r\n Sorry, no USB yet on PSoC4, use PSoC5... \r\n\r\n");
  #endif
  return(RSVP_SUCCESS);
}

rsvp_RetCode_t
rsvp_CLI_CmdUART(int argc, char *argv[])
{
    #define RSVP_MAX_UARTS 2
    rsvp_u8_t  UART_ChanNum = 0;
 	char str_tmp_Buffer[10] = "unknown!";

    if ((argc < 3 ) || (strcmp( "?", argv[1]) == 0) || (strcmp( "?", argv[2])==0)) {
      #if defined(RSVP_USE_UART_1)
        rsvp_io_PutString(rsvp_CLI_Channel, "\r\nUART_1 is UP!\r\n");
      #endif
      #if defined(RSVP_USE_UART_2)
        rsvp_io_PutString(rsvp_CLI_Channel, "\r\nUART_2 is UP!\r\n");
      #endif
      rsvp_io_PutString(rsvp_CLI_Channel, "\r\n");
      return(RSVP_SUCCESS);
	} else {
	  UART_ChanNum = (rsvp_u8_t) atoi(argv[1]);
      if (UART_ChanNum > RSVP_MAX_UARTS) {
        UART_ChanNum = 0;
      }
	} 
    
    if ((argc > 2) && (strcmp( "test", argv[2] ) == 0)) {
    	rsvp_io_PutString(UART_ChanNum+1, "\n\ruart channel #");
		rsvp_CLI_itoa(str_tmp_Buffer, UART_ChanNum, 10); 
    	rsvp_io_PutString(UART_ChanNum+1, str_tmp_Buffer);
        rsvp_io_PutString(UART_ChanNum+1, " : 0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ \r\n\r\n");
    }
    
	return(RSVP_SUCCESS);
}

rsvp_RetCode_t
rsvp_CLI_CmdADC(int argc, char *argv[])
{
    rsvp_u8_t  ADC_ChanNum  = 0;
    rsvp_s16_t ADC_Counts   = 0;
    rsvp_s16_t ADC_mVolts   = 0;
	char str_tmp_Buffer[10] = "unknown!";

	/* Test Argc (number of arguments) */
    if (argc < 3) {
        rsvp_io_PutString(rsvp_CLI_Channel,  "\r\nusage: ADC channel# ?\r\n\r\n");
		return(RSVP_SUCCESS);
	}
    /* @TODO : Add ADC_1/2/3 guards  */
	ADC_ChanNum = (rsvp_u8_t) atoi(argv[1]);
    if (ADC_ChanNum >= (RSVP_IO_ADC_1_NUMCHAN + RSVP_IO_ADC_2_NUMCHAN + RSVP_IO_ADC_3_NUMCHAN )) {
        //return(RSVP_ILL_ARG);
        return(RSVP_SUCCESS);
    }
    
    if ((argc == 3) && (strcmp( "?", argv[2] ) == 0)) {
		rsvp_io_PutString(rsvp_CLI_Channel,  "\r\nADC Channel = ");
		rsvp_io_PutString(rsvp_CLI_Channel,  argv[1]);
		rsvp_io_PutString(rsvp_CLI_Channel,  ",  ADC Data = ");
        if (ADC_ChanNum <= RSVP_IO_ADC_1_NUMCHAN - 1 ) {
          #if defined(RSVP_USE_ADC_1)
            ADC_Counts = adc_1_data[ADC_ChanNum];
            #if defined(CY_BOOT_CORE_CM0_PSOC4_H)
		      ADC_mVolts = ADC_1_CountsTo_mVolts(ADC_ChanNum, adc_1_data[ADC_ChanNum]);
            #else
		      ADC_mVolts = ADC_1_CountsTo_mVolts(adc_1_data[ADC_ChanNum]);
            #endif
          #endif
        } else if (ADC_ChanNum <= RSVP_IO_ADC_1_NUMCHAN + RSVP_IO_ADC_2_NUMCHAN -1 ) {
          #if defined(RSVP_USE_ADC_2)
            ADC_Counts = adc_2_data[ADC_ChanNum];
            #if defined(CY_BOOT_CORE_CM0_PSOC4_H)
		      ADC_mVolts = ADC_2_CountsTo_mVolts(ADC_ChanNum, adc_2_data[ADC_ChanNum]);
            #else
		      ADC_mVolts = ADC_2_CountsTo_mVolts(adc_2_data[ADC_ChanNum]);
            #endif          
           #endif
        } else if (ADC_ChanNum <= RSVP_IO_ADC_1_NUMCHAN + RSVP_IO_ADC_2_NUMCHAN + RSVP_IO_ADC_3_NUMCHAN - 1) {
           #if defined(RSVP_USE_ADC_3)
            ADC_Counts = adc_3_data[ADC_ChanNum];
           #if defined(CY_BOOT_CORE_CM0_PSOC4_H)
		      ADC_mVolts = ADC_3_CountsTo_mVolts(ADC_ChanNum, adc_3_data[ADC_ChanNum]);
            #else
		      ADC_mVolts = ADC_3_CountsTo_mVolts(adc_3_data[ADC_ChanNum]);
            #endif
          #endif
        }
        rsvp_CLI_itoa(str_tmp_Buffer, ADC_Counts, 10); 
		rsvp_io_PutString(rsvp_CLI_Channel,  str_tmp_Buffer);
        rsvp_io_PutString(rsvp_CLI_Channel,  " Raw Counts,  ");
        rsvp_CLI_itoa(str_tmp_Buffer, ADC_mVolts, 10); 
		rsvp_io_PutString(rsvp_CLI_Channel,  str_tmp_Buffer);
		rsvp_io_PutString(rsvp_CLI_Channel,  " milliVolts\r\n\r\n");
    }
	return(RSVP_SUCCESS);
}

rsvp_RetCode_t
rsvp_CLI_CmdDIETEMP(int argc, char *argv[])
{
   (void)argc;
   (void)argv;

 	char str_tmp_Buffer[10] = "unknown!";
	rsvp_io_PutString(rsvp_CLI_Channel,  "\r\nDie Temperature = ");
    #if defined(RSVP_USE_DIETEMP_1)	
      /* get starting temperature */
      #if defined(__CORE_CM3_PSOC5_H__)
        rsvp_dietemp_1_status = DIETEMP_1_GetTemp(&rsvp_dietemp_1_data);
      #endif
    #endif
      #if defined(CY_BOOT_CORE_CM0_PSOC4_H)
        int32 ADCCountsCorrected;
        /* Note Bene : vref is VDDA (5000mV) */
        ADCCountsCorrected = (int32)((adc_1_data[ADC_1_TOTAL_CHANNELS_NUM - 1]) * 5000/1024 ) ;       
        rsvp_dietemp_1_data = DIETEMP_1_CountsTo_Celsius(ADCCountsCorrected);
      #endif
    
	rsvp_CLI_itoa(str_tmp_Buffer, rsvp_dietemp_1_data, 10); 
	rsvp_io_PutString(rsvp_CLI_Channel,  str_tmp_Buffer);
    rsvp_io_PutString(rsvp_CLI_Channel,  " degrees C \r\n\r\n");
	return(RSVP_SUCCESS);
}

rsvp_RetCode_t
rsvp_CLI_CmdBOOTLD(int argc, char *argv[])
{
    (void)argc;
    (void)argv;
    rsvp_io_PutString(rsvp_CLI_Channel, "\r\n boot loader : entering the boot loader program for firmware update!");	
    rsvp_io_PutString(rsvp_CLI_Channel, "\r\n boot loader : (exit the terminal app and start the Bootloader Host app!) \r\n\r\n");	
    CyDelay(500);
    Bootloadable_Load();
	return(RSVP_SUCCESS);
}

rsvp_RetCode_t
rsvp_CLI_CmdTest(int argc, char *argv[])
{
	if ((argc < 2 ) || (strcmp( "?", argv[1] ) == 0)) {
      rsvp_CLI_CmdMenu(argc, argv);
	} else if ((strcmp( "TYPE", argv[1] ) == 0)) {
      /* PLACE YOUR OWN CODE HERE ... */
      rsvp_io_PutString(rsvp_CLI_Channel, "\r\ntest TYPE : add your own tests here...\r\n\r\n");
	} else if ((strcmp( "TYPE2", argv[1] ) == 0)) {
      /* PLACE MORE OF YOUR OWN CODE HERE ... */
      rsvp_io_PutString(rsvp_CLI_Channel, "\r\ntest TYPE2 : add your own tests here...\r\n\r\n");
    } 
	return(RSVP_SUCCESS);
}

void rsvp_CLI_Update(void) 
{
  rsvp_u8_t StringLen;
	
	if (rsvp_CLI_Enable == TRUE) {
      /* send the command line prompt */
	  if (rsvp_CLI_NewPrompt == TRUE ) {
        rsvp_io_PutString(rsvp_CLI_Channel, "RSVP_CLI> ");
	    rsvp_CLI_NewPrompt = FALSE;
	  }
      /* Block until a command is entered and returned */
      StringLen = rsvp_io_GetString(rsvp_CLI_Channel, &StrBuf[0], 64);
	
      /* Pass the line to the Command Line Interpreter */
      /* if there more than a zero length - i.e. more than a delimiter? */
      if( StringLen != 0 ) 
	  {
		/* parse and execute the command line */
        rsvp_CLI_CmdProcess(&StrBuf[0]);
	  }
	}
}
#endif
/*-----------------------------------------------------------------------------*/
/**
  * Close the Doxygen main group.
  *    @}
*/
/*****************************************************************************
# Copyright:	(C) 2013-2015 by PatternAgents,LLC. All rights reserved.
#*****************************************************************************
# RSVP-SIS Licensing Model:
# 
# RSVP-SIS uses the increasingly popular business model called 
# "Dual Licensing" in which both the open source software distribution 
# mechanism and traditional commercial software distribution models 
# are combined.
# 
# Open Source Projects:
# 
# If you are developing and distributing open source applications 
# under the GNU General Public License version 3 (GPLv3), 
# as published by the Free Software Foundation, then you are free 
# to use the RSVP-SIS software under the GPLv3 license. Please note 
# that GPLv3 Section 2(b) requires that all modifications to the 
# original code as well as all Derivative Works must also be 
# released under the terms of the GPLv3 open source license.
# 
# Closed Source Projects:
# 
# If you are developing and distributing traditional closed source 
# applications, you must purchase a RSVP-SIS commercial use license, 
# which is specifically designed for users interested in retaining 
# the proprietary status of their code. All RSVP-SIS commercial licenses 
# expressly supersede the GPLv3 open source license. This means that 
# when you license the RSVP-SIS software under a commercial license, 
# you specifically do not use the software under the open source 
# license and therefore you are not subject to any of its terms.
#
# Commercial licensing options available on the RSVP-SIS Website at : 
#	http://www.rsvpsis.org/licensing/
#
#*****************************************************************************
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, 
# BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
# COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED 
# AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE 
# USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
/* End of File : rsvp_cli.c */
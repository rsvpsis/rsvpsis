/**
 ******************************************************************************
    @file
    @author      Tom Moxon
    @copyright   PatternAgents, LLC
    @brief       This file provides the rsvp_platform hardware porting/mapping routines
    @section     rsvp_platform_intro rsvp_platform hardware porting/mapping
    @par
    The "rsvp_platform" encapsulates the hardware platform into a number of simple APIs. \n
    Each component in the platform, like UARTs, ADC's, etc. have their own simple HAL API. \n
    The "rsvp_platform" HAL API uses the component instance name as a prefix to it's functions, \n
	for example, "UART_1_Start();" or "UART_1_Stop();" \n 
    @par
    Using the PSoC Creator System, most of these API's are auto-generated. \n
	The remaining "wrapper" and high level "rsvp_platform" API's are contained in this file. \n
    @section    rsvp_platform_theory Theory of Operation
    @par
    theory \n
	@par
    more \n

 ******************************************************************************
*/

/*-----------------------------------------------------------------------------*/
/* Include Files                                                               */
/*-----------------------------------------------------------------------------*/
#include <rsvp.h>

/*-----------------------------------------------------------------------------*/
/** @defgroup rsvp_platform rsvp_platform
  * @{
  */

/*-----------------------------------------------------------------------------*/
/* Global variables                                                            */
/*-----------------------------------------------------------------------------*/


/*-----------------------------------------------------------------------------*/
/* Platform Functions                                                          */
/*-----------------------------------------------------------------------------*/
/**
  * @fn         void rsvp_platform_Start(void)
  * @brief      called to initialize all of the rsvp_platform hardware systems
  * @param      None.
  * @retval     rsvp_RetCode_t
  */
rsvp_RetCode_t
rsvp_platform_Start(void)
{
	#if defined(RSVP_USE_USER_LED)	
      USER_LED_1_Write(RSVP_LED_OFF);
    #endif

	#if defined(RSVP_USE_USER_SW)
	  // USER_SW_1_ClearInterrupt();
      USER_SW_1_IRQ_StartEx(USER_SW_1_IRQ_Handler);
	  USER_SW_1_IRQ_Enable();
	  user_sw_1_irq_flag = 0;
    #endif

    #if defined(RSVP_USE_TIMER_BTLDR)	
	  /* Start TIMER_1 */	
	  TIMER_BTLDR_Start();
      TIMER_BTLDR_IRQ_ClearPending();
      TIMER_BTLDR_IRQ_StartEx(TIMER_BTLDR_IRQ_Handler);
    #endif

    #if defined(RSVP_USE_UART_1)	
	  /* Start the Primary UART (usually connected to USB host for CLI) */
	  UART_1_Start();
      UART_1_IRQ_StartEx(UART_1_IRQ_Handler);
	#endif

	#if defined(RSVP_USE_UART_2)	
	  /* Start the Secondary UART Serial Line Component and enable Interrupt */	
	  UART_2_Start();
      UART_2_RX_IRQ_StartEx(UART_2_RX_IRQ_Handler);
      UART_2_TX_IRQ_StartEx(UART_2_TX_IRQ_Handler);
    #endif

    #if defined(RSVP_USE_I2C_1)	
	  /* Start the Primary I2C channel */
	  I2C_1_Start();
        #if defined(RSVP_USE_FRU) 
          /* EZI2C gets mapped to IPMI FRU address space)  */
	      I2C_1_SetBuffer1(rsvp_FRU_PDU_Size, rsvp_FRU_PDU_Size, (void *) rsvp_fru_bmc);
        #endif
	#endif
	
    #if defined(RSVP_USE_I2C_2)	
	  /* Start the Primary I2C channel */
	  I2C_2_Start();
	#endif

    #if defined(RSVP_USE_CAN_1)	
	  /* Start the Primary CAN channel */
	  CAN_1_Start();
	#endif    
    
	#if defined(RSVP_USE_TIMER_1)	
	  /* Start TIMER_1 */	
	  TIMER_1_Start();
      TIMER_1_IRQ_ClearPending();
      TIMER_1_IRQ_StartEx(TIMER_1_IRQ_Handler);
    #endif
	
	#if defined(RSVP_USE_TIMER_2)	
	  /* Start TIMER_2 (Modbus Message Timer) */	
	  TIMER_2_Start();
      TIMER_2_IRQ_ClearPending();
      TIMER_2_IRQ_StartEx(TIMER_2_IRQ_Handler);
    #endif
	
	#if defined(RSVP_USE_TIMER_3)	
	  /* Start TIMER_3 */	
	  TIMER_3_Start();
      TIMER_3_IRQ_ClearPending();
      TIMER_3_IRQ_StartEx(TIMER_3_IRQ_Handler);
    #endif

	#if defined(RSVP_USE_TIMER_4)		
	  /* Start TIMER_4 */	
	  TIMER_4_Start();
      TIMER_4_IRQ_ClearPending();
      TIMER_4_IRQ_StartEx(TIMER_4_IRQ_Handler);
    #endif

	#if defined(RSVP_USE_SYSTICK)		
	  /* Start the ARM Cortex SysTick Timer */
	  SysTick_StartEx(SysTick_IRQ_Handler);
    #endif
 
	#if defined(RSVP_USE_WDT_1)
      /* WatchDog Timer/Counter */
	  WDT_1_IRQ_Start();
      WDT_1_IRQ_StartEx(WDT_1_IRQ_Handler);
      /* stores the reason we reset , was it a watchdog reset? */
      wdt_1_irq_status = CySysGetResetReason(CY_SYS_RESET_WDT);
      /* Once watchdog counter reaches match value interrupt is generated  */
      CySysWdtWriteMatch(RSVP_WDT_CMP_VALUE);
      /* Configure WDT to be 15-bit wraparound up-counter - 1 MSb is ignored */
      CySysWdtWriteIgnoreBits(1u);
      /* Start the WDT */
      CySysWdtEnable();
      /* Make sure that interrupt is forwarded to the CPU */
      CySysWdtUnmaskInterrupt();
    #endif
    
	#if defined(RSVP_USE_LVDT_1)
	  LVDT_1_IRQ_Start();
      LVDT_1_IRQ_StartEx(LVDT_1_IRQ_Handler);
    #endif

    #if defined(RSVP_USE_EEPROM_1)
	  EEPROM_1_Start();
	#endif
    
	#if defined(RSVP_USE_OPAMP_1)	
	  /* Start the Component */
      OPAMP_1_Start();
    #endif

	#if defined(RSVP_USE_OPAMP_2)	
	  /* Start the Component */
      OPAMP_2_Start();
    #endif

	
	#if defined(RSVP_USE_CMP_1)	
	  /* Start the Component and enable Interrupts */
      CMP_1_Start();
      CMP_1_IRQ_StartEx(CMP_1_IRQ_Handler);
    #endif

	#if defined(RSVP_USE_CMP_2)	
	  /* Start the Component and enable Interrupts */
      CMP_2_Start();
      CMP_2_IRQ_StartEx(CMP_2_IRQ_Handler);
    #endif

    /* Die Temperature from SPC component */
	#if defined(RSVP_USE_DIETEMP_1)	
      /* get starting temperature */
      #if defined(__CORE_CM3_PSOC5_H__)
        rsvp_dietemp_1_status = DIETEMP_1_GetTemp(&rsvp_dietemp_1_data);
      #endif
    #endif

	#if defined(RSVP_USE_ADC_1)	
	  /* Start the Analog-to-Digital Converter(ADC) Component and enable Interrupt */
      ADC_1_Start();
      
      /* if using external interrupt component, otherwise internal... */
      #if defined(CY_ISR_ADC_1_IRQ_H)
        ADC_1_IRQ_StartEx(ADC_1_IRQ_Handler);
	  #endif
	  /* Start ADC conversion */
      // #if (ADC_1_DEFAULT_CONV_MODE != ADC_1__HARDWARE_TRIGGER)
	    ADC_1_StartConvert();
      // #endif
    #endif

	#if defined(RSVP_USE_ADC_2)	
	  /* Start the Analog-to-Digital Converter(ADC) Component and enable Interrupt */
      ADC_2_Start();
    
      /* if using external interrupt component, otherwise internal... */
      // ADC_2_IRQ_StartEx(ADC_2_IRQ_Handler);
	
	  /* Start ADC conversion */
      #if (ADC_2_DEFAULT_CONV_MODE != ADC_2__HARDWARE_TRIGGER)
	    ADC_2_StartConvert();
      #endif
    #endif

	#if defined(RSVP_USE_ADC_3)	
	  /* Start the Analog-to-Digital Converter(ADC) Component and enable Interrupt */
      ADC_3_Start();
    
      /* if using external interrupt component, otherwise internal... */
      // ADC_3_IRQ_StartEx(ADC_3_IRQ_Handler);
	
	  /* Start ADC conversion */
      #if (ADC_3_DEFAULT_CONV_MODE != ADC_3__HARDWARE_TRIGGER)
	    ADC_3_StartConvert();
      #endif
    #endif    
    
	#if defined(RSVP_USE_DAC_1)	
	  /* Start the Component and initialize */
      DAC_1_Start();
	  DAC_1_SetValue(0u);
    #endif

	#if defined(RSVP_USE_DAC_2)	
	  /* Start the Component and initialize */
      DAC_2_Start();
	  DAC_2_SetValue(0u);
    #endif

    #if defined(RSVP_USE_CMP_1)	
	  /* Start the Component */
      // CMP_1_Start();
    #endif

    #if defined(RSVP_USE_CMP_2)	
	  /* Start the Component */
      // CMP_2_Start();
    #endif

	#if defined(RSVP_USE_SPWM_1)		
	  /* Enable (and Initialize) the software PWM System */
      RSVP_SPWM_Enable();
    #endif

	/* Enable global interrupts */
    CyGlobalIntEnable;

    #if defined(RSVP_USE_USBUART_1)
      /* USBUART may be defined, but not "UP" by default */
      #if defined(RSVP_USBUART_1_UP)  
	    /* Start the Component and initialize */
        USBUART_1_Start(0u, USBUART_1_5V_OPERATION);
        /* Wait for Device to enumerate */
        /* @TODO : add SW1 or timer breakout */
        while(!USBUART_1_GetConfiguration());
        /*  initializes the CDC interface to be ready to receive data from the PC */
        USBUART_1_CDC_Init();
        CyDelay(100);
        usbuart_1_if_status = 1u ; /* interface is up */
      #endif
    #endif

	return(RSVP_SUCCESS);
}

/**
  * @fn         void rsvp_platform_Update(void)
  * @brief      called to stop all of the hardware rsvp_platform systems
  * @param      None.
  * @retval     rsvp_RetCode_t
  */
rsvp_RetCode_t
rsvp_platform_Update(void)
{	
		/* most I/O operations are interrupt driven... */
        /* the "Update" routines move the data from background interrupt buffers */
		#if defined(RSVP_USE_ADC_1) || defined(RSVP_USE_ADC_2) || defined(RSVP_USE_ADC_3)
	  	    rsvp_ADC_Update();
		#endif

		#if (RSVP_USE_CLI == TRUE)
	 	  rsvp_CLI_Update();
		#endif			

	return(RSVP_SUCCESS);
}

/**
  * @fn         void rsvp_platform_Stop(void)
  * @brief      called to stop all of the hardware rsvp_platform systems
  * @param      None.
  * @retval     rsvp_RetCode_t
  */
rsvp_RetCode_t
rsvp_platform_Stop(void)
{	
	/* Disable global interrupts */
    CyGlobalIntDisable;	
    /* enter an infinite loop - or add default platform error code here... */
    for(;;)
    {
        /* Blink USER_LED1 using the CPU */
        USER_LED_1_Write(0x00); 
        CyDelay(200);
        USER_LED_1_Write(0x01);
        CyDelay(200);
        /* or Halt - your choice... */
        // CyHalt();
    }
	return(RSVP_SUCCESS);
}

/**
  * @fn         void rsvp_platform_Sleep(void)
  * @brief      called to put the hardware rsvp_platform system to sleep
  * @param      None.
  * @retval     rsvp_RetCode_t
  */
rsvp_RetCode_t
rsvp_platform_Sleep(void)
{
	/* Call all component stop/sleep functions here . 
	 * This project doesn't have any components that needs shut down */ 
	 
	/* Set all the port pin registers to high impedence mode */
	// CY_SET_REG32(CYREG_PRT0_PC , RSVP_HIGH_IMPEDANCE);
	// CY_SET_REG32(CYREG_PRT1_PC , RSVP_HIGH_IMPEDANCE);
	// CY_SET_REG32(CYREG_PRT2_PC , RSVP_HIGH_IMPEDANCE);
	// CY_SET_REG32(CYREG_PRT3_PC , RSVP_HIGH_IMPEDANCE);
	// CY_SET_REG32(CYREG_PRT4_PC , RSVP_HIGH_IMPEDANCE);
	
	/* Set the WakeUp Switch pin in resistive pull up mode for detecting 
	 * the falling edge interrupt when switch is pressed */
	// USER_SW_SetDriveMode(USER_SW_DM_RES_UP);
	
	return(RSVP_SUCCESS);
}

/**
  * @fn         void rsvp_platform_Wake(void)
  * @brief      called to wake the hardware rsvp_platform system
  * @param      None.
  * @retval     rsvp_RetCode_t
  */
rsvp_RetCode_t
rsvp_platform_Wake(void)
{
	/* Call all component restore functions here . 
	 * This project doesn't have any components that needs to be restored */ 
	 
	/* Restore all the pin states */
	
	/* Set the output pins in strong drive mode */
	//USER_LEDR_SetDriveMode(USER_SW_DM_STRONG);
	
	return(RSVP_SUCCESS);
}

/*-----------------------------------------------------------------------------*/
/**
  * Close the Doxygen main group.
  *    @}
*/
/*****************************************************************************
# Copyright:	(C) 2013-2015 by PatternAgents,LLC. All rights reserved.
#*****************************************************************************
# RSVP-SIS Licensing Model:
# 
# RSVP-SIS uses the increasingly popular business model called 
# "Dual Licensing" in which both the open source software distribution 
# mechanism and traditional commercial software distribution models 
# are combined.
# 
# Open Source Projects:
# 
# If you are developing and distributing open source applications 
# under the GNU General Public License version 3 (GPLv3), 
# as published by the Free Software Foundation, then you are free 
# to use the RSVP-SIS software under the GPLv3 license. Please note 
# that GPLv3 Section 2(b) requires that all modifications to the 
# original code as well as all Derivative Works must also be 
# released under the terms of the GPLv3 open source license.
# 
# Closed Source Projects:
# 
# If you are developing and distributing traditional closed source 
# applications, you must purchase a RSVP-SIS commercial use license, 
# which is specifically designed for users interested in retaining 
# the proprietary status of their code. All RSVP-SIS commercial licenses 
# expressly supersede the GPLv3 open source license. This means that 
# when you license the RSVP-SIS software under a commercial license, 
# you specifically do not use the software under the open source 
# license and therefore you are not subject to any of its terms.
#
# Commercial licensing options available on the RSVP-SIS Website at : 
#	http://www.rsvpsis.org/licensing/
#
#*****************************************************************************
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, 
# BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
# COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED 
# AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE 
# USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
/* End of rsvp_platform.c */
/**
 ******************************************************************************
    @file        rsvp_fru.c
    @author      Tom Moxon
    @copyright   PatternAgents, LLC
    @brief       This file provides the rsvp_fru Analog-to-Digital Converter routines.
    @section     rsvp_fru_intro rsvp_adc hardware routines
    @par	
    @section    rsvp_fru_theory Theory of Operation
    @par
     rsvp_fru_bmc - Baseboard Management Controller - Field Replaceable Unit     \n
	@par
     This FRU array is typically 512 bytes long and it's data is returned        \n
     (by default) as the base of the exposed device register/address space.      \n
     If a Multirecord area is required, it will occupy the second 256 byte page. \n
     This FRU is a valid, but simplified FRU format, we shall refer to as        \n
     the "Canonical FRU format". In this format, all fields are populated        \n
     with their maximum recommended field size, and that field is null-padded    \n
     (with zeros) to fill a fixed size and hence have fixed locations in memory. \n
     The "Canonical FRU format" is 256 bytes long, with an additional 256 bytes  \n
     reserved for a Multirecord area to contain power supply information, and    \n
     initial device provisioning information, such as MAC ID, Gateway Address,   \n
     DNS address, "Home" URL, "Update" URL, and others. Usually 512 bytes is     \n
     sufficient to hold all the device "metadata", however if more space is      \n
     required, the field can be expanded up to 4K bytes in practice.             \n
     if a number of motor profile or other local calibration tables are needed,  \n
     then the size of the FRU area may need to expand beyond the reserved size   \n
     of 512 bytes (default).                                                     \n                    
	@par
      This allows simple access to the FRU from the firmware using fixed offsets. \n
      ANY user writes to this FRU MUST conform to "Canonical FRU Format", and     \n
      those user writes must update any field related checksums manually.         \n
	@par
      In order to save device flash memory space, it is assumed that the host     \n
      FRU update process is to enforce the padding, that logic is too large to    \n
      embed here locally. The flash write routines are "blind" updates.           \n
	@par
      This array is placed in flash and uses the "CYCODE" keyword so that this    \n
      array can be placed within the em_EEPROM component and simulate an EEPROM.  \n
 	@par
      Note: This is a default "blank" template, for more information, see :       \n
      http://www.intel.com/content/www/us/en/servers/ipmi/information-storage-definition-rev-1-2.html  \n
 	@par
    
    @TODO: add "PSOC" guards for special creator keywords for portability.
 ******************************************************************************
*/

/*-----------------------------------------------------------------------------*/
/* Include Files                                                               */
/*-----------------------------------------------------------------------------*/
#include <rsvp_types.h>
#include <rsvp_fru.h>
#include <CyLib.h>
#include <cydevice_trm.h>
#include <cydisabledsheets.h>

/*-----------------------------------------------------------------------------*/
/** @defgroup rsvp_FRU rsvp_FRU
  * @{
  */

/*-----------------------------------------------------------------------------*/
/* Global variables                                                            */
/*-----------------------------------------------------------------------------*/

rsvp_cu8_t CYCODE rsvp_fru_bmc[RSVP_FRU_PDU_LENGTH] = {
	/* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
	/*       FRU Common Header                                     [  8] bytes */
    0x01, /* Common Header Format Version = 1                                  */
    0x01, /* Internal Use Area Offset                              { 72} bytes */
	0x0A, /* Chassis Info Area Offset                              { 32} bytes */
	0x0E, /* Board Info Area Offset                                { 64} bytes */
	0x16, /* Product Info Area Offset                              { 96} bytes */
	0x22, /* MultiRecord Info Starting Area                        {240} bytes */
	0x00, /* Padding, always 0x00                                              */
	0x00, /* Common Header Checksum                                            */
	/*                                                                         */
	/* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
	/*       Internal Use Area : Application Defined Data Area of  [ 72] bytes */
	/*       Internal Use Area : Header Area and 64 byte Data Area             */
	0x01, /* Internal Use Area : Format = 1                                    */
	0x09, /* Internal Use Area : Length (in multiples of 8 bytes)  [ 72] bytes */
	0x00, /* Internal Use Area : IUA_Flag_1                        [  1] byte  */
	0x00, /* Internal Use Area : IUA_Flag_2                        [  1] byte  */
	0x00, /* Internal Use Area : IUA_Flag_3                        [  1] byte  */
	0x00, /* Internal Use Area : IUA_Flag_4                        [  1] byte  */
	0x00, /* Internal Use Area : Header Checksum                               */
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* Data Area   [ 64] bytes */
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* Make & Model Parameters */
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* This data in this area  */
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* is product specific ... */
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* User/Application Data   */
	0x00, /* Internal Use Area : Internal Use Area Checksum                    */ 
	/*                                                                         */
	/* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
	/*       Chassis Info :                                        [ 32] bytes */
	0x01, /* Chassis Info : Format = 1                                         */
	0x04, /* Chassis Info : Length (in multiples of 8 bytes)       { 32} bytes */
	0x15, /* Chassis Info : Type (enumeration) 0x15 = Peripheral Chassis       */
    0xCC, /* Chassis Info : Part Number (type/length) (ascii/12 bytes)         */
	' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',
    0xCC, /* Chassis Serial Number (type/length) (ascii/12 bytes)              */
	' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',
	0xC1, /* Chassis Info Area : (type/length byte - no more info fields)      */	
	0x00, /* Chassis Info Area : Chassis Info Checksum                         */ 
	/*                                                                         */
	/* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
	/*       Board Info :                                          [ 64] bytes */
	0x01, /* Board Info : Format = 1                                           */
	0x08, /* Board Info : Length (in multiples of 8 bytes)         { 64} bytes */
	0x00, /* Board Info : Language code (section 15)                           */
	0x00, /* Board Info : Board Mfg.Date # of minutes from 0:00 hrs 1/1/96(lsb)*/
	0x00, /* Board Info : Board Mfg.Date # of minutes from 0:00 hrs 1/1/96(csb)*/
	0x00, /* Board Info : Board Mfg.Date # of minutes from 0:00 hrs 1/1/96(msb)*/
	0xCC, /* Board Info : Board Mfg.Name (type/length) (ascii/12 bytes)        */
	' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',
	0xCC, /* Board Info : Board Name (type/length) (ascii/12 bytes)            */
	' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',
	0xCC, /* Board Info : Board Serial Number (type/length) (ascii/12 bytes)   */
	' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',
	0xCC, /* Board Info : Board Part Number (type/length) (ascii/12 bytes)     */
	' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',
	0xC0, /* Board Info : Board FRU File ID (type/length) (not used)           */
	0xC1, /* Board Info : (type/length byte - no more info fields)             */	
	0x00, /* Board Info : Board Info Padding1                                  */ 
	0x00, /* Board Info : Board Info Padding2                                  */ 
	0x00, /* Board Info : Board Info Padding3                                  */ 
	0x00, /* Board Info : Board Info Checksum                                  */ 
	/*                                                                         */
	/* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
	/*       Product Info :                                        [ 96] bytes */
	0x01, /* Product Info : Format = 1                                         */
	0x0C, /* Product Info : Length (in multiples of 8 bytes)       { 96} bytes */
	0x00, /* Product Info : Language Code (See section 15)                     */
	0xCC, /* Product Info : Mfg. Name (type/length) (ascii/12 bytes)           */
	' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',
	0xCC, /* Product Info : Product Name (type/length) (ascii/12 bytes)        */
	' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',
	0xCC, /* Product Info : Product Model (type/length) (ascii/12 bytes)       */
	' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',
	0xCC, /* Product Info : Product Version (type/length) (ascii/12 bytes)     */
	' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',
	0xCC, /* Product Info : Product Serial # (type/length) (ascii/12 bytes)    */
	' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',
	0xD4, /* Product Info : Product Asset Tag (type/length) (ascii/20 bytes)   */
	' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',
	' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',
	0xC0, /* Product Info : FRU File ID (C0 = Not Used)                        */
	0xC1, /* Product Info : (type/length byte - no more info fields)           */	
	0x00, /* Product Info : Product Info Padding1                              */ 
	0x00, /* Product Info : Product Info Padding2                              */ 
	0x00, /* Product Info : Product Info Padding3                              */ 
	0x00, /* Product Info : Product Info Padding4                              */ 
	0x00, /* Product Info : Product Info Checksum                              */ 
	/* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
	/*  MultiRecord Area :                                        [ 240] bytes */
	/*  (empty for now, but will contain configuration URL information)        */
	/*                                                                         */
	0
	/* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
};

rsvp_cu32_t       	rsvp_FRU_PDU_Size =  RSVP_FRU_PDU_LENGTH;

/*-----------------------------------------------------------------------------*/
/**
  * Close the Doxygen main group.
  *    @}
*/
/*****************************************************************************
# Copyright:	(C) 2013-2015 by PatternAgents,LLC. All rights reserved.
#*****************************************************************************
# RSVP-SIS Licensing Model:
# 
# RSVP-SIS uses the increasingly popular business model called 
# "Dual Licensing" in which both the open source software distribution 
# mechanism and traditional commercial software distribution models 
# are combined.
# 
# Open Source Projects:
# 
# If you are developing and distributing open source applications 
# under the GNU General Public License version 3 (GPLv3), 
# as published by the Free Software Foundation, then you are free 
# to use the RSVP-SIS software under the GPLv3 license. Please note 
# that GPLv3 Section 2(b) requires that all modifications to the 
# original code as well as all Derivative Works must also be 
# released under the terms of the GPLv3 open source license.
# 
# Closed Source Projects:
# 
# If you are developing and distributing traditional closed source 
# applications, you must purchase a RSVP-SIS commercial use license, 
# which is specifically designed for users interested in retaining 
# the proprietary status of their code. All RSVP-SIS commercial licenses 
# expressly supersede the GPLv3 open source license. This means that 
# when you license the RSVP-SIS software under a commercial license, 
# you specifically do not use the software under the open source 
# license and therefore you are not subject to any of its terms.
#
# Commercial licensing options available on the RSVP-SIS Website at : 
#	http://www.rsvpsis.org/licensing/
#
#*****************************************************************************
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, 
# BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
# COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED 
# AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE 
# USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
/* End of rsvp_FRU.c */


/**
 ******************************************************************************
    @file        rsvp_interrupts.c
    @author      Tom Moxon
    @copyright   PatternAgents, LLC
    @brief       Defines all the interrupt service routines (ISR's) and low level routines.
    @section     rsvp_interrupts_intro rsvp_interrupts Platform Interrupts 
    @par
    The rsvp_interrupts module contains all the low level hardware and interrupt service routines.
    We thought about naming it "rsvp_cpuSoC", because it really contains all the low level mapping 
	to the actual hardware CPU and System-on-Chip platform.
    @par	
    @section    rsvp_interrupts_theory Theory of Operation
    @par
    theory \n
	@par
    more \n

 ******************************************************************************
*/

/*-----------------------------------------------------------------------------*/
/* Include Files                                                               */
/*-----------------------------------------------------------------------------*/
#include <project.h>
#include <rsvp_types.h>
#include <rsvp_conf.h>
#include <rsvp_interrupts.h>
#include <rsvp_platform.h>
#include <rsvp_cli.h>
#include <rsvp_spwm.h>
#include <rsvp_adc.h>

/*-----------------------------------------------------------------------------*/
/** @defgroup rsvp_interrupts rsvp_interrupts
  * @{
  */

/*-----------------------------------------------------------------------------*/
/* Global Variables   (Interrupt Context)                                      */
/*-----------------------------------------------------------------------------*/
/* The variables (flags and counters) below are used by the interrupt routines */
/* You may want to use "Critical_Section" guards around them when depending on */
/* these variables to be stable across several operations, or make a copy...   */
/* as they may change at any time within the hardware interrupt context.       */
/*-----------------------------------------------------------------------------*/
rsvp_u8_t   cpu_irq_status                       = 0u;
rsvp_u8_t   cpu_irq_flag                         = 0u;

/*-----------------------------------------------------------------------------*/
/* Interrupt Handlers                                                          */
/*-----------------------------------------------------------------------------*/
#if defined(RSVP_USE_LVDT_1)
CY_ISR_PROTO(LVDT_1_IRQ_Handler);
rsvp_u32_t  lvdt_1_irq_status = 0u;
rsvp_u8_t   lvdt_1_irq_flag   = 0u;
/**
  * @fn         void LVDT_1_IRQ_Handler(void)
  * @brief      Interrupt Service Routine for the LVDT_1 Component
  * @param      void
  * @retval     void
  */
CY_ISR(LVDT_1_IRQ_Handler)
{
	/* Read interrupt source registers */
    lvdt_1_irq_status = 0u;
	/* increment the interrupt timer flag  */
	/* (the number of times the interrupt has occurred) */
    lvdt_1_irq_flag++; 
	/* Clear handled interrupt */
	//LVDT_1_ClearInterrupt(wdt_1_irq_status);
}
#endif

#if defined(RSVP_USE_WDT_1)
CY_ISR_PROTO(WDT_1_IRQ_Handler);
rsvp_u32_t  wdt_1_irq_status = 0u;
rsvp_u8_t   wdt_1_irq_flag   = 0u;
/**
  * @fn         void WDT_1_IRQ_Handler(void)
  * @brief      Interrupt Service Routine for the WDT_1 Component
  * @param      void
  * @retval     void
  */
CY_ISR(WDT_1_IRQ_Handler)
{
	/* Read interrupt source registers */
    wdt_1_irq_status = 0u;
	/* increment the interrupt timer flag  */
	/* (the number of times the interrupt has occurred) */
    wdt_1_irq_flag++; 
	/* Clear handled interrupt */
	//WDT_1_ClearInterrupt(wdt_1_irq_status);
}
#endif

#if defined(RSVP_USE_SYSTICK)
CY_ISR_PROTO(SysTick_IRQ_Handler);
rsvp_u32_t  systick_irq_status                   = 0u;
rsvp_u32_t  systick_irq_flag                     = 0u;
rsvp_u32_t  systick_blink_flag                   = 0u;

CY_ISR(SysTick_IRQ_Handler)
{
    /* We got a "Tick" Interrupt, so set the RSVP_SysTickFlag to 1  */
    systick_irq_flag++;
    systick_blink_flag++;
	
	if (systick_blink_flag > 500) {
		USER_LED_1_Write(!USER_LED_1_Read());
		systick_blink_flag = 0;
	}
    
	#if defined(RSVP_USE_SPWM_1)
	/* this needs a configuration template /conditional guards */
    /* Run the Software PWM Update */
    RSVP_SPWM_Enabled = RSVP_SPWM_EnableGet();
    RSVP_SPWM_State = RSVP_SPWM_StateGet();
    if (RSVP_SPWM_Enabled != 0) {
        SPWM_1_Write(RSVP_SPWM_State);
        RSVP_SPWM_Update();
    }
	#endif
}

/*
 * Setup the systick timer to generate the Tick interrupt at a frequency of 1mSec
 */
void SysTick_StartEx(cyisraddress address)
{
	/* Configure SysTick to interrupt at 1 millsecond rate. (For 48Mhz CPU Clock) */
    //SysTick_Config( 48000 );
    SysTick_Config( RSVP_SYSTICK_CONFIG );
    
    /* Register the new SysTick Interrupt Vector Handler */
    CyIntSetSysVector(RSVP_SYSTICK_NVIC, ( cyisraddress ) address);
    
    /* Enable Systick Interrupt in NVIC */
    CyIntEnable(RSVP_SYSTICK_NVIC);
}
#endif

#if defined(RSVP_USE_TIMER_1)
CY_ISR_PROTO(TIMER_1_IRQ_Handler);
rsvp_u32_t  timer_1_irq_status                   = 0u;
rsvp_u8_t   timer_1_irq_flag                     = 0u;
/**
  * @fn         void TIMER_1_IRQ_Handler(void)
  * @brief      Interrupt Service Routine for the TIMER_1 Component
  * @param      void
  * @retval     void
  */
CY_ISR(TIMER_1_IRQ_Handler)
{
	/* Read interrupt source registers */
    timer_1_irq_status = TIMER_1_GetInterruptSource();
	/* increment the timer expired flag, which is the  */
	/* number of times the Modbus 3.5 Character Timeout has occurred */
    timer_1_irq_flag++; 
	/* Clear handled interrupt */
	TIMER_1_ClearInterrupt(timer_1_irq_status);
}
#endif

#if defined(RSVP_USE_TIMER_2)	
CY_ISR_PROTO(TIMER_2_IRQ_Handler);
rsvp_u32_t  timer_2_irq_status                   = 0u;
rsvp_u8_t   timer_2_irq_flag                     = 0u;
/**
  * @fn         void TIMER_2_IRQ_Handler(void)
  * @brief      Interrupt Service Routine for the TIMER_2 Component
  * @param      void
  * @retval     void
  */
CY_ISR(TIMER_2_IRQ_Handler)
{
	/* Read interrupt source registers */
    timer_2_irq_status = TIMER_2_GetInterruptSource();
	/* increment the timer expired flag, which is the  */
	/* number of times the Modbus 3.5 Character Timeout has occurred */
    timer_2_irq_flag++; 
	/* Clear handled interrupt */
	TIMER_2_ClearInterrupt(timer_2_irq_status);
}
#endif

#if defined(RSVP_USE_TIMER_3)
CY_ISR_PROTO(TIMER_3_IRQ_Handler);
rsvp_u32_t  timer_3_irq_status                   = 0u;
rsvp_u8_t   timer_3_irq_flag                     = 0u;
/**
  * @fn         void TIMER_3_IRQ_Handler(void)
  * @brief      Interrupt Service Routine for the TIMER_3 Component
  * @param      void
  * @retval     void
  */
CY_ISR(TIMER_3_IRQ_Handler)
{
	/* Read interrupt source registers */
    timer_3_irq_status = TIMER_3_GetInterruptSource();
	/* increment the interrupt timer flag  */
	/* (the number of times the interrupt has occurred) */
    timer_3_irq_flag++; 
	/* Clear handled interrupt */
	TIMER_3_ClearInterrupt(timer_3_irq_status);
}
#endif

#if defined(RSVP_USE_TIMER_4)
CY_ISR_PROTO(TIMER_4_IRQ_Handler);
rsvp_u32_t  timer_4_irq_status                   = 0u;
rsvp_u8_t   timer_4_irq_flag                     = 0u;

/**
  * @fn         void TIMER_4_IRQ_Handler(void)
  * @brief      Interrupt Service Routine for the TIMER_4 Component
  * @param      void
  * @retval     void
  */
CY_ISR(TIMER_4_IRQ_Handler)
{
	/* Read interrupt source registers */
    timer_4_irq_status = TIMER_4_GetInterruptSource();
	/* increment the interrupt timer flag  */
	/* (the number of times the interrupt has occurred) */
    timer_4_irq_flag++; 
	/* Clear handled interrupt */
	TIMER_4_ClearInterrupt(timer_4_irq_status);
    
    /* Force a bootloader restart */
    Bootloadable_Load();        
}
#endif


#if defined(RSVP_USE_UART_1)
CY_ISR_PROTO(UART_1_IRQ_Handler);
rsvp_u32_t  uart_1_rx_irq_status                 = 0u;
rsvp_u8_t   uart_1_rx_irq_flag                   = 0u;
rsvp_u32_t  uart_1_tx_irq_status                 = 0u;
rsvp_u8_t   uart_1_tx_irq_flag                   = 0u;
/**
  * @fn         void UART_1_IRQ_Handler(void)
  * @brief      Interrupt Service Routine for the UART_1 Component
  * @param      void
  * @retval     void
  */
CY_ISR(UART_1_IRQ_Handler)
{
	/* Read RX interrupt status registers */
    uart_1_rx_irq_status = UART_1_GetRxInterruptSourceMasked();
    /* increment the data ready flag, indicates number of characters received */
	uart_1_rx_irq_flag++;
	/* Clear handled interrupt */	/* this component is self-clearing */
    UART_1_ClearRxInterruptSource(uart_1_rx_irq_status);
}
#endif 

#if defined(RSVP_USE_UART_2)
CY_ISR_PROTO(UART_2_RX_IRQ_Handler);
rsvp_u8_t   uart_2_rx_irq_status                 = 0u;
rsvp_u8_t   uart_2_rx_irq_flag                   = 0u;
/**
  * @fn         void UART_2_RX_IRQ_Handler(void)
  * @brief      Interrupt Service Routine for the UART_2 Component
  * @param      void
  * @retval     void
  */
CY_ISR(UART_2_RX_IRQ_Handler)
{
	/* Read RX interrupt status registers */
    //uart_2_rx_irq_status = UART_2_ReadRxStatus();
    /* increment the data ready flag, indicates number of characters received */
	//uart_2_rx_irq_flag++;
	/* insure that the line stays in receive mode until timeout */
	// UART_2_txen_Write(0x00);
	/* Clear handled interrupt */
	/* this component is self-clearing */
    //UART_2_ClearRxInterruptSource(uart_2_rx_irq_status);
}

CY_ISR_PROTO(UART_2_TX_IRQ_Handler);
rsvp_u8_t   uart_2_tx_irq_status                 = 0u;
rsvp_u8_t   uart_2_tx_irq_flag                   = 0u;
/**
  * @fn         void UART_2_TX_IRQ_Handler(void)
  * @brief      Interrupt Service Routine for the UART_2 Component
  * @param      void
  * @retval     void
  */
CY_ISR(UART_2_TX_IRQ_Handler)
{
	/* N.B. TX interrupts are disabled for now  */
	/* ---------------------------------------- */
    /* Read TX interrupt status registers */
    //uart_2_tx_irq_status = UART_2_ReadTxStatus();
	//uart_2_tx_irq_flag++;

	/* Check status */
	/* if state=transmit, make sure that UART_2_txen is active */
	// UART_2_txen_Write(0x01);
	/* if state=receive or TX FIFO empty, make sure that UART_2_txen is Inactive */
	/* Handle Interrupt Source */
	/* Clear handled interrupt */
	/* this component is self-clearing */
    //UART_2_ClearTxInterruptSource(uart_2_tx_irq_status);
}
#endif

#if defined(RSVP_USE_CMP_1)
CY_ISR_PROTO(CMP_1_IRQ_Handler);
rsvp_u32_t  cmp_1_irq_status                   = 0u;
rsvp_u8_t   cmp_1_irq_flag                     = 0u;

/**
  * @fn         void CMP_1_IRQ_Handler(void)
  * @brief      Interrupt Service Routine for the CMP_1 Component
  * @param      void
  * @retval     void
  */
CY_ISR(CMP_1_IRQ_Handler)
{
	/* Read interrupt source registers */
    cmp_1_irq_status = CMP_1_GetInterruptSource();
	/* increment the interrupt timer flag  */
	/* (the number of times the interrupt has occurred) */
    cmp_1_irq_flag++; 
	/* Clear handled interrupt */
	CMP_1_ClearInterrupt(cmp_1_irq_status);
}
#endif

#if defined(RSVP_USE_CMP_2)
CY_ISR_PROTO(CMP_2_IRQ_Handler);
rsvp_u32_t  cmp_2_irq_status                   = 0u;
rsvp_u8_t   cmp_2_irq_flag                     = 0u;

/**
  * @fn         void CMP_2_IRQ_Handler(void)
  * @brief      Interrupt Service Routine for the CMP_2 Component
  * @param      void
  * @retval     void
  */
CY_ISR(CMP_2_IRQ_Handler)
{
	/* Read interrupt source registers */
    cmp_2_irq_status = CMP_2_GetInterruptSource();
	/* increment the interrupt timer flag  */
	/* (the number of times the interrupt has occurred) */
    cmp_2_irq_flag++; 
	/* Clear handled interrupt */
	CMP_2_ClearInterrupt(cmp_2_irq_status);
}
#endif

/*-----------------------------------------------------------------------------*/
/* ADC_1                                                                       */
/*-----------------------------------------------------------------------------*/
/* If the ADC is defined, then include it's interrupt handler */
#if defined(RSVP_USE_ADC_1)	
CY_ISR_PROTO(ADC_1_IRQ_Handler);
rsvp_u32_t  adc_1_irq_status                     = 0u;
rsvp_u8_t   adc_1_irq_flag                       = 0u;
rsvp_u8_t   adc_1_range_flag                     = 0u;
rsvp_s32_t  adc_1_gain                           = 0u;
rsvp_s16_t  adc_1_data[32];
/**
  * @fn         void ADC_1_IRQ_Handler(void)
  * @brief      Interrupt Service Routine for the ADC Subsystem
  * @param      void
  * @retval     void
  */
CY_ISR(ADC_1_IRQ_Handler)
{
	rsvp_u8_t channum;
	
    /* Read interrupt status registers */
    adc_1_irq_status = ADC_1_SAR_INTR_MASKED_REG;
    /* Check for End of Scan interrupt */
    if((adc_1_irq_status & ADC_1_EOS_MASK) != 0u)
    {
		/* not doing anything with range detect/saturation right now... */
        /* Read range interrupt status and raise the flag */
        adc_1_range_flag = ADC_1_SAR_RANGE_INTR_MASKED_REG;
        /* Clear range detect status */
        ADC_1_SAR_RANGE_INTR_REG = adc_1_range_flag;
		for (channum = 0; channum < ADC_1_TOTAL_CHANNELS_NUM; channum++){
          /* Buffer the results */
          adc_1_data[channum] = ADC_1_GetResult16(channum);
        }		
        /* set IRQ done flag */
        adc_1_irq_flag = 1u;
    }
	/* test for injection channel */
	if((adc_1_irq_status  & ADC_1_INJ_EOC_MASK) != 0u)
    {
        adc_1_data[7] = ADC_1_GetResult16(7);
    }    

    /* Clear handled interrupt */
    ADC_1_SAR_INTR_REG = adc_1_irq_status;
}
#endif

#if defined(RSVP_USE_USER_SW)
CY_ISR_PROTO(USER_SW_IRQ_Handler);
rsvp_u32_t  user_sw_1_irq_status                   = 0u;
rsvp_u8_t   user_sw_1_irq_flag                     = 0u;

/**
  * @fn         void USER_SW_1_IRQ_Handler(void)
  * @brief      Interrupt Service Routine for the USER_SW_1 Component
  * @param      void
  * @retval     void
  */
CY_ISR(USER_SW_1_IRQ_Handler)
{
	/* Read interrupt source registers */
    /* user_sw_1_irq_status = USER_SW_1_GetPending(); */
	
	if (user_sw_1_irq_flag != 0)
	USER_LED_3_Write(!USER_LED_3_Read());
	
	/* use SW_1 to enable /get CLI running */
	rsvp_CLI_NewPrompt = TRUE;
    rsvp_CLI_Enable = TRUE;

	/* increment the interrupt timer flag  */
	/* (the number of times the interrupt has occurred) */
	user_sw_1_irq_flag++;

	/* Clear handled interrupt */
	/* USER_SW_1_ClearInterrupt(); */
	/* USER_SW_1_IRQ_ClearPending(); */
}
#endif


/*-----------------------------------------------------------------------------*/
/**
  * Close the Doxygen main group.
  *    @}
*/
/*****************************************************************************
# Copyright:	(C) 2013-2015 by PatternAgents,LLC. All rights reserved.
#*****************************************************************************
# RSVP-SIS Licensing Model:
# 
# RSVP-SIS uses the increasingly popular business model called 
# "Dual Licensing" in which both the open source software distribution 
# mechanism and traditional commercial software distribution models 
# are combined.
# 
# Open Source Projects:
# 
# If you are developing and distributing open source applications 
# under the GNU General Public License version 3 (GPLv3), 
# as published by the Free Software Foundation, then you are free 
# to use the RSVP-SIS software under the GPLv3 license. Please note 
# that GPLv3 Section 2(b) requires that all modifications to the 
# original code as well as all Derivative Works must also be 
# released under the terms of the GPLv3 open source license.
# 
# Closed Source Projects:
# 
# If you are developing and distributing traditional closed source 
# applications, you must purchase a RSVP-SIS commercial use license, 
# which is specifically designed for users interested in retaining 
# the proprietary status of their code. All RSVP-SIS commercial licenses 
# expressly supersede the GPLv3 open source license. This means that 
# when you license the RSVP-SIS software under a commercial license, 
# you specifically do not use the software under the open source 
# license and therefore you are not subject to any of its terms.
#
# Commercial licensing options available on the RSVP-SIS Website at : 
#	http://www.rsvpsis.org/licensing/
#
#*****************************************************************************
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, 
# BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
# COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED 
# AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE 
# USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
/* End of rsvp_interrupts.c */

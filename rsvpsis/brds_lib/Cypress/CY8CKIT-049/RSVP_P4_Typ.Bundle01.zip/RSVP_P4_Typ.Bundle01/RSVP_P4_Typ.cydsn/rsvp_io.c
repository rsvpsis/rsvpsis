/**
 ******************************************************************************
    @file        rsvp_io.c
    @author      Tom Moxon
    @copyright   PatternAgents, LLC
    @brief       This file provides the rsvp_io Input/Output Streams.
    @section     rsvp_io_intro rsvp_io hardware routines
    @par	
    @section    rsvp_io_theory Theory of Operation
    @par
    theory \n
	@par
    more \n

 ******************************************************************************
*/

/*-----------------------------------------------------------------------------*/
/* Include Files                                                               */
/*-----------------------------------------------------------------------------*/
#include <rsvp_types.h>
#include <rsvp_conf.h>
#include <rsvp_interrupts.h>
#include <rsvp_platform.h>
#include <rsvp_io.h>
#include <CyLib.h>
#include <cydevice_trm.h>
#include <cydisabledsheets.h>

/*-----------------------------------------------------------------------------*/
/** @defgroup rsvp_io rsvp_io
  * @{
  */

/*-----------------------------------------------------------------------------*/
/* Global variables                                                            */
/*-----------------------------------------------------------------------------*/
rsvp_cu8_t rsvp_io_LEDblink[16] = {0x01, 50, 0x02, 50, 0x03, 50, 0x04, 50, 0x05, 50, 0x06, 50, 0xFF, 50};

/*-----------------------------------------------------------------------------*/
/**
  * @fn         rsvp_io_GetRxBufferSize(rsvp_u8_t channel)
  * @brief      Returns the number of received bytes available in the RX buffer.
  * @param      None.
  * @retval     rsvp_u32_t
  * @detail
  */
rsvp_u32_t rsvp_io_GetRxBufferSize(rsvp_u8_t channel)
{
  rsvp_u8_t BufSize = 0;
	
	  #if (RSVP_USE_IO == TRUE)
	    if (channel == 1) {
	      #if defined CY_SCB_UART_1_H
		    BufSize = UART_1_SpiUartGetRxBufferSize();
		  #else 
		    BufSize = UART_1_GetRxBufferSize();
		  #endif
        } else if (channel == 2) {
	      #if defined CY_SCB_UART_2_H
		    BufSize = UART_2_SpiUartGetRxBufferSize();
		  #else 
		    BufSize = UART_2_GetRxBufferSize();
		  #endif
        }		
      #endif	
	return(BufSize);
}

/*-----------------------------------------------------------------------------*/
/**
  * @fn         rsvp_u8_t rsvp_io_PutChar(rsvp_u8_t channel, rsvp_u8_t Buffer)
  * @brief      put a character
  * @param      None.
  * @retval     rsvp_RetCode_t
  * @detail
  */
rsvp_RetCode_t 
rsvp_io_PutChar(rsvp_u8_t channel, rsvp_u8_t Buffer)
{
	  #if (RSVP_USE_IO == TRUE)
	    if (channel == 1) {
	      #if defined CY_SCB_UART_1_H
		    UART_1_UartPutChar(Buffer);
		  #else 
		    UART_1_PutString(Buffer);
		  #endif
        } else if (channel == 2) {
	      #if defined CY_SCB_UART_2_H
		    UART_2_UartPutString(Buffer);
		  #else 
		    UART_2_PutChar(Buffer);
		  #endif
        }		
      #endif	
	return(RSVP_SUCCESS);	
}

/*-----------------------------------------------------------------------------*/
/**
  * @fn         rsvp_u8_t rsvp_io_PutChar(rsvp_u8_t channel, rsvp_u8_t Buffer)
  * @brief      put a character
  * @param      None.
  * @retval     rsvp_RetCode_t
  * @detail
  */
rsvp_u8_t
rsvp_io_GetChar(rsvp_u8_t channel)
{
  rsvp_u8_t Buffer = 0;
	
	  #if (RSVP_USE_IO == TRUE)
	    if (channel == 1) {
	      #if defined CY_SCB_UART_1_H
		    Buffer = UART_1_UartGetChar();
		  #else 
		    UART_1_GetChar();
		  #endif
        } else if (channel == 2) {
	      #if defined CY_SCB_UART_2_H
		    Buffer = UART_2_UartGetChar();
		  #else 
		    Buffer = UART_2_GetChar();
		  #endif
        }		
      #endif	
	return(Buffer);
}

/*-----------------------------------------------------------------------------*/
/**
  * @fn         rsvp_u8_t rsvp_io_PutString(rsvp_u8_t channel, char *Buffer, rsvp_u8_t BufLen)
  * @brief      get a string, blocking...
  * @param      None.
  * @retval     rsvp_RetCode_t
  * @detail
  */
rsvp_RetCode_t 
rsvp_io_PutString(rsvp_u8_t channel, char *Buffer)
{
	  #if (RSVP_USE_IO == TRUE)
	    if (channel == 1) {
	      #if defined CY_SCB_UART_1_H
		    UART_1_UartPutString(Buffer);
		  #else 
		    UART_1_PutString(Buffer);
		  #endif
        } else if (channel == 2) {
	      #if defined CY_SCB_UART_2_H
		    UART_2_UartPutString(Buffer);
		  #else 
		    UART_2_PutString(Buffer);
		  #endif
        }		
      #endif	
	return(RSVP_SUCCESS);	
}

/*-----------------------------------------------------------------------------*/
/**
  * @fn         rsvp_u8_t rsvp_io_GetString(rsvp_u8_t channel, char *Buffer, rsvp_u8_t BufLen)
  * @brief      get a string
  * @param      None.
  * @retval     rsvp_RetCode_t
  * @detail
      Channel is the physical channel number (UART_1, _2, _3, etc.) UART_1 for now. 
      Buffer is a pointer to a character buffer for the incoming string from the UART.
      BufLen is the maximum length of the buffer in characters (bytes),
      (which include the trailing null (0) to terminate the string.
     
      This function will receive characters from the UART_1 input and store them
      in the buffer pointed to by Buffer, until a termination character
      is received.  The valid termination characters are CR, LF, or ESC.  
      A CRLF (\r\n) pair is treated as a single termination character.  
      The termination characters are not stored in the string but are
      converted to a string terminator (NULL=0), and the function will return.
     
      This function is blocking, and will not return until a 
      line termination charcter has been received and processed.
     
      Returns the count of valid characters that were stored, 
      which does not include the trailing string terminator (NULL=0).
     
      Limits : String Length is limited to BufLen
  */
rsvp_u8_t rsvp_io_GetString(rsvp_u8_t channel, char *Buffer, rsvp_u8_t BufLen)
{
    rsvp_u8_t CharCnt = 0;
    char CurChar;
    static char LineTermFound = 0;

	/* make sure to leave space for the trailing null terminator */
    BufLen--;

    /* Blocking - this routine will block until a line termination character is received */
    while(1)
    {
        /* Blocking - GetChar will block until a charcter is received */ 
        CurChar = rsvp_io_GetChar(channel);
        /* error on character received, discard it and try again */
        if (CurChar == 0) {
            continue;
        }

        /* backspace processing */
        /* TODO : add "delete" processing */
        if(CurChar == '\b')
        {
            /* only if there are characters still in the buffer */
            if(CharCnt)
            {
                /* delete (using backspace) the previous character */
                rsvp_io_PutString(channel, "\b \b");

                /* then decrement the number of characters (left) in the buffer */
                CharCnt--;
            }

            /* backspace processed, now continue back to read the next character */
            continue;
        }

        /* If the current character is LF and last character was CR, then just   */
        /* ignore the LF (drop it), it may also have been from the previous line */
        if((CurChar == '\n') && LineTermFound)
        {
            LineTermFound = 0;
            continue;
        }

        /* check for a line termination character */
        if((CurChar == '\r') || (CurChar == '\n') || (CurChar == 0x1b))
        {
            /* remember that we got a Carriage Return, usually followed by a line feed */
            if(CurChar == '\r')
            {
                LineTermFound = 1;
            }
            break;
        }

        /* Process the received string, and stuff it into the Buffer */
        /* If we have reached the end of the Buffer we are out of buffer memory */
        /* only thing we can do is drop the additional characters until a newline is received */
        /* TODO: Flag a buffer overrun error if we have dropped any characters */
        if(CharCnt < BufLen)
        {
            Buffer[CharCnt] = CurChar;
            CharCnt++;

            /* Echo the character back to the user */
            if (CurChar != 0) {
                rsvp_io_PutChar(channel, CurChar);
            }
        }
    }

    /* null terminate the string */
    Buffer[CharCnt] = 0;

    /* Echo a CRLF pair to the terminal to end the line */
    rsvp_io_PutString(channel, "\r\n");

    /* Return the total count of characters in the buffer */
    return(CharCnt);
}


/**
  * @fn         rsvp_RetCode_t rsvp_io_PutLog(rsvp_u8_t channel, char *Buffer, rsvp_u8_t BufLen)
  * @brief      Log status information to Logging Channels
  * @param      rsvp_u8_t array[], rsvp_u8_t length
  * @retval     rsvp_RetCode_t
  */
rsvp_RetCode_t
rsvp_io_PutLog(rsvp_u8_t channel, char *Buffer, rsvp_u8_t BufLen)
{
	rsvp_u8_t i, red, green, blue, yellow;
	rsvp_u32_t delay;
	
	/* just LED's for now on Channel zero (default is one LED!) */
	/* Color LED's are Red[0], Green[1], Blue[2] */
	(void) (BufLen);
	if (channel == 0) {
	#if defined(RSVP_USE_USER_LED)	
	  ENTER_CRITICAL_SECTION();	
	  red     = USER_LED_1_Read();
	  green   = USER_LED_2_Read();
	  blue    = USER_LED_3_Read();
	  yellow  = USER_LED_4_Read();
    
	  for (i = 0; i < BufLen; i+=2) {
		if ((Buffer[i] & RSVP_LED_RED_MASK) == RSVP_LED_RED_MASK) {
			USER_LED_1_Write(RSVP_LED_ON);
		} else {
			USER_LED_1_Write(RSVP_LED_OFF);			
		}
		if ((Buffer[i] & RSVP_LED_GREEN_MASK) == RSVP_LED_GREEN_MASK) {
			USER_LED_2_Write(RSVP_LED_ON);
		} else {
			USER_LED_2_Write(RSVP_LED_OFF);			
		}
		if ((Buffer[i] & RSVP_LED_BLUE_MASK) == RSVP_LED_BLUE_MASK) {
			USER_LED_3_Write(RSVP_LED_ON);
		} else {
			USER_LED_3_Write(RSVP_LED_OFF);			
		}
		if ((Buffer[i] & RSVP_LED_YELLOW_MASK) == RSVP_LED_YELLOW_MASK) {
			USER_LED_4_Write(RSVP_LED_ON);
		} else {
			USER_LED_4_Write(RSVP_LED_OFF);			
		}
		delay = (rsvp_u32_t) (Buffer[i+1]<<3);
		CyDelay(delay);
	  }
	  USER_LED_1_Write(red);
	  USER_LED_2_Write(green);
	  USER_LED_3_Write(blue);
	  USER_LED_4_Write(yellow);
	  EXIT_CRITICAL_SECTION();	
	#endif
	}	
	return(RSVP_SUCCESS);
}

/*-----------------------------------------------------------------------------*/
/**
  * Close the Doxygen main group.
  *    @}
*/
/*****************************************************************************
# Copyright:	(C) 2013-2015 by PatternAgents,LLC. All rights reserved.
#*****************************************************************************
# RSVP-SIS Licensing Model:
# 
# RSVP-SIS uses the increasingly popular business model called 
# "Dual Licensing" in which both the open source software distribution 
# mechanism and traditional commercial software distribution models 
# are combined.
# 
# Open Source Projects:
# 
# If you are developing and distributing open source applications 
# under the GNU General Public License version 3 (GPLv3), 
# as published by the Free Software Foundation, then you are free 
# to use the RSVP-SIS software under the GPLv3 license. Please note 
# that GPLv3 Section 2(b) requires that all modifications to the 
# original code as well as all Derivative Works must also be 
# released under the terms of the GPLv3 open source license.
# 
# Closed Source Projects:
# 
# If you are developing and distributing traditional closed source 
# applications, you must purchase a RSVP-SIS commercial use license, 
# which is specifically designed for users interested in retaining 
# the proprietary status of their code. All RSVP-SIS commercial licenses 
# expressly supersede the GPLv3 open source license. This means that 
# when you license the RSVP-SIS software under a commercial license, 
# you specifically do not use the software under the open source 
# license and therefore you are not subject to any of its terms.
#
# Commercial licensing options available on the RSVP-SIS Website at : 
#	http://www.rsvpsis.org/licensing/
#
#*****************************************************************************
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, 
# BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
# COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED 
# AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE 
# USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
/* End of rsvp_io.c */


/*******************************************************************************
* File Name: CPM1_P.h  
* Version 2.10
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_CPM1_P_ALIASES_H) /* Pins CPM1_P_ALIASES_H */
#define CY_PINS_CPM1_P_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define CPM1_P_0		(CPM1_P__0__PC)
#define CPM1_P_0_PS		(CPM1_P__0__PS)
#define CPM1_P_0_PC		(CPM1_P__0__PC)
#define CPM1_P_0_DR		(CPM1_P__0__DR)
#define CPM1_P_0_SHIFT	(CPM1_P__0__SHIFT)


#endif /* End Pins CPM1_P_ALIASES_H */


/* [] END OF FILE */

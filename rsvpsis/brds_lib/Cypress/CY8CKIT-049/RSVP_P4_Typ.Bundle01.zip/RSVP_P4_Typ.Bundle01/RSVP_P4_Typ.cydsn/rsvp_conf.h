/**
  ******************************************************************************
    @file        rsvp_conf.h
    @author      Tom Moxon
    @copyright   PatternAgents, LLC
    @brief       The include file to define the RsVpSiS configuration.
  ******************************************************************************
  */

/*-----------------------------------------------------------------------------*/
/* Define to prevent recursive inclusion                                       */
/*-----------------------------------------------------------------------------*/
#ifndef RSVP_CONF_H_
#define RSVP_CONF_H_

/* Define to support C++ */
#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */
	
/*-----------------------------------------------------------------------------*/
/* Include Files                                                               */
/*-----------------------------------------------------------------------------*/
#include <project.h>
#include <rsvp_types.h>
#include <CyLib.h>
#include <cydevice_trm.h>

/** @addtogroup rsvp_conf rsvp_conf
  * @{
  */

/*-----------------------------------------------------------------------------*/
/* Exported Types                                                              */
/*-----------------------------------------------------------------------------*/
/** @defgroup rsvp_conf_Exported_Types
  * @{
  */
typedef enum {FALSE = 0, TRUE = !FALSE} bool;

/**
  * Close the Doxygen rsvp_conf__Exported_Types group.
  * @}
  */

/*-----------------------------------------------------------------------------*/
/* Exported Constants                                                          */
/*-----------------------------------------------------------------------------*/
/** @defgroup rsvp_conf_Exported_Constants
  * @{
  */
/*-----------------------------------------------------------------------------*/
/* Platform CPU Constants */
/** @TODO can we init theses automatically, from creator variables?            */
/*-----------------------------------------------------------------------------*/
#define RSVP_CPU_FREQ			        ( 24000000u )
#define RSVP_CPU_TYPE                   "arm cortex-m0"

/*-----------------------------------------------------------------------------*/
/* Basic RSVP Definitions                                                      */
/*-----------------------------------------------------------------------------*/
#define RSVP_DELAY_1S                   ( 1000 )
#define RSVP_HIGH_IMPEDANCE             ( 0x00000000 )

/*-----------------------------------------------------------------------------*/
/* enable/disable rsvp_sis system code                                         */
/*                                                                             */
#if !defined(RSVP_USE_RSVPSIS) || defined(__DOXYGEN__)
	#if !defined(RSVP_SIS_PG__DISABLED)
		#define RSVP_USE_RSVPSIS            TRUE		
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable rsvp_cli code                                                */
/*                                                                             */
#if !defined(RSVP_USE_CLI) || defined(__DOXYGEN__)
	#if !defined(RSVP_CLI_PG__DISABLED)
		#define RSVP_USE_CLI                TRUE
		#define RSVP_CLI_CHANNEL            1
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable rsvp_io code                                                 */
/*                                                                             */
#if !defined(RSVP_USE_IO) || defined(__DOXYGEN__)
	#if !defined(RSVP_IO_PG__DISABLED)
		#define RSVP_USE_IO                TRUE		
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/*  emulated EEPROM / IPMI FRU flash memory block                              */
/*                                                                             */
#if !defined(RSVP_USE_EEPROM_1) || defined(__DOXYGEN__)
	#if !defined(EEPROM_1_PG__DISABLED)
		#define RSVP_USE_EEPROM_1           TRUE		
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable LVDT_1 resources                                             */
/*                                                                             */
#if !defined(RSVP_USE_LVDT_1) || defined(__DOXYGEN__)
	#if !defined(LVDT_1_PG__DISABLED)
		#define RSVP_USE_LVDT_1             TRUE		
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable WDT_1 resources                                              */
/*                                                                             */
#if !defined(RSVP_USE_WDT_1) || defined(__DOXYGEN__)
	#if !defined(WDT_1_PG__DISABLED)
		#define RSVP_USE_WDT_1                TRUE		
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable SysTick resources                                             */
/*                                                                             */
#if !defined(RSVP_USE_SYSTICK) || defined(__DOXYGEN__)
	#if !defined(SYSTICK_PG__DISABLED)
		#define RSVP_USE_SYSTICK                TRUE		
		#define RSVP_SYSTICK_TYPE               "arm cortex-m0"		
        #define RSVP_SYSTICK_FREQ			    ( 1000u )
        #define RSVP_SYSTICK_NVIC			    ( 15 )
        #define RSVP_SYSTICK_CONFIG			    ( RSVP_CPU_FREQ / RSVP_SYSTICK_FREQ )
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable TIMER_1 resources                                            */
/*                                                                             */
#if !defined(RSVP_USE_TIMER_1) || defined(__DOXYGEN__)
	#if !defined(TIMER_1_PG__DISABLED)
		#define RSVP_USE_TIMER_1                TRUE		
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable TIMER_2 resources                                            */
/*                                                                             */
#if !defined(RSVP_USE_TIMER_2) || defined(__DOXYGEN__)
	#if !defined(TIMER_2_PG__DISABLED)
		#define RSVP_USE_TIMER_2                TRUE		
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable TIMER_3 resources                                            */
/*                                                                             */
#if !defined(RSVP_USE_TIMER_3) || defined(__DOXYGEN__)
	#if !defined(TIMER_3_PG__DISABLED)
		#define RSVP_USE_TIMER_3                TRUE		
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable TIMER_4 resources                                            */
/*                                                                             */
#if !defined(RSVP_USE_TIMER_4) || defined(__DOXYGEN__)
	#if !defined(TIMER_4_PG__DISABLED)
		#define RSVP_USE_TIMER_4                TRUE		
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable I2C_1 resources                                              */
/*                                                                             */
#if !defined(RSVP_USE_I2C_1) || defined(__DOXYGEN__)
	#if !defined(I2C_1_PG__DISABLED)
		#define RSVP_USE_I2C_1                TRUE		
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable UART_1 resources                                             */
/*                                                                             */
#if !defined(RSVP_USE_UART_1) || defined(__DOXYGEN__)
	#if !defined(UART_1_PG__DISABLED)
		#define RSVP_USE_UART_1                TRUE
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable UART_2 resources                                             */
/*                                                                             */
#if !defined(RSVP_USE_UART_2) || defined(__DOXYGEN__)
	#if !defined(UART_2_PG__DISABLED)
		#define RSVP_USE_UART_2                TRUE		
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable OPAMP_1 resources                                            */
/*                                                                             */
#if !defined(RSVP_USE_OPAMP_1) || defined(__DOXYGEN__)
	#if !defined(OPAMP_1_PG__DISABLED)
		#define RSVP_USE_OPAMP_1                TRUE
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable OPAMP_2 resources                                            */
/*                                                                             */
#if !defined(RSVP_USE_OPAMP_2) || defined(__DOXYGEN__)
	#if !defined(OPAMP_2_PG__DISABLED)
		#define RSVP_USE_OPAMP_2                TRUE
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable CMP_1 resources                                              */
/*                                                                             */
#if !defined(RSVP_USE_CMP_1) || defined(__DOXYGEN__)
	#if !defined(CMP_1_PG__DISABLED)
		#define RSVP_USE_CMP_1                TRUE
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable CMP_2 resources                                              */
/*                                                                             */
#if !defined(RSVP_USE_CMP_2) || defined(__DOXYGEN__)
	#if !defined(CMP_2_PG__DISABLED)
		#define RSVP_USE_CMP_2                TRUE
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable ADC resources                                                */
/*                                                                             */
#if !defined(RSVP_USE_ADC_1) || defined(__DOXYGEN__)
	#if !defined(ADC_1_PG__DISABLED)
		#define RSVP_USE_ADC_1                TRUE
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable DAC_1 resources                                              */
/*                                                                             */
#if !defined(RSVP_USE_DAC_1) || defined(__DOXYGEN__)
	#if !defined(DAC_1_PG__DISABLED)
		#define RSVP_USE_DAC_1                TRUE
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable DAC_2 resources                                              */
/*                                                                             */
#if !defined(RSVP_USE_DAC_2) || defined(__DOXYGEN__)
	#if !defined(CMP_2_PG__DISABLED)
		#define RSVP_USE_DAC_2                TRUE
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable SPWM (Software PWM) resources                                */
/*                                                                             */
#if !defined(RSVP_USE_SPWM_1) || defined(__DOXYGEN__)
	#if !defined(RSVP_SPWM_PG__DISABLED)
		#define RSVP_USE_SPWM_1                TRUE		
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable user LED resources                                           */
/*                                                                             */
#if !defined(RSVP_USE_USER_LED) || defined(__DOXYGEN__)
	#if !defined(USER_LED_PG__DISABLED)
		#define RSVP_USE_USER_LED                TRUE		
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable user switch (input pushbutton) resources */
/*                                                                             */
#if !defined(RSVP_USE_USER_SW) || defined(__DOXYGEN__)
	#if !defined(USER_SW_PG__DISABLED)
		#define RSVP_USE_USER_SW                TRUE		
	#endif
#endif

/**
  * Close the Doxygen rsvp_conf_Exported_Constants group.
  * @}
  */

/*-----------------------------------------------------------------------------*/
/* Exported Macros                                                             */
/*-----------------------------------------------------------------------------*/
/** @defgroup rsvp_conf_Exported_Macros
  * @{
  */

/**
  * Close the Doxygen rsvp_conf_Exported_Macros group.
  * @}
  */

/*-----------------------------------------------------------------------------*/
/* Exported Variable Declarations                                              */
/*-----------------------------------------------------------------------------*/
/** @defgroup rsvp_conf_Exported_Variables
  * @{
  */

/** Platform Globals */

/**
  * Close the Doxygen rsvp_conf_Exported_Variables group.
  * @}
  */

/*-----------------------------------------------------------------------------*/
/* Exported Function Declarations                                              */
/*-----------------------------------------------------------------------------*/
/** @defgroup rsvp_conf_Exported_Functions
  * @{
  */

/**
  * Close the Doxygen rsvp_conf_Exported_Functions group.
  * @}
  */

/*-----------------------------------------------------------------------------*/
/* End of the C bindings section for C++ compilers.                            */
/*-----------------------------------------------------------------------------*/
#ifdef __cplusplus
}
#endif

#endif /* RSVP_CONF_H_ */

/*-----------------------------------------------------------------------------*/
/**
  * Close the Doxygen rsvp_conf group.
  *    @}
*/
/*****************************************************************************
# Copyright:	(C) 2013-2015 by PatternAgents,LLC. All rights reserved.
#*****************************************************************************
# RSVP-SIS Licensing Model:
# 
# RSVP-SIS uses the increasingly popular business model called 
# "Dual Licensing" in which both the open source software distribution 
# mechanism and traditional commercial software distribution models 
# are combined.
# 
# Open Source Projects:
# 
# If you are developing and distributing open source applications 
# under the GNU General Public License version 3 (GPLv3), 
# as published by the Free Software Foundation, then you are free 
# to use the RSVP-SIS software under the GPLv3 license. Please note 
# that GPLv3 Section 2(b) requires that all modifications to the 
# original code as well as all Derivative Works must also be 
# released under the terms of the GPLv3 open source license.
# 
# Closed Source Projects:
# 
# If you are developing and distributing traditional closed source 
# applications, you must purchase a RSVP-SIS commercial use license, 
# which is specifically designed for users interested in retaining 
# the proprietary status of their code. All RSVP-SIS commercial licenses 
# expressly supersede the GPLv3 open source license. This means that 
# when you license the RSVP-SIS software under a commercial license, 
# you specifically do not use the software under the open source 
# license and therefore you are not subject to any of its terms.
#
# Commercial licensing options available on the RSVP-SIS Website at : 
#	http://www.rsvpsis.org/licensing/
#
#*****************************************************************************
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, 
# BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
# COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED 
# AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE 
# USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
/* End of File : rsvp_conf.h */
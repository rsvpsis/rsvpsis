/**
 ******************************************************************************
    @file        rsvp_adc.c
    @author      Tom Moxon
    @copyright   PatternAgents, LLC
    @brief       This file provides the rsvp_adc Analog-to-Digital Converter routines.
    @section     rsvp_adc_intro rsvp_adc hardware routines
    @par	
    @section    rsvp_adc_theory Theory of Operation
    @par
    theory \n
	@par
    more \n

 ******************************************************************************
*/

/*-----------------------------------------------------------------------------*/
/* Include Files                                                               */
/*-----------------------------------------------------------------------------*/
#include <rsvp_types.h>
#include <rsvp_conf.h>
#include <rsvp_interrupts.h>
#include <rsvp_platform.h>
#include <rsvp_adc.h>
#include <CyLib.h>
#include <cydevice_trm.h>
#include <cydisabledsheets.h>

/*-----------------------------------------------------------------------------*/
/** @defgroup rsvp_adc rsvp_adc
  * @{
  */

/*-----------------------------------------------------------------------------*/
/* Global variables                                                            */
/*-----------------------------------------------------------------------------*/

/**
  * @fn         rsvp_RetCode_t rsvp_platform_PollADC(void)
  * @brief      get an ADC channel reading
  * @param      None.
  * @retval     rsvp_RetCode_t
  */
rsvp_RetCode_t
rsvp_ADC_Poll(void)
{
  #if (RSVP_USE_ADC_1 == TRUE)
 // rsvp_u8_t channum;
	/* if the ADC conversion is done... */
    if (adc_1_irq_flag != 0u) {	
        /* Check for ADC window limit interrupt */
        if(adc_1_range_flag != 0u)
        {
            /* input is outside the voltage window (250mV - 750mV) */
			/* add error handler here                              */
        }
		adc_1_irq_flag = 0;
		/* do anything else when ADC data is ready? */
	}
  #endif
	return(RSVP_SUCCESS);
}

/*-----------------------------------------------------------------------------*/
/**
  * Close the Doxygen main group.
  *    @}
*/
/*****************************************************************************
# Copyright:	(C) 2013-2015 by PatternAgents,LLC. All rights reserved.
#*****************************************************************************
# RSVP-SIS Licensing Model:
# 
# RSVP-SIS uses the increasingly popular business model called 
# "Dual Licensing" in which both the open source software distribution 
# mechanism and traditional commercial software distribution models 
# are combined.
# 
# Open Source Projects:
# 
# If you are developing and distributing open source applications 
# under the GNU General Public License version 3 (GPLv3), 
# as published by the Free Software Foundation, then you are free 
# to use the RSVP-SIS software under the GPLv3 license. Please note 
# that GPLv3 Section 2(b) requires that all modifications to the 
# original code as well as all Derivative Works must also be 
# released under the terms of the GPLv3 open source license.
# 
# Closed Source Projects:
# 
# If you are developing and distributing traditional closed source 
# applications, you must purchase a RSVP-SIS commercial use license, 
# which is specifically designed for users interested in retaining 
# the proprietary status of their code. All RSVP-SIS commercial licenses 
# expressly supersede the GPLv3 open source license. This means that 
# when you license the RSVP-SIS software under a commercial license, 
# you specifically do not use the software under the open source 
# license and therefore you are not subject to any of its terms.
#
# Commercial licensing options available on the RSVP-SIS Website at : 
#	http://www.rsvpsis.org/licensing/
#
#*****************************************************************************
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, 
# BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
# COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED 
# AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE 
# USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
/* End of rsvp_adc.c */

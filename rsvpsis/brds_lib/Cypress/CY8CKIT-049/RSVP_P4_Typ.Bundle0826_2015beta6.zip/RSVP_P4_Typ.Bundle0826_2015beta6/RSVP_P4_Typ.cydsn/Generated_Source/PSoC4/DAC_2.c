/*******************************************************************************
* File Name: DAC_2.c
* Version 1.10
*
* Description:
*  This file provides the source code of APIs for the IDAC_P4 component.
*
*******************************************************************************
* Copyright 2013-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "DAC_2.h"

uint32 DAC_2_initVar = 0u;


/*******************************************************************************
* Function Name: DAC_2_Init
********************************************************************************
*
* Summary:
*  Initializes IDAC registers with initial values provided from customizer.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  None
*
*******************************************************************************/
void DAC_2_Init(void)
{
    uint32 regVal;
    uint8 enableInterrupts;

    /* Set initial configuration */
    enableInterrupts = CyEnterCriticalSection();
    
    #if(DAC_2_MODE_SOURCE == DAC_2_IDAC_POLARITY)
        regVal  = DAC_2_CSD_TRIM1_REG & ~(DAC_2_CSD_IDAC_TRIM1_MASK);
        regVal |=  (DAC_2_SFLASH_TRIM1_REG & DAC_2_CSD_IDAC_TRIM1_MASK);
        DAC_2_CSD_TRIM1_REG = regVal;
    #else
        regVal  = DAC_2_CSD_TRIM2_REG & ~(DAC_2_CSD_IDAC_TRIM2_MASK);
        regVal |=  (DAC_2_SFLASH_TRIM2_REG & DAC_2_CSD_IDAC_TRIM2_MASK);
        DAC_2_CSD_TRIM2_REG = regVal;
    #endif /* (DAC_2_MODE_SOURCE == DAC_2_IDAC_POLARITY) */

    /* clear previous values */
    DAC_2_IDAC_CONTROL_REG &= ((uint32)~((uint32)DAC_2_IDAC_VALUE_MASK <<
        DAC_2_IDAC_VALUE_POSITION)) | ((uint32)~((uint32)DAC_2_IDAC_MODE_MASK <<
        DAC_2_IDAC_MODE_POSITION))  | ((uint32)~((uint32)DAC_2_IDAC_RANGE_MASK  <<
        DAC_2_IDAC_RANGE_POSITION));

    DAC_2_IDAC_POLARITY_CONTROL_REG &= (~(uint32)((uint32)DAC_2_IDAC_POLARITY_MASK <<
        DAC_2_IDAC_POLARITY_POSITION));

    /* set new configuration */
    DAC_2_IDAC_CONTROL_REG |= (((uint32)DAC_2_IDAC_INIT_VALUE <<
        DAC_2_IDAC_VALUE_POSITION) | ((uint32)DAC_2_IDAC_RANGE <<
        DAC_2_IDAC_RANGE_POSITION));

    DAC_2_IDAC_POLARITY_CONTROL_REG |= ((uint32)DAC_2_IDAC_POLARITY <<
                                                           DAC_2_IDAC_POLARITY_POSITION);

    CyExitCriticalSection(enableInterrupts);

}


/*******************************************************************************
* Function Name: DAC_2_Enable
********************************************************************************
*
* Summary:
*  Enables IDAC operations.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  None
*
*******************************************************************************/
void DAC_2_Enable(void)
{
    uint8 enableInterrupts;

    enableInterrupts = CyEnterCriticalSection();

    /* Enable the IDAC */
    DAC_2_IDAC_CONTROL_REG |= ((uint32)DAC_2_IDAC_EN_MODE <<
                                                  DAC_2_IDAC_MODE_POSITION);
    DAC_2_IDAC_POLARITY_CONTROL_REG |= ((uint32)DAC_2_IDAC_CSD_EN <<
                                                           DAC_2_IDAC_CSD_EN_POSITION);
    CyExitCriticalSection(enableInterrupts);

}


/*******************************************************************************
* Function Name: DAC_2_Start
********************************************************************************
*
* Summary:
*  Starts the IDAC hardware.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  DAC_2_initVar
*
*******************************************************************************/
void DAC_2_Start(void)
{
    if(0u == DAC_2_initVar)
    {
        DAC_2_Init();
        DAC_2_initVar = 1u;
    }

    DAC_2_Enable();

}


/*******************************************************************************
* Function Name: DAC_2_Stop
********************************************************************************
*
* Summary:
*  Stops the IDAC hardware.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  None
*
*******************************************************************************/
void DAC_2_Stop(void)
{
    uint8 enableInterrupts;

    enableInterrupts = CyEnterCriticalSection();

    /* Disable the IDAC */
    DAC_2_IDAC_CONTROL_REG &= ((uint32)~((uint32)DAC_2_IDAC_MODE_MASK <<
        DAC_2_IDAC_MODE_POSITION));
    CyExitCriticalSection(enableInterrupts);
}


/*******************************************************************************
* Function Name: DAC_2_SetValue
********************************************************************************
*
* Summary:
*  Sets the IDAC value.
*
* Parameters:
*  uint32 value
*
* Return:
*  None
*
* Global variables:
*  None
*
*******************************************************************************/
void DAC_2_SetValue(uint32 value)
{
    uint8 enableInterrupts;
    uint32 newRegisterValue;

    enableInterrupts = CyEnterCriticalSection();

    #if(DAC_2_IDAC_VALUE_POSITION != 0u)
        newRegisterValue = ((DAC_2_IDAC_CONTROL_REG & (~(uint32)((uint32)DAC_2_IDAC_VALUE_MASK <<
        DAC_2_IDAC_VALUE_POSITION))) | (value << DAC_2_IDAC_VALUE_POSITION));
    #else
        newRegisterValue = ((DAC_2_IDAC_CONTROL_REG & (~(uint32)DAC_2_IDAC_VALUE_MASK)) | value);
    #endif /* DAC_2_IDAC_VALUE_POSITION != 0u */

    DAC_2_IDAC_CONTROL_REG = newRegisterValue;

    CyExitCriticalSection(enableInterrupts);
}

/* [] END OF FILE */

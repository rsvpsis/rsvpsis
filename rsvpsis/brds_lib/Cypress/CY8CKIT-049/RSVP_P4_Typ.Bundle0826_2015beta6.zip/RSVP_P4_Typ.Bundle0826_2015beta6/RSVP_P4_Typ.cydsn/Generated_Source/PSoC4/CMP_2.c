/*******************************************************************************
* File Name: CMP_2.c
* Version 2.10
*
* Description:
*  This file provides the source code to the API for the Low Power Comparator
*  component.
*
* Note:
*  None
*
********************************************************************************
* Copyright 2013-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "CMP_2.h"
#include "CyLib.h"
#include "cyPm.h"

uint8 CMP_2_initVar = 0u;
static uint32 CMP_2_internalIntr = 0u;
#if(CMP_2_CY_LPCOMP_V2)
    #if(CY_IP_SRSSV2)
        /* This variable saves INTR_MASK register since it get reset after wakeup 
        * from Hibernate. Attribute CY_NOINIT puts SRAM variable in memory section 
        * which is retained in low power modes 
        */
        CY_NOINIT static uint32 CMP_2_intrMaskRegState;
    #endif /* (CY_IP_SRSSV2) */
#endif /* (CMP_2_CY_LPCOMP_V2) */


/*******************************************************************************
* Function Name: CMP_2_Start
********************************************************************************
*
* Summary:
*  Performs all of the required initialization for the component and enables
*  power to the block. The first time the routine is executed, the component is
*  initialized to the configuration from the customizer. When called to restart
*  the comparator following a CMP_2_Stop() call, the current
*  component parameter settings are retained.
*
* Parameters:
*   None
*
* Return:
*  None
*
* Global variables:
*  CMP_2_initVar: Is modified when this function is called for the
*   first time. Is used to ensure that initialization happens only once.
*
*******************************************************************************/
void CMP_2_Start(void)
{
    if(0u == CMP_2_initVar)
    {
        CMP_2_Init();
        CMP_2_initVar = 1u;
    }
    CMP_2_Enable();
}


/*******************************************************************************
* Function Name: CMP_2_Init
********************************************************************************
*
* Summary:
*  Initializes or restores the component according to the customizer settings.
*  It is not necessary to call CMP_2_Init() because the
*  CMP_2_Start() API calls this function and is the preferred method
*  to begin component operation.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void CMP_2_Init(void)
{
    uint8 enableInterrupts;

    enableInterrupts = CyEnterCriticalSection();
    CMP_2_CONFIG_REG |= CMP_2_CONFIG_REG_DEFAULT;
    
    #if (CMP_2_CY_LPCOMP_V2)
        #if(CY_IP_SRSSV2)
            if (CySysPmGetResetReason() == CY_PM_RESET_REASON_WAKEUP_HIB)
            {
                /* Restore the INTR_MASK register state since it get reset after 
                * wakeup from Hibernate.  
                */
                CMP_2_INTR_MASK_REG |= CMP_2_intrMaskRegState;  
            }
            else
            {
                CMP_2_INTR_MASK_REG |= CMP_2_INTR_MASK_REG_DEFAULT;    
                CMP_2_intrMaskRegState = CMP_2_INTR_MASK_REG;
            }
        #else
            CMP_2_INTR_MASK_REG |= CMP_2_INTR_MASK_REG_DEFAULT;
        #endif /* (CMP_2_CY_LPCOMP_V2) */
    #endif /* (CMP_2_CY_LPCOMP_V2) */
    
    CyExitCriticalSection(enableInterrupts);
}


/*******************************************************************************
* Function Name: CMP_2_Enable
********************************************************************************
*
* Summary:
*  Activates the hardware and begins component operation. It is not necessary
*  to call CMP_2_Enable() because the CMP_2_Start() API
*  calls this function, which is the preferred method to begin component
*  operation.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void CMP_2_Enable(void)
{
    uint8 enableInterrupts;
    
    enableInterrupts = CyEnterCriticalSection();
    CMP_2_CONFIG_REG |= CMP_2_CONFIG_EN;
    
    /*******************************************************
    * When the Enable() API is called the CONFIG_EN bit is set. 
    * This can cause fake interrupt because of the output delay 
    * of the analog. This requires setting the CONFIG_INTR bits 
    * after the CONFIG_EN bit is set.
    *******************************************************/
    CMP_2_CONFIG_REG |= CMP_2_internalIntr;
    CyExitCriticalSection(enableInterrupts);
}


/*******************************************************************************
* Function Name: CMP_2_Stop
********************************************************************************
*
* Summary:
*  Turns off the LP Comparator.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Side Effects:
*  The function doesn't change component Speed settings.
*
*******************************************************************************/
void CMP_2_Stop(void)
{
    uint8 enableInterrupts;
    
    enableInterrupts = CyEnterCriticalSection();
    #if (CMP_2_CY_LPCOMP_V0)
        /*******************************************************
        * When the Stop() API is called the CONFIG_EN bit is 
        * cleared. This causes the output of the comparator to go 
        * low. If the comparator output was high and the Interrupt 
        * Configuration is set for Falling edge disabling the 
        * comparator will cause an fake interrupt. This requires 
        * to clear the CONFIG_INTR bits before the CONFIG_EN bit 
        * is cleared.
        *******************************************************/
        CMP_2_CONFIG_REG &= (uint32)~CMP_2_CONFIG_INTR_MASK;
    #endif /* (CMP_2_CY_LPCOMP_V0) */

    CMP_2_CONFIG_REG &= (uint32)~CMP_2_CONFIG_EN;
    CyExitCriticalSection(enableInterrupts);
}


/*******************************************************************************
* Function Name: CMP_2_SetSpeed
*
* Summary:
*  Sets the drive power and speed to one of three settings.
*
* Parameters:
*  uint32 speed: Sets operation mode of the component:
*   CMP_2_LOW_SPEED  - Slow/ultra low 
*   CMP_2_MED_SPEED  - Medium/low 
*   CMP_2_HIGH_SPEED - Fast/normal 
*
* Return:
*  None
*
*******************************************************************************/
void CMP_2_SetSpeed(uint32 speed)
{
    uint32 config;
    uint8 enableInterrupts;
    
    enableInterrupts = CyEnterCriticalSection();
    config = CMP_2_CONFIG_REG & (uint32)~CMP_2_CONFIG_SPEED_MODE_MASK;
    CMP_2_CONFIG_REG = config | CMP_2_GET_CONFIG_SPEED_MODE(speed);
    CyExitCriticalSection(enableInterrupts);
}


/*******************************************************************************
* Function Name: CMP_2_SetInterruptMode
********************************************************************************
*
* Summary:
*  Sets the interrupt edge detect mode. This also controls the value provided
*  on the output.
*
* Parameters:
*  uint32 mode: Enumerated edge detect mode value:
*  CMP_2_INTR_DISABLE - Disable
*  CMP_2_INTR_RISING  - Rising edge detect
*  CMP_2_INTR_FALLING - Falling edge detect
*  CMP_2_INTR_BOTH    - Detect both edges
*
* Return:
*  None
*
*******************************************************************************/
void CMP_2_SetInterruptMode(uint32 mode)
{
    uint32 config;
    uint8 enableInterrupts;
    
    CMP_2_internalIntr = CMP_2_GET_CONFIG_INTR(mode);

    enableInterrupts = CyEnterCriticalSection();
    config = CMP_2_CONFIG_REG & (uint32)~CMP_2_CONFIG_INTR_MASK;
    CMP_2_CONFIG_REG = config | CMP_2_internalIntr;
    CyExitCriticalSection(enableInterrupts);
}


/*******************************************************************************
* Function Name: CMP_2_GetInterruptSource
********************************************************************************
*
* Summary:
*  Gets the interrupt requests. This function is for use when using the combined
*  interrupt signal from the global signal reference. This function from either
*  component instance can be used to determine the interrupt source for both the
*  interrupts combined.
*
* Parameters:
*  None
*
* Return:
*  uint32: Interrupt source. Each component instance has a mask value:
*  CMP_2_INTR.
*
*******************************************************************************/
uint32 CMP_2_GetInterruptSource(void)
{
    return (CMP_2_INTR_REG); 
}


/*******************************************************************************
* Function Name: CMP_2_ClearInterrupt
********************************************************************************
*
* Summary:
*  Clears the interrupt request. This function is for use when using the
*  combined interrupt signal from the global signal reference. This function
*  from either component instance can be used to clear either or both
*  interrupts.
*
* Parameters:
*  uint32 interruptMask: Mask of interrupts to clear. Each component instance
*  has a mask value: CMP_2_INTR.
*
* Return:
*  None
*
*******************************************************************************/
void CMP_2_ClearInterrupt(uint32 interruptMask)
{   
    CMP_2_INTR_REG = interruptMask;
}


/*******************************************************************************
* Function Name: CMP_2_SetInterrupt
********************************************************************************
*
* Summary:
*  Sets a software interrupt request. This function is for use when using the
*  combined interrupt signal from the global signal reference. This function
*  from either component instance can be used to trigger either or both software
*  interrupts.
*
* Parameters:
*  uint32 interruptMask: Mask of interrupts to set. Each component instance has
*  a mask value: CMP_2_INTR_SET.
*
* Return:
*  None
*
*******************************************************************************/
void CMP_2_SetInterrupt(uint32 interruptMask)
{
    uint8 enableInterrupts;
    
    enableInterrupts = CyEnterCriticalSection();
    CMP_2_INTR_SET_REG |= interruptMask;
    CyExitCriticalSection(enableInterrupts);
}


/*******************************************************************************
* Function Name: CMP_2_SetHysteresis
********************************************************************************
*
* Summary:
*  Enables or disables the hysteresis.
*
* Parameters:
*  hysteresis: (uint32) Enables or disables the hysteresis setting.
*  CMP_2_HYST_ENABLE     - Enable hysteresis
*  CMP_2_HYST_DISABLE    - Disable hysteresis
*
* Return:
*  None
*
*******************************************************************************/
void CMP_2_SetHysteresis(uint32 hysteresis)
{
    uint8 enableInterrupts;
    
    enableInterrupts = CyEnterCriticalSection();
    if(0u != hysteresis)
    {
        CMP_2_CONFIG_REG |= CMP_2_CONFIG_HYST;
    }
    else
    {
        CMP_2_CONFIG_REG &= (uint32)~CMP_2_CONFIG_HYST;
    }
    CyExitCriticalSection(enableInterrupts);
}


/*******************************************************************************
* Function Name: CMP_2_SetFilter
********************************************************************************
*
* Summary:
*  Enables or disables the digital filter. This still exists for saving backward 
*  compatibility, but not recommended for using.
*  This API is DEPRECATED and should not be used in new projects.
*
* Parameters:
*  uint32 filter: filter enable.
*  CMP_2_FILT_ENABLE  - Enable filter
*  CMP_2_FILT_DISABLE - Disable filter
*
* Return:
*  None
*
*******************************************************************************/
void CMP_2_SetFilter(uint32 filter)
{
    uint8 enableInterrupts;
    
    enableInterrupts = CyEnterCriticalSection();
    if( 0u != filter)
    {
        CMP_2_CONFIG_REG |= CMP_2_CONFIG_FILT;
    }
    else
    {
        CMP_2_CONFIG_REG &= (uint32)~CMP_2_CONFIG_FILT;
    }
    CyExitCriticalSection(enableInterrupts);
}


/*******************************************************************************
* Function Name: CMP_2_GetCompare
********************************************************************************
*
* Summary:
*  This function returns a nonzero value when the voltage connected to the
*  positive input is greater than the negative input voltage.
*  This function reads the direct (unflopped) comparator output which can also be 
*  metastable (since it may result in incorrect data).
*
* Parameters:
*  None
*
* Return:
*  (uint32) Comparator output state. This value is not impacted by the interrupt
*  edge detect setting:
*   0 - if positive input is less than negative one.
*   1 - if positive input greater than negative one.
*
*******************************************************************************/
uint32 CMP_2_GetCompare(void)
{
    return((uint32)((0u == (CMP_2_CONFIG_REG & CMP_2_CONFIG_OUT)) ? 0u : 1u));
}


/*******************************************************************************
* Function Name: CMP_2_ZeroCal
********************************************************************************
*
* Summary:
*  Performs custom calibration of the input offset to minimize error for a
*  specific set of conditions: comparator reference voltage, supply voltage,
*  and operating temperature. A reference voltage in the range at which the
*  comparator will be used must be applied to one of the inputs. The two inputs
*  will be shorted internally to perform the offset calibration.
*
* Parameters:
*  None
*
* Return:
*  The value from the comparator trim register after the offset calibration is
*  complete. This value has the same format as the input parameter for the
*  CMP_2_LoadTrim() API routine.
*
*******************************************************************************/
uint32 CMP_2_ZeroCal(void)
{
    uint32 cmpOut;
    uint32 i;

    CMP_2_DFT_REG |= CMP_2_DFT_CAL_EN;
    CMP_2_TRIMA_REG = 0u;
    CMP_2_TRIMB_REG = 0u;

    CyDelayUs(1u);

    cmpOut = CMP_2_GetCompare();

    if(0u != cmpOut)
    {
        CMP_2_TRIMA_REG = ((uint32) 0x01u << CMP_2_TRIMA_SIGNBIT);
    }

    for(i = (CMP_2_TRIMA_MAX_VALUE +1u ); i != 0u; i--)
    {
        CMP_2_TRIMA_REG++;
        CyDelayUs(1u);
        if(cmpOut != CMP_2_GetCompare())
        {
            break;
        }
    }

    if(((uint32)(CMP_2_CONFIG_REG >> CMP_2_CONFIG_REG_SHIFT) &
        CMP_2_SPEED_PARAM_MASK) == CMP_2_MED_SPEED)
    {
        cmpOut = CMP_2_GetCompare();

        if(0u == cmpOut)
        {
            CMP_2_TRIMB_REG = ((uint32)1u << CMP_2_TRIMB_SIGNBIT);
        }

        for(i = (CMP_2_TRIMB_MAX_VALUE +1u ); i != 0u; i--)
        {
            CMP_2_TRIMB_REG++;
            CyDelayUs(1u);
            if(cmpOut != CMP_2_GetCompare())
            {
                break;
            }
        }
    }

    CMP_2_DFT_REG &= ((uint32)~CMP_2_DFT_CAL_EN);

    return (CMP_2_TRIMA_REG | ((uint32)CMP_2_TRIMB_REG << CMP_2_TRIMB_SHIFT));
}


/*******************************************************************************
* Function Name: CMP_2_LoadTrim
********************************************************************************
*
* Summary:
*  This function writes a value into the comparator offset trim register.
*
* Parameters:
*  trimVal: Value to be stored in the comparator offset trim register. This
*  value has the same format as the parameter returned by the
*  CMP_2_ZeroCal() API routine.
*
* Return:
*  None
*
*******************************************************************************/
void CMP_2_LoadTrim(uint32 trimVal)
{
    CMP_2_TRIMA_REG = (trimVal & CMP_2_TRIMA_MASK);
    CMP_2_TRIMB_REG = ((trimVal >> CMP_2_TRIMB_SHIFT) & CMP_2_TRIMB_MASK);
}


#if (CMP_2_CY_LPCOMP_V2)
    
/*******************************************************************************
* Function Name: CMP_2_SetOutputMode
********************************************************************************
*
* Summary:
*  Set comparator output mode. 
*
* Parameters:
*  uint32 mode: Comparator output mode value
*  CMP_2_OUT_DIRECT - Direct output
*  CMP_2_OUT_SYNC   - Synchronized output
*  CMP_2_OUT_PULSE  - Pulse output
*
* Return:
*  None
*
*******************************************************************************/
void CMP_2_SetOutputMode(uint32 mode)
{
    uint32 config;
    uint8 enableInterrupts;
    
    enableInterrupts = CyEnterCriticalSection();
    config = CMP_2_CONFIG_REG & ((uint32)~(CMP_2_CONFIG_DSI_BYPASS | \
                                                     CMP_2_CONFIG_DSI_LEVEL));
    CMP_2_CONFIG_REG = config | CMP_2_GET_CONFIG_DSI_BYPASS(mode) | \
                                           CMP_2_GET_CONFIG_DSI_LEVEL(mode);
    CyExitCriticalSection(enableInterrupts);
}


/*******************************************************************************
* Function Name: CMP_2_SetInterruptMask
********************************************************************************
*
* Summary:
*  Configures which bits of interrupt request register will trigger an interrupt 
*  event.
*
* Parameters:
*  uint32 interruptMask: Mask of interrupts to set. Each component instance has
*  a mask value: CMP_2_INTR_MASK.
*
* Return:
*  None
*
*******************************************************************************/
void CMP_2_SetInterruptMask(uint32 interruptMask)
{
    #if(CY_IP_SRSSV2)
        CMP_2_intrMaskRegState = interruptMask;
    #endif /* (CY_IP_SRSSV2) */
    
    CMP_2_INTR_MASK_REG = interruptMask;
}


/*******************************************************************************
* Function Name: CMP_2_GetInterruptMask
********************************************************************************
*
* Summary:
*  Returns interrupt mask.
*
* Parameters:
*  None
*
* Return:
*  uint32:  Mask of enabled interrupt source. Each component instance 
*  has a mask value: CMP_2_INTR_MASK.
*
*******************************************************************************/
uint32 CMP_2_GetInterruptMask(void)
{
    return (CMP_2_INTR_MASK_REG);
}


/*******************************************************************************
* Function Name: CMP_2_GetInterruptSourceMasked
********************************************************************************
*
* Summary:
*  Returns interrupt request register masked by interrupt mask. Returns the result 
*  of bitwise AND operation between corresponding interrupt request and mask bits.
*
* Parameters:
*  None
*
* Return:
*  uint32: Status of enabled interrupt source. Each component instance 
*  has a mask value: CMP_2_INTR_MASKED.
*
*******************************************************************************/
uint32 CMP_2_GetInterruptSourceMasked(void)
{
    return (CMP_2_INTR_MASKED_REG);
}

#endif /* (CMP_2_CY_LPCOMP_V2) */


/* [] END OF FILE */

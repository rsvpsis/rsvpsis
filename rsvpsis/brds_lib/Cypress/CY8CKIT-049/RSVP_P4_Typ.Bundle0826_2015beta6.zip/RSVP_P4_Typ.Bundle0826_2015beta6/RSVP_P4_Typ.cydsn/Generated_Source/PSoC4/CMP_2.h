/*******************************************************************************
* File Name: CMP_2.h
* Version 2.10
*
* Description:
*  This file contains the function prototypes and constants used in
*  the Low Power Comparator component.
*
* Note:
*  None
*
********************************************************************************
* Copyright 2013-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_COMPARATOR_CMP_2_H)
#define CY_COMPARATOR_CMP_2_H

#include "cytypes.h"
#include "cyfitter.h"


extern uint8  CMP_2_initVar;


/***************************************
*  Conditional Compilation Parameters
****************************************/

#define CMP_2_CY_LPCOMP_V0 (CYIPBLOCK_m0s8lpcomp_VERSION == 0u) 
#define CMP_2_CY_LPCOMP_V2 (CYIPBLOCK_m0s8lpcomp_VERSION >= 2u) 


/**************************************
*        Function Prototypes
**************************************/

void    CMP_2_Start(void);
void    CMP_2_Init(void);
void    CMP_2_Enable(void);
void    CMP_2_Stop(void);
void    CMP_2_SetSpeed(uint32 speed);
void    CMP_2_SetInterruptMode(uint32 mode);
uint32  CMP_2_GetInterruptSource(void);
void    CMP_2_ClearInterrupt(uint32 interruptMask);
void    CMP_2_SetInterrupt(uint32 interruptMask);
void    CMP_2_SetHysteresis(uint32 hysteresis);
uint32  CMP_2_GetCompare(void);
uint32  CMP_2_ZeroCal(void);
void    CMP_2_LoadTrim(uint32 trimVal);
void    CMP_2_Sleep(void);
void    CMP_2_Wakeup(void);
void    CMP_2_SaveConfig(void);
void    CMP_2_RestoreConfig(void);
#if(CMP_2_CY_LPCOMP_V2)
    void    CMP_2_SetOutputMode(uint32 mode);
    void    CMP_2_SetInterruptMask(uint32 interruptMask);
    uint32  CMP_2_GetInterruptMask(void);
    uint32  CMP_2_GetInterruptSourceMasked(void);
#endif /* (CMP_2_CY_LPCOMP_V2) */


/**************************************
*           API Constants
**************************************/

#if(CMP_2_CY_LPCOMP_V2)
    /* Constants for CMP_2_SetOutputMode(), mode parameter */
    #define CMP_2_OUT_PULSE      (0x00u)
    #define CMP_2_OUT_SYNC       (0x01u)
    #define CMP_2_OUT_DIRECT     (0x02u)
#endif /* (CMP_2_CY_LPCOMP_V2) */

#define CMP_2_INTR_PARAM_MASK    (0x03u)
#define CMP_2_SPEED_PARAM_MASK   (0x03u)

/* Constants for CMP_2_SetSpeed(), speed parameter */
#define CMP_2_MED_SPEED          (0x00u)
#define CMP_2_HIGH_SPEED         (0x01u)
#define CMP_2_LOW_SPEED          (0x02u)

/* Constants for CMP_2_SetInterruptMode(), mode parameter */
#define CMP_2_INTR_DISABLE       (0x00u)
#define CMP_2_INTR_RISING        (0x01u)
#define CMP_2_INTR_FALLING       (0x02u)
#define CMP_2_INTR_BOTH          (0x03u)

/* Constants for CMP_2_SetHysteresis(), hysteresis parameter */
#define CMP_2_HYST_ENABLE        (0x00u)
#define CMP_2_HYST_DISABLE       (0x01u)

/* Constants for CMP_2_ZeroCal() */
#define CMP_2_TRIMA_MASK         (0x1Fu)
#define CMP_2_TRIMA_SIGNBIT      (4u)
#define CMP_2_TRIMA_MAX_VALUE    (15u)
#define CMP_2_TRIMB_MASK         (0x1Fu)
#define CMP_2_TRIMB_SHIFT        (8u)
#define CMP_2_TRIMB_SIGNBIT      (4u)
#define CMP_2_TRIMB_MAX_VALUE    (15u)

/* Constants for CMP_2_GetInterruptSource() and 
* CMP_2_ClearInterrupt(), interruptMask parameter 
*/
#define CMP_2_INTR_SHIFT         (CMP_2_cy_psoc4_lpcomp_1__LPCOMP_INTR_SHIFT)
#define CMP_2_INTR               ((uint32)0x01u << CMP_2_INTR_SHIFT)

/* Constants for CMP_2_SetInterrupt(), interruptMask parameter */
#define CMP_2_INTR_SET_SHIFT     (CMP_2_cy_psoc4_lpcomp_1__LPCOMP_INTR_SET_SHIFT)
#define CMP_2_INTR_SET           ((uint32)0x01u << CMP_2_INTR_SHIFT)

#if(CMP_2_CY_LPCOMP_V2)
    /* Constants for CMP_2_GetInterruptMask() and 
    * CMP_2_SetInterruptMask(), interruptMask parameter 
    */
    #define CMP_2_INTR_MASK_SHIFT    (CMP_2_cy_psoc4_lpcomp_1__LPCOMP_INTR_MASK_SHIFT)
    #define CMP_2_INTR_MASK          ((uint32)0x01u << CMP_2_INTR_MASK_SHIFT)

    /* Constants for CMP_2_GetInterruptSourceMasked() */ 
    #define CMP_2_INTR_MASKED_SHIFT  (CMP_2_cy_psoc4_lpcomp_1__LPCOMP_INTR_MASKED_SHIFT)
    #define CMP_2_INTR_MASKED        ((uint32)0x01u << CMP_2_INTR_MASKED_SHIFT)
#endif /* (CMP_2_CY_LPCOMP_V2) */


/***************************************
* Enumerated Types and Parameters 
***************************************/

/* Enumerated Types LPCompSpeedType, Used in parameter Speed */
#define CMP_2__LPC_LOW_SPEED 2
#define CMP_2__LPC_MED_SPEED 0
#define CMP_2__LPC_HIGH_SPEED 1


/* Enumerated Types LPCompInterruptType, Used in parameter Interrupt */
#define CMP_2__LPC_INT_DISABLE 0
#define CMP_2__LPC_INT_RISING 1
#define CMP_2__LPC_INT_FALLING 2
#define CMP_2__LPC_INT_BOTH 3


/* Enumerated Types LPCompHysteresisType, Used in parameter Hysteresis */
#define CMP_2__LPC_DISABLE_HYST 1
#define CMP_2__LPC_ENABLE_HYST 0


/* Enumerated Types OutputModeType, Used in parameter OutputMode */
#define CMP_2__OUT_MODE_SYNC 1
#define CMP_2__OUT_MODE_DIRECT 2
#define CMP_2__OUT_MODE_PULSE 0



/***************************************
*   Initial Parameter Constants
****************************************/

#define CMP_2_INTERRUPT    (1u)
#define CMP_2_SPEED        (0u)
#define CMP_2_HYSTERESIS   (0u)
#if (CMP_2_CY_LPCOMP_V2)
    #define CMP_2_OUT_MODE       (0u)
    #define CMP_2_INTERRUPT_EN   (0u)
#endif /* (CMP_2_CY_LPCOMP_V2) */


/**************************************
*             Registers
**************************************/

#define CMP_2_CONFIG_REG     (*(reg32 *)CMP_2_cy_psoc4_lpcomp_1__LPCOMP_CONFIG)
#define CMP_2_CONFIG_PTR     ( (reg32 *)CMP_2_cy_psoc4_lpcomp_1__LPCOMP_CONFIG)

#define CMP_2_DFT_REG        (*(reg32 *)CYREG_LPCOMP_DFT)
#define CMP_2_DFT_PTR        ( (reg32 *)CYREG_LPCOMP_DFT)

#define CMP_2_INTR_REG       (*(reg32 *)CMP_2_cy_psoc4_lpcomp_1__LPCOMP_INTR)
#define CMP_2_INTR_PTR       ( (reg32 *)CMP_2_cy_psoc4_lpcomp_1__LPCOMP_INTR)

#define CMP_2_INTR_SET_REG   (*(reg32 *)CMP_2_cy_psoc4_lpcomp_1__LPCOMP_INTR_SET)
#define CMP_2_INTR_SET_PTR   ( (reg32 *)CMP_2_cy_psoc4_lpcomp_1__LPCOMP_INTR_SET)

#define CMP_2_TRIMA_REG      (*(reg32 *)CMP_2_cy_psoc4_lpcomp_1__TRIM_A)
#define CMP_2_TRIMA_PTR      ( (reg32 *)CMP_2_cy_psoc4_lpcomp_1__TRIM_A)

#define CMP_2_TRIMB_REG      (*(reg32 *)CMP_2_cy_psoc4_lpcomp_1__TRIM_B)
#define CMP_2_TRIMB_PTR      ( (reg32 *)CMP_2_cy_psoc4_lpcomp_1__TRIM_B)

#if(CMP_2_CY_LPCOMP_V2)
    #define CMP_2_INTR_MASK_REG    (*(reg32 *)CMP_2_cy_psoc4_lpcomp_1__LPCOMP_INTR_MASK) 
    #define CMP_2_INTR_MASK_PTR    ( (reg32 *)CMP_2_cy_psoc4_lpcomp_1__LPCOMP_INTR_MASK) 

    #define CMP_2_INTR_MASKED_REG  (*(reg32 *)CMP_2_cy_psoc4_lpcomp_1__LPCOMP_INTR_MASKED) 
    #define CMP_2_INTR_MASKED_PTR  ( (reg32 *)CMP_2_cy_psoc4_lpcomp_1__LPCOMP_INTR_MASKED) 
#endif /* (CMP_2_CY_LPCOMP_V2) */


/***************************************
*        Registers Constants
***************************************/

#define CMP_2_CONFIG_REG_SHIFT           (CMP_2_cy_psoc4_lpcomp_1__LPCOMP_CONFIG_SHIFT)

/* CMP_2CMP_2_CONFIG_REG */
#define CMP_2_CONFIG_SPEED_MODE_SHIFT    (0u)    /* [1:0]    Operating mode for the comparator      */
#define CMP_2_CONFIG_HYST_SHIFT          (2u)    /* [2]      Add 10mV hysteresis to the comparator: 0-enable, 1-disable */
#define CMP_2_CONFIG_INTR_SHIFT          (4u)    /* [5:4]    Sets Pulse/Interrupt mode              */
#define CMP_2_CONFIG_OUT_SHIFT           (6u)    /* [6]      Current output value of the comparator    */
#define CMP_2_CONFIG_EN_SHIFT            (7u)    /* [7]      Enable comparator */
#if(CMP_2_CY_LPCOMP_V2)
    #define CMP_2_CONFIG_DSI_BYPASS_SHIFT    (16u)   /* [16]   Bypass comparator output synchronization for DSI output  */
    #define CMP_2_CONFIG_DSI_LEVEL_SHIFT     (17u)   /* [17]   Comparator DSI (trigger) out level: 0-pulse, 1-level  */
#endif /* (CMP_2_CY_LPCOMP_V2) */

#define CMP_2_CONFIG_SPEED_MODE_MASK     (((uint32) 0x03u << CMP_2_CONFIG_SPEED_MODE_SHIFT) << \
                                                    CMP_2_CONFIG_REG_SHIFT)

#define CMP_2_CONFIG_HYST                (((uint32) 0x01u << CMP_2_CONFIG_HYST_SHIFT) << \
                                                    CMP_2_CONFIG_REG_SHIFT)

#define CMP_2_CONFIG_INTR_MASK           (((uint32) 0x03u << CMP_2_CONFIG_INTR_SHIFT) << \
                                                    CMP_2_CONFIG_REG_SHIFT)

#define CMP_2_CONFIG_OUT                 (((uint32) 0x01u << CMP_2_CONFIG_OUT_SHIFT) << \
                                                    CMP_2_CONFIG_REG_SHIFT)

#define CMP_2_CONFIG_EN                  (((uint32) 0x01u << CMP_2_CONFIG_EN_SHIFT) << \
                                                    CMP_2_CONFIG_REG_SHIFT)
#if(CMP_2_CY_LPCOMP_V2)
    #define CMP_2_CONFIG_DSI_BYPASS          (((uint32) 0x01u << CMP_2_CONFIG_DSI_BYPASS_SHIFT) << \
                                                        (CMP_2_CONFIG_REG_SHIFT/2))

    #define CMP_2_CONFIG_DSI_LEVEL           (((uint32) 0x01u << CMP_2_CONFIG_DSI_LEVEL_SHIFT) << \
                                                        (CMP_2_CONFIG_REG_SHIFT/2))
#endif /* (CMP_2_CY_LPCOMP_V2) */


/* CMP_2CMP_2_DFT_REG */
#define CMP_2_DFT_CAL_EN_SHIFT    (0u)    /* [0] Calibration enable */

#define CMP_2_DFT_CAL_EN          ((uint32) 0x01u << CMP_2_DFT_CAL_EN_SHIFT)


/***************************************
*       Init Macros Definitions
***************************************/

#define CMP_2_GET_CONFIG_SPEED_MODE(mode)    ((uint32) ((((uint32) (mode) << CMP_2_CONFIG_SPEED_MODE_SHIFT) << \
                                                            CMP_2_CONFIG_REG_SHIFT) & \
                                                            CMP_2_CONFIG_SPEED_MODE_MASK))

#define CMP_2_GET_CONFIG_HYST(hysteresis)    ((0u != (hysteresis)) ? (CMP_2_CONFIG_HYST) : (0u))

#define CMP_2_GET_CONFIG_INTR(intType)   ((uint32) ((((uint32)(intType) << CMP_2_CONFIG_INTR_SHIFT) << \
                                                    CMP_2_CONFIG_REG_SHIFT) & \
                                                    CMP_2_CONFIG_INTR_MASK))
#if(CMP_2_CY_LPCOMP_V2)
    #define CMP_2_GET_CONFIG_DSI_BYPASS(bypass)  ((0u != ((bypass) & CMP_2_OUT_DIRECT)) ? \
                                                                    (CMP_2_CONFIG_DSI_BYPASS) : (0u))
   
    #define CMP_2_GET_CONFIG_DSI_LEVEL(level)    ((0u != ((level) & CMP_2_OUT_SYNC)) ? \
                                                                    (CMP_2_CONFIG_DSI_LEVEL) : (0u))
    
    #define CMP_2_GET_INTR_MASK(mask)            ((0u != (mask)) ? (CMP_2_INTR_MASK) : (0u))
#endif /* (CMP_2_CY_LPCOMP_V2) */

#if(CMP_2_CY_LPCOMP_V0)
    #define CMP_2_CONFIG_REG_DEFAULT (CMP_2_GET_CONFIG_SPEED_MODE(CMP_2_SPEED) |\
                                                 CMP_2_GET_CONFIG_INTR(CMP_2_INTERRUPT)   |\
                                                 CMP_2_GET_CONFIG_HYST(CMP_2_HYSTERESIS))
#else
    #define CMP_2_CONFIG_REG_DEFAULT (CMP_2_GET_CONFIG_SPEED_MODE(CMP_2_SPEED) |\
                                                 CMP_2_GET_CONFIG_INTR(CMP_2_INTERRUPT)   |\
                                                 CMP_2_GET_CONFIG_HYST(CMP_2_HYSTERESIS)  |\
                                                 CMP_2_GET_CONFIG_DSI_BYPASS(CMP_2_OUT_MODE) |\
                                                 CMP_2_GET_CONFIG_DSI_LEVEL(CMP_2_OUT_MODE))
#endif /* (CMP_2_CY_LPCOMP_V0) */

#if(CMP_2_CY_LPCOMP_V2)
    #define CMP_2_INTR_MASK_REG_DEFAULT  (CMP_2_GET_INTR_MASK(CMP_2_INTERRUPT_EN))
#endif /* (CMP_2_CY_LPCOMP_V2) */


/***************************************
* The following code is DEPRECATED and 
* should not be used in new projects.
***************************************/

#define CMP_2_CONFIG_FILT_SHIFT          (3u)    
#define CMP_2_CONFIG_FILT                ((uint32)((uint32)((uint32)0x01u << \
                                                    CMP_2_CONFIG_FILT_SHIFT) << CMP_2_CONFIG_REG_SHIFT))

#define CMP_2_DIGITAL_FILTER             (0u)

/* CMP_2_SetFilter() parameters */
#define CMP_2_FILT_DISABLE               (0x00u)
#define CMP_2_FILT_ENABLE                (0x01u)

/* CMP_2_SetSpeed() parameters */
#define CMP_2_MEDSPEED                   (CMP_2_MED_SPEED)
#define CMP_2_HIGHSPEED                  (CMP_2_HIGH_SPEED)
#define CMP_2_LOWSPEED                   (CMP_2_LOW_SPEED)

void    CMP_2_SetFilter(uint32 filter);

#endif    /* CY_COMPARATOR_CMP_2_H */


/* [] END OF FILE */

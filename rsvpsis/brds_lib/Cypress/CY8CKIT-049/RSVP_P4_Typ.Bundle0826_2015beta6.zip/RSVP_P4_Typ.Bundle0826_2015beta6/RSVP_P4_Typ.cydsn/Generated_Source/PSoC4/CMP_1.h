/*******************************************************************************
* File Name: CMP_1.h
* Version 2.10
*
* Description:
*  This file contains the function prototypes and constants used in
*  the Low Power Comparator component.
*
* Note:
*  None
*
********************************************************************************
* Copyright 2013-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_COMPARATOR_CMP_1_H)
#define CY_COMPARATOR_CMP_1_H

#include "cytypes.h"
#include "cyfitter.h"


extern uint8  CMP_1_initVar;


/***************************************
*  Conditional Compilation Parameters
****************************************/

#define CMP_1_CY_LPCOMP_V0 (CYIPBLOCK_m0s8lpcomp_VERSION == 0u) 
#define CMP_1_CY_LPCOMP_V2 (CYIPBLOCK_m0s8lpcomp_VERSION >= 2u) 


/**************************************
*        Function Prototypes
**************************************/

void    CMP_1_Start(void);
void    CMP_1_Init(void);
void    CMP_1_Enable(void);
void    CMP_1_Stop(void);
void    CMP_1_SetSpeed(uint32 speed);
void    CMP_1_SetInterruptMode(uint32 mode);
uint32  CMP_1_GetInterruptSource(void);
void    CMP_1_ClearInterrupt(uint32 interruptMask);
void    CMP_1_SetInterrupt(uint32 interruptMask);
void    CMP_1_SetHysteresis(uint32 hysteresis);
uint32  CMP_1_GetCompare(void);
uint32  CMP_1_ZeroCal(void);
void    CMP_1_LoadTrim(uint32 trimVal);
void    CMP_1_Sleep(void);
void    CMP_1_Wakeup(void);
void    CMP_1_SaveConfig(void);
void    CMP_1_RestoreConfig(void);
#if(CMP_1_CY_LPCOMP_V2)
    void    CMP_1_SetOutputMode(uint32 mode);
    void    CMP_1_SetInterruptMask(uint32 interruptMask);
    uint32  CMP_1_GetInterruptMask(void);
    uint32  CMP_1_GetInterruptSourceMasked(void);
#endif /* (CMP_1_CY_LPCOMP_V2) */


/**************************************
*           API Constants
**************************************/

#if(CMP_1_CY_LPCOMP_V2)
    /* Constants for CMP_1_SetOutputMode(), mode parameter */
    #define CMP_1_OUT_PULSE      (0x00u)
    #define CMP_1_OUT_SYNC       (0x01u)
    #define CMP_1_OUT_DIRECT     (0x02u)
#endif /* (CMP_1_CY_LPCOMP_V2) */

#define CMP_1_INTR_PARAM_MASK    (0x03u)
#define CMP_1_SPEED_PARAM_MASK   (0x03u)

/* Constants for CMP_1_SetSpeed(), speed parameter */
#define CMP_1_MED_SPEED          (0x00u)
#define CMP_1_HIGH_SPEED         (0x01u)
#define CMP_1_LOW_SPEED          (0x02u)

/* Constants for CMP_1_SetInterruptMode(), mode parameter */
#define CMP_1_INTR_DISABLE       (0x00u)
#define CMP_1_INTR_RISING        (0x01u)
#define CMP_1_INTR_FALLING       (0x02u)
#define CMP_1_INTR_BOTH          (0x03u)

/* Constants for CMP_1_SetHysteresis(), hysteresis parameter */
#define CMP_1_HYST_ENABLE        (0x00u)
#define CMP_1_HYST_DISABLE       (0x01u)

/* Constants for CMP_1_ZeroCal() */
#define CMP_1_TRIMA_MASK         (0x1Fu)
#define CMP_1_TRIMA_SIGNBIT      (4u)
#define CMP_1_TRIMA_MAX_VALUE    (15u)
#define CMP_1_TRIMB_MASK         (0x1Fu)
#define CMP_1_TRIMB_SHIFT        (8u)
#define CMP_1_TRIMB_SIGNBIT      (4u)
#define CMP_1_TRIMB_MAX_VALUE    (15u)

/* Constants for CMP_1_GetInterruptSource() and 
* CMP_1_ClearInterrupt(), interruptMask parameter 
*/
#define CMP_1_INTR_SHIFT         (CMP_1_cy_psoc4_lpcomp_1__LPCOMP_INTR_SHIFT)
#define CMP_1_INTR               ((uint32)0x01u << CMP_1_INTR_SHIFT)

/* Constants for CMP_1_SetInterrupt(), interruptMask parameter */
#define CMP_1_INTR_SET_SHIFT     (CMP_1_cy_psoc4_lpcomp_1__LPCOMP_INTR_SET_SHIFT)
#define CMP_1_INTR_SET           ((uint32)0x01u << CMP_1_INTR_SHIFT)

#if(CMP_1_CY_LPCOMP_V2)
    /* Constants for CMP_1_GetInterruptMask() and 
    * CMP_1_SetInterruptMask(), interruptMask parameter 
    */
    #define CMP_1_INTR_MASK_SHIFT    (CMP_1_cy_psoc4_lpcomp_1__LPCOMP_INTR_MASK_SHIFT)
    #define CMP_1_INTR_MASK          ((uint32)0x01u << CMP_1_INTR_MASK_SHIFT)

    /* Constants for CMP_1_GetInterruptSourceMasked() */ 
    #define CMP_1_INTR_MASKED_SHIFT  (CMP_1_cy_psoc4_lpcomp_1__LPCOMP_INTR_MASKED_SHIFT)
    #define CMP_1_INTR_MASKED        ((uint32)0x01u << CMP_1_INTR_MASKED_SHIFT)
#endif /* (CMP_1_CY_LPCOMP_V2) */


/***************************************
* Enumerated Types and Parameters 
***************************************/

/* Enumerated Types LPCompSpeedType, Used in parameter Speed */
#define CMP_1__LPC_LOW_SPEED 2
#define CMP_1__LPC_MED_SPEED 0
#define CMP_1__LPC_HIGH_SPEED 1


/* Enumerated Types LPCompInterruptType, Used in parameter Interrupt */
#define CMP_1__LPC_INT_DISABLE 0
#define CMP_1__LPC_INT_RISING 1
#define CMP_1__LPC_INT_FALLING 2
#define CMP_1__LPC_INT_BOTH 3


/* Enumerated Types LPCompHysteresisType, Used in parameter Hysteresis */
#define CMP_1__LPC_DISABLE_HYST 1
#define CMP_1__LPC_ENABLE_HYST 0


/* Enumerated Types OutputModeType, Used in parameter OutputMode */
#define CMP_1__OUT_MODE_SYNC 1
#define CMP_1__OUT_MODE_DIRECT 2
#define CMP_1__OUT_MODE_PULSE 0



/***************************************
*   Initial Parameter Constants
****************************************/

#define CMP_1_INTERRUPT    (1u)
#define CMP_1_SPEED        (0u)
#define CMP_1_HYSTERESIS   (0u)
#if (CMP_1_CY_LPCOMP_V2)
    #define CMP_1_OUT_MODE       (0u)
    #define CMP_1_INTERRUPT_EN   (0u)
#endif /* (CMP_1_CY_LPCOMP_V2) */


/**************************************
*             Registers
**************************************/

#define CMP_1_CONFIG_REG     (*(reg32 *)CMP_1_cy_psoc4_lpcomp_1__LPCOMP_CONFIG)
#define CMP_1_CONFIG_PTR     ( (reg32 *)CMP_1_cy_psoc4_lpcomp_1__LPCOMP_CONFIG)

#define CMP_1_DFT_REG        (*(reg32 *)CYREG_LPCOMP_DFT)
#define CMP_1_DFT_PTR        ( (reg32 *)CYREG_LPCOMP_DFT)

#define CMP_1_INTR_REG       (*(reg32 *)CMP_1_cy_psoc4_lpcomp_1__LPCOMP_INTR)
#define CMP_1_INTR_PTR       ( (reg32 *)CMP_1_cy_psoc4_lpcomp_1__LPCOMP_INTR)

#define CMP_1_INTR_SET_REG   (*(reg32 *)CMP_1_cy_psoc4_lpcomp_1__LPCOMP_INTR_SET)
#define CMP_1_INTR_SET_PTR   ( (reg32 *)CMP_1_cy_psoc4_lpcomp_1__LPCOMP_INTR_SET)

#define CMP_1_TRIMA_REG      (*(reg32 *)CMP_1_cy_psoc4_lpcomp_1__TRIM_A)
#define CMP_1_TRIMA_PTR      ( (reg32 *)CMP_1_cy_psoc4_lpcomp_1__TRIM_A)

#define CMP_1_TRIMB_REG      (*(reg32 *)CMP_1_cy_psoc4_lpcomp_1__TRIM_B)
#define CMP_1_TRIMB_PTR      ( (reg32 *)CMP_1_cy_psoc4_lpcomp_1__TRIM_B)

#if(CMP_1_CY_LPCOMP_V2)
    #define CMP_1_INTR_MASK_REG    (*(reg32 *)CMP_1_cy_psoc4_lpcomp_1__LPCOMP_INTR_MASK) 
    #define CMP_1_INTR_MASK_PTR    ( (reg32 *)CMP_1_cy_psoc4_lpcomp_1__LPCOMP_INTR_MASK) 

    #define CMP_1_INTR_MASKED_REG  (*(reg32 *)CMP_1_cy_psoc4_lpcomp_1__LPCOMP_INTR_MASKED) 
    #define CMP_1_INTR_MASKED_PTR  ( (reg32 *)CMP_1_cy_psoc4_lpcomp_1__LPCOMP_INTR_MASKED) 
#endif /* (CMP_1_CY_LPCOMP_V2) */


/***************************************
*        Registers Constants
***************************************/

#define CMP_1_CONFIG_REG_SHIFT           (CMP_1_cy_psoc4_lpcomp_1__LPCOMP_CONFIG_SHIFT)

/* CMP_1CMP_1_CONFIG_REG */
#define CMP_1_CONFIG_SPEED_MODE_SHIFT    (0u)    /* [1:0]    Operating mode for the comparator      */
#define CMP_1_CONFIG_HYST_SHIFT          (2u)    /* [2]      Add 10mV hysteresis to the comparator: 0-enable, 1-disable */
#define CMP_1_CONFIG_INTR_SHIFT          (4u)    /* [5:4]    Sets Pulse/Interrupt mode              */
#define CMP_1_CONFIG_OUT_SHIFT           (6u)    /* [6]      Current output value of the comparator    */
#define CMP_1_CONFIG_EN_SHIFT            (7u)    /* [7]      Enable comparator */
#if(CMP_1_CY_LPCOMP_V2)
    #define CMP_1_CONFIG_DSI_BYPASS_SHIFT    (16u)   /* [16]   Bypass comparator output synchronization for DSI output  */
    #define CMP_1_CONFIG_DSI_LEVEL_SHIFT     (17u)   /* [17]   Comparator DSI (trigger) out level: 0-pulse, 1-level  */
#endif /* (CMP_1_CY_LPCOMP_V2) */

#define CMP_1_CONFIG_SPEED_MODE_MASK     (((uint32) 0x03u << CMP_1_CONFIG_SPEED_MODE_SHIFT) << \
                                                    CMP_1_CONFIG_REG_SHIFT)

#define CMP_1_CONFIG_HYST                (((uint32) 0x01u << CMP_1_CONFIG_HYST_SHIFT) << \
                                                    CMP_1_CONFIG_REG_SHIFT)

#define CMP_1_CONFIG_INTR_MASK           (((uint32) 0x03u << CMP_1_CONFIG_INTR_SHIFT) << \
                                                    CMP_1_CONFIG_REG_SHIFT)

#define CMP_1_CONFIG_OUT                 (((uint32) 0x01u << CMP_1_CONFIG_OUT_SHIFT) << \
                                                    CMP_1_CONFIG_REG_SHIFT)

#define CMP_1_CONFIG_EN                  (((uint32) 0x01u << CMP_1_CONFIG_EN_SHIFT) << \
                                                    CMP_1_CONFIG_REG_SHIFT)
#if(CMP_1_CY_LPCOMP_V2)
    #define CMP_1_CONFIG_DSI_BYPASS          (((uint32) 0x01u << CMP_1_CONFIG_DSI_BYPASS_SHIFT) << \
                                                        (CMP_1_CONFIG_REG_SHIFT/2))

    #define CMP_1_CONFIG_DSI_LEVEL           (((uint32) 0x01u << CMP_1_CONFIG_DSI_LEVEL_SHIFT) << \
                                                        (CMP_1_CONFIG_REG_SHIFT/2))
#endif /* (CMP_1_CY_LPCOMP_V2) */


/* CMP_1CMP_1_DFT_REG */
#define CMP_1_DFT_CAL_EN_SHIFT    (0u)    /* [0] Calibration enable */

#define CMP_1_DFT_CAL_EN          ((uint32) 0x01u << CMP_1_DFT_CAL_EN_SHIFT)


/***************************************
*       Init Macros Definitions
***************************************/

#define CMP_1_GET_CONFIG_SPEED_MODE(mode)    ((uint32) ((((uint32) (mode) << CMP_1_CONFIG_SPEED_MODE_SHIFT) << \
                                                            CMP_1_CONFIG_REG_SHIFT) & \
                                                            CMP_1_CONFIG_SPEED_MODE_MASK))

#define CMP_1_GET_CONFIG_HYST(hysteresis)    ((0u != (hysteresis)) ? (CMP_1_CONFIG_HYST) : (0u))

#define CMP_1_GET_CONFIG_INTR(intType)   ((uint32) ((((uint32)(intType) << CMP_1_CONFIG_INTR_SHIFT) << \
                                                    CMP_1_CONFIG_REG_SHIFT) & \
                                                    CMP_1_CONFIG_INTR_MASK))
#if(CMP_1_CY_LPCOMP_V2)
    #define CMP_1_GET_CONFIG_DSI_BYPASS(bypass)  ((0u != ((bypass) & CMP_1_OUT_DIRECT)) ? \
                                                                    (CMP_1_CONFIG_DSI_BYPASS) : (0u))
   
    #define CMP_1_GET_CONFIG_DSI_LEVEL(level)    ((0u != ((level) & CMP_1_OUT_SYNC)) ? \
                                                                    (CMP_1_CONFIG_DSI_LEVEL) : (0u))
    
    #define CMP_1_GET_INTR_MASK(mask)            ((0u != (mask)) ? (CMP_1_INTR_MASK) : (0u))
#endif /* (CMP_1_CY_LPCOMP_V2) */

#if(CMP_1_CY_LPCOMP_V0)
    #define CMP_1_CONFIG_REG_DEFAULT (CMP_1_GET_CONFIG_SPEED_MODE(CMP_1_SPEED) |\
                                                 CMP_1_GET_CONFIG_INTR(CMP_1_INTERRUPT)   |\
                                                 CMP_1_GET_CONFIG_HYST(CMP_1_HYSTERESIS))
#else
    #define CMP_1_CONFIG_REG_DEFAULT (CMP_1_GET_CONFIG_SPEED_MODE(CMP_1_SPEED) |\
                                                 CMP_1_GET_CONFIG_INTR(CMP_1_INTERRUPT)   |\
                                                 CMP_1_GET_CONFIG_HYST(CMP_1_HYSTERESIS)  |\
                                                 CMP_1_GET_CONFIG_DSI_BYPASS(CMP_1_OUT_MODE) |\
                                                 CMP_1_GET_CONFIG_DSI_LEVEL(CMP_1_OUT_MODE))
#endif /* (CMP_1_CY_LPCOMP_V0) */

#if(CMP_1_CY_LPCOMP_V2)
    #define CMP_1_INTR_MASK_REG_DEFAULT  (CMP_1_GET_INTR_MASK(CMP_1_INTERRUPT_EN))
#endif /* (CMP_1_CY_LPCOMP_V2) */


/***************************************
* The following code is DEPRECATED and 
* should not be used in new projects.
***************************************/

#define CMP_1_CONFIG_FILT_SHIFT          (3u)    
#define CMP_1_CONFIG_FILT                ((uint32)((uint32)((uint32)0x01u << \
                                                    CMP_1_CONFIG_FILT_SHIFT) << CMP_1_CONFIG_REG_SHIFT))

#define CMP_1_DIGITAL_FILTER             (0u)

/* CMP_1_SetFilter() parameters */
#define CMP_1_FILT_DISABLE               (0x00u)
#define CMP_1_FILT_ENABLE                (0x01u)

/* CMP_1_SetSpeed() parameters */
#define CMP_1_MEDSPEED                   (CMP_1_MED_SPEED)
#define CMP_1_HIGHSPEED                  (CMP_1_HIGH_SPEED)
#define CMP_1_LOWSPEED                   (CMP_1_LOW_SPEED)

void    CMP_1_SetFilter(uint32 filter);

#endif    /* CY_COMPARATOR_CMP_1_H */


/* [] END OF FILE */

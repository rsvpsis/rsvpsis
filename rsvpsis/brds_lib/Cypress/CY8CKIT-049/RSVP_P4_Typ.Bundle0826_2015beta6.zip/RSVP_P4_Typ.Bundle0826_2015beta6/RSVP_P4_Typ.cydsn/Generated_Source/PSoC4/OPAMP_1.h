/*******************************************************************************
* File Name: OPAMP_1.h
* Version 1.10
*
* Description:
*  This file contains the function prototypes and constants used in
*  the Opamp (Analog Buffer) Component.
*
*
********************************************************************************
* Copyright 2013-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/


#if !defined(CY_OPAMP_OPAMP_1_H)
#define CY_OPAMP_OPAMP_1_H

#include "cytypes.h"
#include "cyfitter.h"


/***************************************
*       Type Definitions
***************************************/

/* Structure to save state before go to sleep */
typedef struct
{
    uint8  enableState;
} OPAMP_1_BACKUP_STRUCT;


/**************************************
*        Function Prototypes
**************************************/
void OPAMP_1_Init(void);
void OPAMP_1_Enable(void);
void OPAMP_1_Start(void);
void OPAMP_1_Stop(void);
void OPAMP_1_SetPower(uint32 power);
void OPAMP_1_PumpControl(uint32 onOff);
void OPAMP_1_Sleep(void);
void OPAMP_1_Wakeup(void);
void OPAMP_1_SaveConfig(void);
void OPAMP_1_RestoreConfig(void);


/**************************************
*           API Constants
**************************************/

/* Parameters for SetPower() function */
#define OPAMP_1_LOW_POWER      (1u)
#define OPAMP_1_MED_POWER      (2u)
#define OPAMP_1_HIGH_POWER     (3u)


/* Parameters for PumpControl() function */
#define OPAMP_1_PUMP_ON        (1u)
#define OPAMP_1_PUMP_OFF       (0u)


/***************************************
*   Initial Parameter Constants
****************************************/

#define OPAMP_1_OUTPUT_CURRENT         (1u)
#define OPAMP_1_POWER                  (3u)
#define OPAMP_1_MODE                   (0u)
#define OPAMP_1_OA_COMP_TRIM_VALUE     (3u)
#define OPAMP_1_DEEPSLEEP_SUPPORT      (0u)


/***************************************
*    Variables with External Linkage
***************************************/

extern uint8  OPAMP_1_initVar;


/**************************************
*             Registers
**************************************/
#define OPAMP_1_CTB_CTRL_REG       (*(reg32 *) OPAMP_1_cy_psoc4_abuf__CTBM_CTB_CTRL)
#define OPAMP_1_CTB_CTRL_PTR       ( (reg32 *) OPAMP_1_cy_psoc4_abuf__CTBM_CTB_CTRL)
#define OPAMP_1_OA_RES_CTRL_REG    (*(reg32 *) OPAMP_1_cy_psoc4_abuf__OA_RES_CTRL)
#define OPAMP_1_OA_RES_CTRL_PTR    ( (reg32 *) OPAMP_1_cy_psoc4_abuf__OA_RES_CTRL)
#define OPAMP_1_OA_COMP_TRIM_REG   (*(reg32 *) OPAMP_1_cy_psoc4_abuf__OA_COMP_TRIM)
#define OPAMP_1_OA_COMP_TRIM_PTR   ( (reg32 *) OPAMP_1_cy_psoc4_abuf__OA_COMP_TRIM)


/***************************************
*        Registers Constants
***************************************/

/* OPAMP_1_CTB_CTRL_REG */
#define OPAMP_1_CTB_CTRL_DEEPSLEEP_ON_SHIFT    (30u)   /* [30] Selects behavior CTB IP in the DeepSleep power mode */
#define OPAMP_1_CTB_CTRL_ENABLED_SHIFT         (31u)   /* [31] Enable of the CTB IP */


#define OPAMP_1_CTB_CTRL_DEEPSLEEP_ON          ((uint32) 0x01u << OPAMP_1_CTB_CTRL_DEEPSLEEP_ON_SHIFT)
#define OPAMP_1_CTB_CTRL_ENABLED               ((uint32) 0x01u << OPAMP_1_CTB_CTRL_ENABLED_SHIFT)


/* OPAMP_1_OA_RES_CTRL_REG */
#define OPAMP_1_OA_PWR_MODE_SHIFT          (0u)    /* [1:0]    Power level */
#define OPAMP_1_OA_DRIVE_STR_SEL_SHIFT     (2u)    /* [2]      Opamp output strenght select: 0 - 1x, 1 - 10x */
#define OPAMP_1_OA_COMP_EN_SHIFT           (4u)    /* [4]      CTB IP mode: 0 - Opamp, 1 - Comparator  */
#define OPAMP_1_OA_PUMP_EN_SHIFT           (11u)   /* [11]     Pump enable */


#define OPAMP_1_OA_PWR_MODE                ((uint32) 0x02u << OPAMP_1_OA_PWR_MODE_SHIFT)
#define OPAMP_1_OA_PWR_MODE_MASK           ((uint32) 0x03u << OPAMP_1_OA_PWR_MODE_SHIFT)
#define OPAMP_1_OA_DRIVE_STR_SEL_1X        ((uint32) 0x00u << OPAMP_1_OA_DRIVE_STR_SEL_SHIFT)
#define OPAMP_1_OA_DRIVE_STR_SEL_10X       ((uint32) 0x01u << OPAMP_1_OA_DRIVE_STR_SEL_SHIFT)
#define OPAMP_1_OA_DRIVE_STR_SEL_MASK      ((uint32) 0x01u << OPAMP_1_OA_DRIVE_STR_SEL_SHIFT)
#define OPAMP_1_OA_COMP_EN                 ((uint32) 0x00u << OPAMP_1_OA_COMP_EN_SHIFT)
#define OPAMP_1_OA_PUMP_EN                 ((uint32) 0x01u << OPAMP_1_OA_PUMP_EN_SHIFT)


/***************************************
*       Init Macros Definitions
***************************************/

#define OPAMP_1_GET_DEEPSLEEP_ON(deepSleep)    ((0u != (deepSleep)) ? (OPAMP_1_CTB_CTRL_DEEPSLEEP_ON) : (0u))
#define OPAMP_1_GET_OA_DRIVE_STR(current)      ((0u != (current)) ? (OPAMP_1_OA_DRIVE_STR_SEL_10X) : \
                                                                             (OPAMP_1_OA_DRIVE_STR_SEL_1X))
#define OPAMP_1_GET_OA_PWR_MODE(mode)          ((mode) & OPAMP_1_OA_PWR_MODE_MASK)
#define OPAMP_1_CHECK_PWR_MODE_OFF             (0u != (OPAMP_1_OA_RES_CTRL_REG & \
                                                                OPAMP_1_OA_PWR_MODE_MASK))

/* Returns true if component available in Deep Sleep power mode*/ 
#define OPAMP_1_CHECK_DEEPSLEEP_SUPPORT        (0u != OPAMP_1_DEEPSLEEP_SUPPORT) 

#define OPAMP_1_DEFAULT_CTB_CTRL (OPAMP_1_GET_DEEPSLEEP_ON(OPAMP_1_DEEPSLEEP_SUPPORT) | \
                                           OPAMP_1_CTB_CTRL_ENABLED)

#define OPAMP_1_DEFAULT_OA_RES_CTRL (OPAMP_1_OA_COMP_EN | \
                                              OPAMP_1_GET_OA_DRIVE_STR(OPAMP_1_OUTPUT_CURRENT))

#define OPAMP_1_DEFAULT_OA_COMP_TRIM_REG (OPAMP_1_OA_COMP_TRIM_VALUE)


/***************************************
* The following code is DEPRECATED and 
* should not be used in new projects.
***************************************/

#define OPAMP_1_LOWPOWER                   (OPAMP_1_LOW_POWER)
#define OPAMP_1_MEDPOWER                   (OPAMP_1_MED_POWER)
#define OPAMP_1_HIGHPOWER                  (OPAMP_1_HIGH_POWER)

/* PUMP ON/OFF defines */
#define OPAMP_1_PUMPON                     (OPAMP_1_PUMP_ON)
#define OPAMP_1_PUMPOFF                    (OPAMP_1_PUMP_OFF)

#define OPAMP_1_OA_CTRL                    (OPAMP_1_CTB_CTRL_REG)
#define OPAMP_1_OA_RES_CTRL                (OPAMP_1_OA_RES_CTRL_REG)

/* Bit Field  OA_CTRL */
#define OPAMP_1_OA_CTB_EN_SHIFT            (OPAMP_1_CTB_CTRL_ENABLED_SHIFT)
#define OPAMP_1_OA_PUMP_CTRL_SHIFT         (OPAMP_1_OA_PUMP_EN_SHIFT)
#define OPAMP_1_OA_PUMP_EN_MASK            (0x800u)
#define OPAMP_1_PUMP_PROTECT_MASK          (1u)


#endif    /* CY_OPAMP_OPAMP_1_H */


/* [] END OF FILE */

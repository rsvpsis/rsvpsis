/*******************************************************************************
* File Name: CPM1_P.h  
* Version 2.10
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_CPM1_P_H) /* Pins CPM1_P_H */
#define CY_PINS_CPM1_P_H

#include "cytypes.h"
#include "cyfitter.h"
#include "CPM1_P_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    CPM1_P_Write(uint8 value) ;
void    CPM1_P_SetDriveMode(uint8 mode) ;
uint8   CPM1_P_ReadDataReg(void) ;
uint8   CPM1_P_Read(void) ;
uint8   CPM1_P_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define CPM1_P_DRIVE_MODE_BITS        (3)
#define CPM1_P_DRIVE_MODE_IND_MASK    (0xFFFFFFFFu >> (32 - CPM1_P_DRIVE_MODE_BITS))

#define CPM1_P_DM_ALG_HIZ         (0x00u)
#define CPM1_P_DM_DIG_HIZ         (0x01u)
#define CPM1_P_DM_RES_UP          (0x02u)
#define CPM1_P_DM_RES_DWN         (0x03u)
#define CPM1_P_DM_OD_LO           (0x04u)
#define CPM1_P_DM_OD_HI           (0x05u)
#define CPM1_P_DM_STRONG          (0x06u)
#define CPM1_P_DM_RES_UPDWN       (0x07u)

/* Digital Port Constants */
#define CPM1_P_MASK               CPM1_P__MASK
#define CPM1_P_SHIFT              CPM1_P__SHIFT
#define CPM1_P_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define CPM1_P_PS                     (* (reg32 *) CPM1_P__PS)
/* Port Configuration */
#define CPM1_P_PC                     (* (reg32 *) CPM1_P__PC)
/* Data Register */
#define CPM1_P_DR                     (* (reg32 *) CPM1_P__DR)
/* Input Buffer Disable Override */
#define CPM1_P_INP_DIS                (* (reg32 *) CPM1_P__PC2)


#if defined(CPM1_P__INTSTAT)  /* Interrupt Registers */

    #define CPM1_P_INTSTAT                (* (reg32 *) CPM1_P__INTSTAT)

#endif /* Interrupt Registers */


/***************************************
* The following code is DEPRECATED and 
* must not be used.
***************************************/

#define CPM1_P_DRIVE_MODE_SHIFT       (0x00u)
#define CPM1_P_DRIVE_MODE_MASK        (0x07u << CPM1_P_DRIVE_MODE_SHIFT)


#endif /* End Pins CPM1_P_H */


/* [] END OF FILE */

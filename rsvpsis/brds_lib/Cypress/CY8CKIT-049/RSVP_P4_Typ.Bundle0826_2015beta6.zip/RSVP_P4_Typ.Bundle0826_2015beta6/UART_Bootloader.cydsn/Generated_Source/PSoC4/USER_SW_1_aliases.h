/*******************************************************************************
* File Name: USER_SW_1.h  
* Version 2.10
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_USER_SW_1_ALIASES_H) /* Pins USER_SW_1_ALIASES_H */
#define CY_PINS_USER_SW_1_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define USER_SW_1_0		(USER_SW_1__0__PC)
#define USER_SW_1_0_PS		(USER_SW_1__0__PS)
#define USER_SW_1_0_PC		(USER_SW_1__0__PC)
#define USER_SW_1_0_DR		(USER_SW_1__0__DR)
#define USER_SW_1_0_SHIFT	(USER_SW_1__0__SHIFT)


#define USER_SW_1_P0_7		(USER_SW_1__P0_7__PC)
#define USER_SW_1_P0_7_PS		(USER_SW_1__P0_7__PS)
#define USER_SW_1_P0_7_PC		(USER_SW_1__P0_7__PC)
#define USER_SW_1_P0_7_DR		(USER_SW_1__P0_7__DR)
#define USER_SW_1_P0_7_SHIFT	(USER_SW_1__P0_7__SHIFT)


#endif /* End Pins USER_SW_1_ALIASES_H */


/* [] END OF FILE */
